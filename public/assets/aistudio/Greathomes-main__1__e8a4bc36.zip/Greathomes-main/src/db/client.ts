import { drizzle } from 'drizzle-orm/node-postgres';
import { sql } from 'drizzle-orm';
import { Pool } from 'pg';
import * as schema from './schema.ts';

let pool: Pool | null = null;
let dbInstance: ReturnType<typeof drizzle<typeof schema>> | null = null;
let schemaUpdatesPromise: Promise<void> | null = null;

export async function ensureSchemaUpdates(db: ReturnType<typeof drizzle<typeof schema>> | null) {
  if (!db) return;
  if (schemaUpdatesPromise) return schemaUpdatesPromise;

  schemaUpdatesPromise = (async () => {
  try {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS staff_users (
        id text PRIMARY KEY,
        email text NOT NULL UNIQUE,
        name text NOT NULL,
        role text NOT NULL,
        password_hash text,
        session_version integer DEFAULT 0 NOT NULL,
        enabled boolean DEFAULT true NOT NULL,
        avatar_url text,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL
      );

      ALTER TABLE IF EXISTS staff_users ADD COLUMN IF NOT EXISTS password_hash text;
      ALTER TABLE IF EXISTS staff_users ADD COLUMN IF NOT EXISTS session_version integer DEFAULT 0 NOT NULL;

      CREATE INDEX IF NOT EXISTS idx_staff_users_email ON staff_users(email);
      CREATE INDEX IF NOT EXISTS idx_staff_users_role ON staff_users(role);
      CREATE INDEX IF NOT EXISTS idx_staff_users_enabled ON staff_users(enabled);

      ALTER TABLE IF EXISTS projects ADD COLUMN IF NOT EXISTS project_area text;
      ALTER TABLE IF EXISTS projects ADD COLUMN IF NOT EXISTS tower_count integer;
      ALTER TABLE IF EXISTS projects ADD COLUMN IF NOT EXISTS total_units integer;
      ALTER TABLE IF EXISTS projects ADD COLUMN IF NOT EXISTS floors text;
      ALTER TABLE IF EXISTS projects ADD COLUMN IF NOT EXISTS possession text;
      ALTER TABLE IF EXISTS projects ADD COLUMN IF NOT EXISTS latitude numeric(9, 6);
      ALTER TABLE IF EXISTS projects ADD COLUMN IF NOT EXISTS longitude numeric(9, 6);

      ALTER TABLE IF EXISTS project_media ADD COLUMN IF NOT EXISTS media_id text;

      ALTER TABLE IF EXISTS resale_listings ADD COLUMN IF NOT EXISTS location_id uuid REFERENCES locations(id);
      ALTER TABLE IF EXISTS resale_listings ADD COLUMN IF NOT EXISTS latitude numeric(9, 6);
      ALTER TABLE IF EXISTS resale_listings ADD COLUMN IF NOT EXISTS longitude numeric(9, 6);
      ALTER TABLE IF EXISTS resale_listings ADD COLUMN IF NOT EXISTS geometry text;

      ALTER TABLE IF EXISTS rental_listings ADD COLUMN IF NOT EXISTS location_id uuid REFERENCES locations(id);
      ALTER TABLE IF EXISTS rental_listings ADD COLUMN IF NOT EXISTS latitude numeric(9, 6);
      ALTER TABLE IF EXISTS rental_listings ADD COLUMN IF NOT EXISTS longitude numeric(9, 6);
      ALTER TABLE IF EXISTS rental_listings ADD COLUMN IF NOT EXISTS geometry text;

      CREATE INDEX IF NOT EXISTS idx_resale_listings_location_id ON resale_listings(location_id);
      CREATE INDEX IF NOT EXISTS idx_rental_listings_location_id ON rental_listings(location_id);
      CREATE INDEX IF NOT EXISTS idx_resale_listings_spatial ON resale_listings USING gist (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)) WHERE (latitude IS NOT NULL AND longitude IS NOT NULL);
      CREATE INDEX IF NOT EXISTS idx_rental_listings_spatial ON rental_listings USING gist (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)) WHERE (latitude IS NOT NULL AND longitude IS NOT NULL);

      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS configuration_id text;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS priority text DEFAULT 'NORMAL';
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS assigned_to text;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS assigned_to_name text;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS source text;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS source_page text;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS internal_notes text;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS last_contacted_at timestamp;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS next_follow_up_at timestamp;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS site_visit_id text;
      ALTER TABLE IF EXISTS enquiries ADD COLUMN IF NOT EXISTS metadata text;

      CREATE INDEX IF NOT EXISTS idx_enquiries_status ON enquiries(status);
      CREATE INDEX IF NOT EXISTS idx_enquiries_priority ON enquiries(priority);
      CREATE INDEX IF NOT EXISTS idx_enquiries_context_type ON enquiries(context_type);
      CREATE INDEX IF NOT EXISTS idx_enquiries_created_at ON enquiries(created_at);
      CREATE INDEX IF NOT EXISTS idx_enquiries_updated_at ON enquiries(updated_at);
      CREATE INDEX IF NOT EXISTS idx_enquiries_assigned_to ON enquiries(assigned_to);
      CREATE INDEX IF NOT EXISTS idx_enquiries_project_id ON enquiries(project_id);
      CREATE INDEX IF NOT EXISTS idx_enquiries_listing_id ON enquiries(listing_id);
      CREATE INDEX IF NOT EXISTS idx_enquiries_next_follow_up_at ON enquiries(next_follow_up_at);

      CREATE TABLE IF NOT EXISTS audit_logs (
        id text PRIMARY KEY,
        actor_staff_id text REFERENCES staff_users(id) ON DELETE SET NULL,
        actor_role text NOT NULL,
        action text NOT NULL,
        resource_type text NOT NULL,
        resource_id text,
        resource_label text,
        timestamp timestamp DEFAULT now() NOT NULL,
        request_id text,
        ip_address text,
        user_agent text,
        before jsonb,
        after jsonb,
        metadata jsonb,
        success boolean DEFAULT true NOT NULL,
        failure_reason text,
        created_at timestamp DEFAULT now() NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_actor_staff_id ON audit_logs(actor_staff_id);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_resource_type ON audit_logs(resource_type);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_resource_id ON audit_logs(resource_id);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_success ON audit_logs(success);
      CREATE INDEX IF NOT EXISTS idx_audit_logs_request_id ON audit_logs(request_id);

      CREATE TABLE IF NOT EXISTS media_assets (
        id text PRIMARY KEY,
        entity_type text NOT NULL,
        entity_id text NOT NULL,
        filename text NOT NULL,
        mime_type text NOT NULL,
        category text NOT NULL,
        media_type text DEFAULT 'IMAGE' NOT NULL,
        width integer DEFAULT 0 NOT NULL,
        height integer DEFAULT 0 NOT NULL,
        file_size_bytes integer DEFAULT 0 NOT NULL,
        storage_provider text DEFAULT 'local' NOT NULL,
        storage_key text NOT NULL,
        url text NOT NULL,
        original_url text NOT NULL,
        thumbnail_url text,
        webp_url text,
        avif_url text,
        watermarked_url text,
        watermark_applied boolean DEFAULT false NOT NULL,
        alt_text text,
        caption text,
        sort_order integer DEFAULT 0 NOT NULL,
        is_featured boolean DEFAULT false NOT NULL,
        processing_status text DEFAULT 'READY' NOT NULL,
        variants jsonb,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_media_assets_entity ON media_assets(entity_type, entity_id);
      CREATE INDEX IF NOT EXISTS idx_media_assets_category ON media_assets(category);
      CREATE INDEX IF NOT EXISTS idx_media_assets_created ON media_assets(created_at);

      CREATE TABLE IF NOT EXISTS customers (
        id text PRIMARY KEY,
        email text NOT NULL UNIQUE,
        phone text,
        name text NOT NULL,
        password_hash text,
        avatar_url text,
        status text DEFAULT 'ACTIVE' NOT NULL,
        email_verified_at timestamp,
        phone_verified_at timestamp,
        last_login_at timestamp,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_customers_email ON customers(email);
      CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);
      CREATE INDEX IF NOT EXISTS idx_customers_status ON customers(status);

      -- Provider session identifiers and OTP state are server-side only. The OTP itself is never stored.
      CREATE TABLE IF NOT EXISTS customer_otp_challenges (
        id text PRIMARY KEY,
        phone text NOT NULL,
        phone_hash text NOT NULL,
        ip_hash text NOT NULL,
        provider_session_id text,
        customer_id text REFERENCES customers(id) ON DELETE SET NULL,
        status text NOT NULL DEFAULT 'SENDING',
        attempt_count integer NOT NULL DEFAULT 0,
        expires_at timestamp NOT NULL,
        verified_at timestamp,
        profile_expires_at timestamp,
        created_at timestamp NOT NULL DEFAULT now(),
        updated_at timestamp NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_customer_otp_phone_created
        ON customer_otp_challenges(phone_hash, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_customer_otp_status_expiry
        ON customer_otp_challenges(status, expires_at);

      -- Fixed-window counters are persistent across Vercel serverless instances.
      CREATE TABLE IF NOT EXISTS customer_auth_rate_limits (
        id text PRIMARY KEY,
        window_start timestamp NOT NULL DEFAULT now(),
        request_count integer NOT NULL DEFAULT 0,
        updated_at timestamp NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS customer_auth_sessions (
        token_hash text PRIMARY KEY,
        customer_id text NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
        expires_at timestamp NOT NULL,
        revoked_at timestamp,
        created_at timestamp NOT NULL DEFAULT now(),
        last_seen_at timestamp
      );
      CREATE INDEX IF NOT EXISTS idx_customer_auth_sessions_customer
        ON customer_auth_sessions(customer_id);
      CREATE INDEX IF NOT EXISTS idx_customer_auth_sessions_expiry
        ON customer_auth_sessions(expires_at);

      CREATE TABLE IF NOT EXISTS saved_items (
        id text PRIMARY KEY,
        customer_id text NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
        resource_type text NOT NULL,
        resource_id text NOT NULL,
        created_at timestamp DEFAULT now() NOT NULL,
        CONSTRAINT uq_saved_items_customer_resource UNIQUE (customer_id, resource_type, resource_id)
      );

      CREATE INDEX IF NOT EXISTS idx_saved_items_customer ON saved_items(customer_id);
      CREATE INDEX IF NOT EXISTS idx_saved_items_resource ON saved_items(resource_type, resource_id);
      CREATE INDEX IF NOT EXISTS idx_saved_items_created ON saved_items(created_at);

      CREATE TABLE IF NOT EXISTS recently_viewed (
        id text PRIMARY KEY,
        customer_id text NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
        resource_type text NOT NULL,
        resource_id text NOT NULL,
        first_viewed_at timestamp DEFAULT now() NOT NULL,
        last_viewed_at timestamp DEFAULT now() NOT NULL,
        view_count integer DEFAULT 1 NOT NULL,
        CONSTRAINT uq_recently_viewed_customer_resource UNIQUE (customer_id, resource_type, resource_id)
      );

      CREATE INDEX IF NOT EXISTS idx_recently_viewed_customer ON recently_viewed(customer_id);
      CREATE INDEX IF NOT EXISTS idx_recently_viewed_last_viewed ON recently_viewed(last_viewed_at);

      CREATE TABLE IF NOT EXISTS customer_preferences (
        id text PRIMARY KEY,
        customer_id text NOT NULL UNIQUE REFERENCES customers(id) ON DELETE CASCADE,
        preferred_mode text DEFAULT 'ALL',
        preferred_locations jsonb,
        preferred_bhk jsonb,
        preferred_property_types jsonb,
        budget_min integer,
        budget_max integer,
        email_alerts_enabled boolean DEFAULT true,
        new_launch_alerts boolean DEFAULT true,
        price_drop_alerts boolean DEFAULT true,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL
      );

      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS email_alerts_enabled boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS new_launch_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS price_drop_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS in_app_alerts_enabled boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS project_status_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS rera_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS price_change_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS configuration_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS location_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS resale_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS rental_alerts boolean DEFAULT true;
      ALTER TABLE IF EXISTS customer_preferences ADD COLUMN IF NOT EXISTS marketing_emails_enabled boolean DEFAULT false;

      CREATE TABLE IF NOT EXISTS project_watchlists (
        id text PRIMARY KEY,
        customer_id text REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
        project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
        enabled boolean DEFAULT true NOT NULL,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL,
        last_evaluated_at timestamp,
        last_alerted_at timestamp,
        CONSTRAINT uq_project_watchlists_customer_project UNIQUE (customer_id, project_id)
      );

      CREATE INDEX IF NOT EXISTS idx_project_watchlists_customer ON project_watchlists(customer_id);
      CREATE INDEX IF NOT EXISTS idx_project_watchlists_project ON project_watchlists(project_id);

      CREATE TABLE IF NOT EXISTS location_watchlists (
        id text PRIMARY KEY,
        customer_id text REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
        location_id uuid REFERENCES locations(id) ON DELETE CASCADE NOT NULL,
        enabled boolean DEFAULT true NOT NULL,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL,
        last_evaluated_at timestamp,
        last_alerted_at timestamp,
        CONSTRAINT uq_location_watchlists_customer_location UNIQUE (customer_id, location_id)
      );

      CREATE INDEX IF NOT EXISTS idx_location_watchlists_customer ON location_watchlists(customer_id);
      CREATE INDEX IF NOT EXISTS idx_location_watchlists_location ON location_watchlists(location_id);

      CREATE TABLE IF NOT EXISTS notifications (
        id text PRIMARY KEY,
        customer_id text REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
        type text NOT NULL,
        title text NOT NULL,
        message text NOT NULL,
        resource_type text NOT NULL,
        resource_id text NOT NULL,
        project_id uuid REFERENCES projects(id) ON DELETE SET NULL,
        location_id uuid REFERENCES locations(id) ON DELETE SET NULL,
        saved_item_id text,
        watch_id text,
        metadata jsonb,
        is_read boolean DEFAULT false NOT NULL,
        read_at timestamp,
        created_at timestamp DEFAULT now() NOT NULL,
        expires_at timestamp
      );

      CREATE INDEX IF NOT EXISTS idx_notifications_customer ON notifications(customer_id);
      CREATE INDEX IF NOT EXISTS idx_notifications_customer_created ON notifications(customer_id, created_at);
      CREATE INDEX IF NOT EXISTS idx_notifications_customer_read_created ON notifications(customer_id, is_read, created_at);
      CREATE INDEX IF NOT EXISTS idx_notifications_customer_type_created ON notifications(customer_id, type, created_at);

      CREATE TABLE IF NOT EXISTS alert_delivery_attempts (
        id text PRIMARY KEY,
        notification_id text REFERENCES notifications(id) ON DELETE CASCADE NOT NULL,
        channel text NOT NULL,
        status text NOT NULL,
        attempts integer DEFAULT 0 NOT NULL,
        last_attempt_at timestamp,
        failure_reason text,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_alert_delivery_notification ON alert_delivery_attempts(notification_id);
      CREATE INDEX IF NOT EXISTS idx_alert_delivery_status ON alert_delivery_attempts(status);

      CREATE INDEX IF NOT EXISTS idx_customer_preferences_customer ON customer_preferences(customer_id);

      CREATE TABLE IF NOT EXISTS location_market_snapshots (
        id text PRIMARY KEY,
        location_id uuid REFERENCES locations(id) ON DELETE CASCADE NOT NULL,
        snapshot_date text NOT NULL,
        project_count integer DEFAULT 0 NOT NULL,
        published_project_count integer DEFAULT 0 NOT NULL,
        new_launch_count integer DEFAULT 0 NOT NULL,
        under_construction_count integer DEFAULT 0 NOT NULL,
        ready_to_move_count integer DEFAULT 0 NOT NULL,
        completed_project_count integer DEFAULT 0 NOT NULL,
        sold_out_project_count integer DEFAULT 0 NOT NULL,
        resale_listing_count integer DEFAULT 0 NOT NULL,
        rental_listing_count integer DEFAULT 0 NOT NULL,
        configuration_counts jsonb,
        price_metrics jsonb,
        rera_metrics jsonb,
        data_freshness jsonb,
        source text DEFAULT 'GREAT_HOMES_DB' NOT NULL,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL,
        CONSTRAINT uq_snapshots_location_date UNIQUE (location_id, snapshot_date)
      );

      CREATE INDEX IF NOT EXISTS idx_snapshots_location ON location_market_snapshots(location_id);
      CREATE INDEX IF NOT EXISTS idx_snapshots_date ON location_market_snapshots(snapshot_date);

      CREATE TABLE IF NOT EXISTS market_events (
        id text PRIMARY KEY,
        event_type text NOT NULL,
        resource_type text NOT NULL,
        resource_id text NOT NULL,
        location_id uuid REFERENCES locations(id) ON DELETE CASCADE NOT NULL,
        project_id uuid REFERENCES projects(id) ON DELETE SET NULL,
        previous_value text,
        new_value text,
        change_fingerprint text NOT NULL,
        metadata jsonb,
        event_date timestamp DEFAULT now() NOT NULL,
        created_at timestamp DEFAULT now() NOT NULL,
        CONSTRAINT uq_market_events_fingerprint UNIQUE (location_id, event_type, resource_id, change_fingerprint)
      );

      CREATE INDEX IF NOT EXISTS idx_market_events_location ON market_events(location_id);
      CREATE INDEX IF NOT EXISTS idx_market_events_type ON market_events(event_type);
      CREATE INDEX IF NOT EXISTS idx_market_events_resource ON market_events(resource_type, resource_id);
      CREATE INDEX IF NOT EXISTS idx_market_events_date ON market_events(event_date);

      CREATE TABLE IF NOT EXISTS data_quality_issues (
        id text PRIMARY KEY,
        severity text NOT NULL,
        entity_type text NOT NULL,
        entity_id text NOT NULL,
        field text,
        code text NOT NULL,
        message text NOT NULL,
        detected_at timestamp DEFAULT now() NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_data_quality_severity ON data_quality_issues(severity);
      CREATE INDEX IF NOT EXISTS idx_data_quality_code ON data_quality_issues(code);
      CREATE INDEX IF NOT EXISTS idx_data_quality_entity ON data_quality_issues(entity_type, entity_id);

      CREATE TABLE IF NOT EXISTS project_considerations (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
        section text NOT NULL,
        title text NOT NULL,
        description text NOT NULL,
        source_type text DEFAULT 'EDITORIAL' NOT NULL,
        sort_order integer DEFAULT 0 NOT NULL,
        is_visible boolean DEFAULT true NOT NULL,
        created_at timestamp DEFAULT now() NOT NULL,
        updated_at timestamp DEFAULT now() NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_project_considerations_project_id ON project_considerations(project_id);
      CREATE INDEX IF NOT EXISTS idx_project_considerations_section ON project_considerations(section);
      CREATE INDEX IF NOT EXISTS idx_project_considerations_is_visible ON project_considerations(is_visible);
    `);
  } catch (err) {
    console.warn('Postgres schema extension notice:', err);
  }

  // Install the OTP tables independently so an unrelated legacy schema extension
  // cannot prevent passwordless authentication tables from being created.
  try {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS customer_otp_challenges (
        id text PRIMARY KEY,
        phone text NOT NULL,
        phone_hash text NOT NULL,
        ip_hash text NOT NULL,
        provider_session_id text,
        customer_id text REFERENCES customers(id) ON DELETE SET NULL,
        status text NOT NULL DEFAULT 'SENDING',
        attempt_count integer NOT NULL DEFAULT 0,
        expires_at timestamp NOT NULL,
        verified_at timestamp,
        profile_expires_at timestamp,
        created_at timestamp NOT NULL DEFAULT now(),
        updated_at timestamp NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS idx_customer_otp_phone_created
        ON customer_otp_challenges(phone_hash, created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_customer_otp_status_expiry
        ON customer_otp_challenges(status, expires_at);
      CREATE TABLE IF NOT EXISTS customer_auth_rate_limits (
        id text PRIMARY KEY,
        window_start timestamp NOT NULL DEFAULT now(),
        request_count integer NOT NULL DEFAULT 0,
        updated_at timestamp NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS customer_auth_sessions (
        token_hash text PRIMARY KEY,
        customer_id text NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
        expires_at timestamp NOT NULL,
        revoked_at timestamp,
        created_at timestamp NOT NULL DEFAULT now(),
        last_seen_at timestamp
      );
      CREATE INDEX IF NOT EXISTS idx_customer_auth_sessions_customer
        ON customer_auth_sessions(customer_id);
      CREATE INDEX IF NOT EXISTS idx_customer_auth_sessions_expiry
        ON customer_auth_sessions(expires_at);
    `);
  } catch (otpSchemaError) {
    console.warn('Customer OTP schema setup notice:', otpSchemaError);
  }
  })();
  return schemaUpdatesPromise;
}

export function getDb() {
  if (!dbInstance) {
    let connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      if (process.env.PERSISTENCE_PROVIDER === 'postgres') {
        throw new Error('FATAL: PERSISTENCE_PROVIDER is set to postgres, but DATABASE_URL is missing in environment.');
      }
      return null;
    }
    if (connectionString.includes('sslmode=') && !connectionString.includes('uselibpqcompat=') && !connectionString.includes('sslmode=verify-full')) {
      connectionString = connectionString.replace(/sslmode=(require|prefer|verify-ca)/g, 'sslmode=verify-full');
    }
    try {
      pool = new Pool({ connectionString });
      dbInstance = drizzle(pool, { schema });
      ensureSchemaUpdates(dbInstance).catch(() => {});
    } catch (err: any) {
      if (process.env.PERSISTENCE_PROVIDER === 'postgres') {
        throw new Error(`FATAL: Failed to connect to PostgreSQL database: ${err?.message || err}`);
      }
      return null;
    }
  }
  return dbInstance;
}

export function isPostgresConfigured(): boolean {
  return Boolean(process.env.DATABASE_URL && process.env.PERSISTENCE_PROVIDER === 'postgres');
}
