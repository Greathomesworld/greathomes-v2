import { auditLogRepository, AuditLogRepositoryPostgres } from '@/src/infrastructure/repositories/postgres/auditLogRepositoryPostgres';
import { AuditLogEntity, CreateAuditLogDto, AuditFilterDto } from './auditTypes';
import { extractRequestContext, RequestLike } from './auditRequestContext';

export class AuditService {
  private repository = auditLogRepository;

  async record(
    req: RequestLike | null,
    staff: { id?: string | null; role?: string | null } | null,
    data: Omit<CreateAuditLogDto, 'actorStaffId' | 'actorRole'>
  ): Promise<AuditLogEntity> {
    const actorStaffId = staff?.id || null;
    const actorRole = staff?.role || 'SYSTEM';

    let requestId: string | null = null;
    let ipAddress: string | null = null;
    let userAgent: string | null = null;

    if (req) {
      const ctx = extractRequestContext(req);
      requestId = ctx.requestId;
      ipAddress = ctx.ipAddress;
      userAgent = ctx.userAgent;
    }

    try {
      const metadata = data.metadata || (data.changes ? { changes: data.changes } : null);
      return await this.repository.create({
        ...data,
        metadata,
        actorStaffId,
        actorRole,
        requestId: data.requestId || requestId,
        ipAddress: data.ipAddress || ipAddress,
        userAgent: data.userAgent || userAgent,
      });
    } catch (err: any) {
      console.error('[AuditService] Failed to record audit log:', err);
      throw err;
    }
  }

  async recordSystem(data: CreateAuditLogDto): Promise<AuditLogEntity> {
    return await this.repository.create({
      ...data,
      actorStaffId: data.actorStaffId || null,
      actorRole: data.actorRole || 'SYSTEM',
    });
  }

  async getById(id: string): Promise<AuditLogEntity | null> {
    return await this.repository.findById(id);
  }

  async list(filter?: AuditFilterDto): Promise<{ items: AuditLogEntity[]; total: number }> {
    return await this.repository.list(filter);
  }
}

export const auditService = new AuditService();
