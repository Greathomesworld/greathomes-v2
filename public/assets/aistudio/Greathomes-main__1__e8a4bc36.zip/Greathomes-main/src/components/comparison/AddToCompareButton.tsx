'use client';

import React, { useState, useEffect } from 'react';
import { Scale, Check } from 'lucide-react';

interface AddToCompareButtonProps {
  mode: 'PROJECTS' | 'RESALE' | 'RENTAL';
  id: string;
  name: string;
  className?: string;
}

export function AddToCompareButton({ mode, id, name, className = '' }: AddToCompareButtonProps) {
  const [isComparing, setIsComparing] = useState(false);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(`gh_compare_${mode.toLowerCase()}`);
      if (stored) {
        const ids: string[] = JSON.parse(stored);
        setIsComparing(ids.includes(id));
      }
    } catch {
      // ignore
    }
  }, [mode, id]);

  const toggleCompare = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      const key = `gh_compare_${mode.toLowerCase()}`;
      const stored = localStorage.getItem(key);
      let ids: string[] = stored ? JSON.parse(stored) : [];

      if (ids.includes(id)) {
        ids = ids.filter(i => i !== id);
        setIsComparing(false);
      } else {
        if (ids.length >= 4) {
          alert('Compare up to 4 homes at a time');
          return;
        }
        ids.push(id);
        setIsComparing(true);
      }

      localStorage.setItem(key, JSON.stringify(ids));
      window.dispatchEvent(new Event('gh_compare_updated'));
    } catch {
      // ignore
    }
  };

  return (
    <button
      onClick={toggleCompare}
      title={isComparing ? 'Remove from comparison' : 'Add to comparison'}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
        isComparing
          ? 'bg-emerald-600 text-white shadow-sm'
          : 'bg-stone-100 hover:bg-stone-200 text-stone-700 dark:bg-stone-800 dark:text-stone-300 dark:hover:bg-stone-700'
      } ${className}`}
    >
      {isComparing ? <Check className="w-3.5 h-3.5" /> : <Scale className="w-3.5 h-3.5" />}
      <span>{isComparing ? 'Comparing' : 'Compare'}</span>
    </button>
  );
}
