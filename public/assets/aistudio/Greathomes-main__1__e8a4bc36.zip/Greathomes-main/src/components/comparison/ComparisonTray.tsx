'use client';

import React, { useState, useEffect } from 'react';
import { Scale, X, ArrowRight } from 'lucide-react';
import Link from 'next/link';

export function ComparisonTray() {
  const [activeMode, setActiveMode] = useState<'projects' | 'resale' | 'rental' | null>(null);
  const [ids, setIds] = useState<string[]>([]);

  useEffect(() => {
    const checkCompare = () => {
      const modes: ('projects' | 'resale' | 'rental')[] = ['projects', 'resale', 'rental'];
      for (const m of modes) {
        try {
          const stored = localStorage.getItem(`gh_compare_${m}`);
          if (stored) {
            const parsed: string[] = JSON.parse(stored);
            if (parsed && parsed.length > 0) {
              setActiveMode(m);
              setIds(parsed);
              return;
            }
          }
        } catch {
          // ignore
        }
      }
      setActiveMode(null);
      setIds([]);
    };

    checkCompare();
    window.addEventListener('gh_compare_updated', checkCompare);
    window.addEventListener('storage', checkCompare);
    return () => {
      window.removeEventListener('gh_compare_updated', checkCompare);
      window.removeEventListener('storage', checkCompare);
    };
  }, []);

  if (!activeMode || ids.length === 0) return null;

  const clearCompare = () => {
    try {
      localStorage.removeItem(`gh_compare_${activeMode}`);
      setIds([]);
      setActiveMode(null);
      window.dispatchEvent(new Event('gh_compare_updated'));
    } catch {
      // ignore
    }
  };

  const compareUrl = `/compare/${activeMode}?ids=${ids.join(',')}`;

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-xl px-4">
      <div className="bg-stone-900/95 backdrop-blur-md text-white px-5 py-3 rounded-2xl shadow-2xl border border-stone-800 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-display font-bold">
              Comparing {ids.length} {activeMode === 'projects' ? 'Projects' : activeMode === 'resale' ? 'Resale Homes' : 'Rental Homes'}
            </div>
            <div className="text-xs text-stone-400">
              {ids.length < 2 ? 'Select at least 2 homes to compare side-by-side' : 'Ready for side-by-side comparison'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={clearCompare}
            className="p-2 text-stone-400 hover:text-white transition-colors rounded-lg hover:bg-stone-800"
            title="Clear comparison"
          >
            <X className="w-4 h-4" />
          </button>
          <Link
            href={compareUrl}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium font-display transition-all ${
              ids.length >= 2
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
                : 'bg-stone-800 text-stone-400 cursor-not-allowed pointer-events-none'
            }`}
          >
            <span>Compare Now</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
