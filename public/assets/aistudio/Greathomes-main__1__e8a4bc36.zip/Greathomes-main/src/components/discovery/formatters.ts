/**
 * Discovery formatters for Great Homes V2
 * Pure formatting utilities for Indian real estate display
 */

export function formatIndianPrice(amount: number, isMonthly = false): string {
  if (amount === undefined || amount === null || isNaN(amount)) return 'Price on Request';
  
  if (isMonthly) {
    return `₹${amount.toLocaleString('en-IN')} / month`;
  }

  if (amount >= 10000000) {
    const cr = (amount / 10000000).toFixed(2).replace(/\.00$/, '');
    return `₹${cr} Cr`;
  }
  
  if (amount >= 100000) {
    const l = (amount / 100000).toFixed(2).replace(/\.00$/, '');
    return `₹${l} L`;
  }

  return `₹${amount.toLocaleString('en-IN')}`;
}

export function formatArea(sqft?: number | null): string | null {
  if (!sqft) return null;
  return `${sqft.toLocaleString('en-IN')} sq.ft.`;
}

export function formatFurnishing(furnishing?: string | null): string {
  if (!furnishing) return 'Unfurnished';
  switch (furnishing.toUpperCase()) {
    case 'FULLY_FURNISHED':
      return 'Fully Furnished';
    case 'SEMI_FURNISHED':
      return 'Semi Furnished';
    case 'UNFURNISHED':
      return 'Unfurnished';
    default:
      return furnishing.replace(/_/g, ' ');
  }
}

export function formatFloorCategory(floor?: string | null): string | null {
  if (!floor) return null;
  switch (floor.toUpperCase()) {
    case 'GROUND_FLOOR':
      return 'Ground Floor';
    case 'LOWER_FLOOR':
    case 'LOW_FLOOR':
      return 'Lower Floor';
    case 'MID_FLOOR':
      return 'Mid Floor';
    case 'HIGH_FLOOR':
    case 'HIGHER_FLOOR':
      return 'Higher Floor';
    case 'TOP_FLOOR':
      return 'Top Floor';
    default:
      return floor.replace(/_/g, ' ');
  }
}

export function formatPropertyType(type?: string | null): string {
  if (!type) return 'Residential';
  switch (type.toUpperCase()) {
    case 'APARTMENT':
      return 'Apartment';
    case 'VILLA':
      return 'Villa';
    case 'INDEPENDENT_HOUSE':
      return 'Independent House';
    case 'PLOT':
      return 'Plot';
    case 'DUPLEX':
      return 'Duplex';
    case 'PENTHOUSE':
      return 'Penthouse';
    default:
      return type.replace(/_/g, ' ');
  }
}

export function formatProjectStatus(status?: string | null): string {
  if (!status) return 'Project';
  switch (status.toUpperCase()) {
    case 'UPCOMING':
      return 'Upcoming';
    case 'NEW_LAUNCH':
      return 'New Launch';
    case 'UNDER_CONSTRUCTION':
      return 'Under Construction';
    case 'READY_TO_MOVE':
      return 'Ready to Move';
    case 'COMPLETED':
      return 'Completed';
    case 'SOLD_OUT':
      return 'Sold Out';
    default:
      return status.replace(/_/g, ' ');
  }
}
