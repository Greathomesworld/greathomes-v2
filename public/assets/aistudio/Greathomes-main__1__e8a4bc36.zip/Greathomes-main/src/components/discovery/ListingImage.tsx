'use client';

import { useState } from 'react';
import { Home, Building2 } from 'lucide-react';

interface ListingImageProps {
  src?: string | null;
  alt: string;
  className?: string;
  aspectRatio?: string;
  fallbackType?: 'resale' | 'rent' | 'project' | 'general';
}

export function ListingImage({
  src,
  alt,
  className = '',
  aspectRatio = 'aspect-[16/10]',
  fallbackType = 'general',
}: ListingImageProps) {
  const [hasError, setHasError] = useState(false);

  const showFallback = !src || hasError;

  if (showFallback) {
    const Icon = fallbackType === 'project' ? Building2 : Home;
    const label =
      fallbackType === 'resale'
        ? 'Verified Resale Residence'
        : fallbackType === 'rent'
        ? 'Verified Rental Residence'
        : fallbackType === 'project'
        ? 'Landmark Development'
        : 'Residential Property';

    return (
      <div
        className={`relative w-full ${aspectRatio} bg-gradient-to-br from-[#F5F4F0] via-[#EFECE6] to-[#E5E0D8] flex flex-col items-center justify-center text-center p-4 overflow-hidden border-b border-[rgba(17,17,17,0.06)] ${className}`}
        role="img"
        aria-label={alt || label}
      >
        {/* Subtle architectural background texture pattern */}
        <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#111111_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
        
        <div className="w-10 h-10 rounded-full bg-white/80 border border-[rgba(17,17,17,0.08)] flex items-center justify-center text-neutral-500 mb-2 shadow-2xs">
          <Icon className="w-5 h-5 text-neutral-600" />
        </div>
        <span className="text-[11px] font-medium tracking-wide uppercase text-neutral-600">
          {label}
        </span>
        <span className="text-[10px] text-neutral-400 mt-0.5">
          Great Homes Verified
        </span>
      </div>
    );
  }

  return (
    <div className={`relative w-full ${aspectRatio} bg-neutral-100 overflow-hidden ${className}`}>
      <img
        src={src}
        alt={alt}
        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
        loading="lazy"
        onError={() => setHasError(true)}
      />
    </div>
  );
}
