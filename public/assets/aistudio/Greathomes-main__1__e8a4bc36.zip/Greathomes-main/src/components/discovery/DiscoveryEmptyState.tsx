'use client';

import { useRouter, usePathname } from 'next/navigation';
import { SearchX, RotateCcw } from 'lucide-react';

interface DiscoveryEmptyStateProps {
  title?: string;
  description?: string;
}

export function DiscoveryEmptyState({
  title = 'No residences found',
  description = 'We could not find properties matching all of your specified criteria. Try widening your price range, choosing all BHK configurations, or removing selected filters.',
}: DiscoveryEmptyStateProps) {
  const router = useRouter();
  const pathname = usePathname();

  const handleReset = () => {
    router.push(pathname);
  };

  return (
    <div className="py-16 px-6 text-center max-w-lg mx-auto bg-white rounded-2xl border border-[rgba(17,17,17,0.08)] shadow-2xs my-6">
      <div className="w-12 h-12 rounded-full bg-[#FAFAF8] border border-[rgba(17,17,17,0.08)] flex items-center justify-center mx-auto mb-4 text-neutral-400">
        <SearchX className="w-6 h-6 text-neutral-500" />
      </div>

      <h3 className="font-display font-semibold text-xl text-[#111111] mb-2">
        {title}
      </h3>

      <p className="text-sm text-neutral-600 leading-relaxed mb-6 font-body">
        {description}
      </p>

      <button
        type="button"
        onClick={handleReset}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#111111] text-white text-xs font-semibold hover:bg-neutral-800 transition-colors shadow-xs cursor-pointer"
      >
        <RotateCcw className="w-3.5 h-3.5" />
        <span>Clear All Filters</span>
      </button>
    </div>
  );
}
