import Link from 'next/link';
import { MapPin, ShieldCheck, CheckCircle, ArrowRight } from 'lucide-react';
import { 
  ProjectDiscoveryCardDto, 
  PropertyDiscoveryCardDto, 
  NewBookingDiscoveryCardDto, 
  ResaleDiscoveryCardDto, 
  RentDiscoveryCardDto 
} from '@/src/domain/projects/dto/discoveryDto';
import { formatIndianPrice, formatArea, formatFurnishing, formatFloorCategory, formatPropertyType, formatProjectStatus } from './formatters';
import { ListingImage } from './ListingImage';

interface PropertyCardProps {
  item: PropertyDiscoveryCardDto | RentDiscoveryCardDto | ProjectDiscoveryCardDto;
  id?: string;
}

export function PropertyCard({ item, id }: PropertyCardProps) {
  if (item.type === 'NEW_BOOKING') {
    return <NewBookingCard item={item as NewBookingDiscoveryCardDto} id={id} />;
  }
  if (item.type === 'RESALE') {
    return <ResaleCard item={item as ResaleDiscoveryCardDto} id={id} />;
  }
  if (item.type === 'RENT') {
    return <RentCard item={item as RentDiscoveryCardDto} id={id} />;
  }
  if (item.type === 'PROJECT') {
    return <ProjectCard item={item as ProjectDiscoveryCardDto} id={id} />;
  }
  return null;
}

function NewBookingCard({ item, id }: { item: NewBookingDiscoveryCardDto; id?: string }) {
  const projectSlug = item.project?.slug || '#';
  const targetUrl = `/projects/${projectSlug}`;
  const locationLabel = item.project?.location?.name || 'Kolkata';
  const devName = item.project?.developer?.name;
  const configSummary = `${item.bedroomCount} BHK`;
  const areaSummary = formatArea(item.carpetArea);

  return (
    <Link
      href={targetUrl}
      id={id || `card-nb-${item.id}`}
      aria-label={`${item.bedroomCount} BHK New Booking at ${item.project?.name || item.configurationName}`}
      className="group flex flex-col bg-white border border-[rgba(17,17,17,0.08)] rounded-xl overflow-hidden hover:border-[rgba(17,17,17,0.2)] hover:shadow-md transition-all duration-200 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#111111] focus-visible:ring-offset-2"
    >
      <article className="flex flex-col flex-grow">
        {/* Media Header */}
        <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
          <ListingImage
            src={item.featuredImageUrl}
            alt={item.configurationName}
            fallbackType="project"
          />
          
          {/* Top Badges */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
            <span className="bg-[#111111] text-white text-[11px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-md shadow-xs">
              NEW BOOKING
            </span>
          </div>

          <div className="absolute top-3 right-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
            {item.reraVerified && (
              <span className="bg-[#218C5A] text-white text-[11px] font-medium px-2 py-1 rounded-md flex items-center gap-1 shadow-xs">
                <ShieldCheck className="w-3 h-3" />
                RERA Verified
              </span>
            )}
            {item.availabilityStatus === 'FEW_UNITS_LEFT' && (
              <span className="bg-[#E85D3F] text-white text-[11px] font-medium px-2 py-1 rounded-md shadow-xs">
                Few Units Left
              </span>
            )}
          </div>
        </div>

        {/* Body */}
        <div className="p-5 flex flex-col flex-grow justify-between">
          <div>
            {/* Project & Developer */}
            <div className="flex items-baseline justify-between gap-2 mb-1">
              <h3 className="font-display font-semibold text-lg text-[#111111] group-hover:text-[#E85D3F] transition-colors line-clamp-1">
                {item.project?.name || item.configurationName}
              </h3>
            </div>
            
            {devName && (
              <p className="text-xs text-neutral-500 mb-2">by {devName}</p>
            )}

            <div className="flex items-center gap-1 text-xs text-neutral-600 mb-3.5">
              <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
              <span className="line-clamp-1">{locationLabel}</span>
            </div>

            {/* Configuration & Area */}
            <div className="py-2.5 px-3 bg-[#FAFAF8] rounded-lg border border-[rgba(17,17,17,0.06)] text-xs text-neutral-700 flex items-center justify-between mb-4">
              <span className="font-medium text-neutral-900">{configSummary} · {item.configurationName}</span>
              {areaSummary && <span className="text-neutral-500">{areaSummary}</span>}
            </div>
          </div>

          {/* Pricing & CTA - Secondary reinforcement inside card */}
          <div className="pt-3 border-t border-[rgba(17,17,17,0.06)] flex items-end justify-between">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-neutral-500 block mb-0.5">Starting Price</span>
              <div className="flex items-baseline gap-1.5">
                <span className="font-display font-bold text-xl text-[#111111]">
                  {formatIndianPrice(item.price)}
                </span>
                <span className="text-xs text-neutral-500">onwards</span>
              </div>
              {item.effectivePricePerSqft > 0 && (
                <span className="text-[11px] text-neutral-500 block">
                  ₹{Math.round(item.effectivePricePerSqft).toLocaleString('en-IN')}/sq.ft.
                </span>
              )}
            </div>

            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#111111] group-hover:text-[#E85D3F] transition-colors py-2 px-3 rounded-lg border border-[rgba(17,17,17,0.12)] group-hover:border-[#E85D3F]">
              <span>View Project</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}

function ResaleCard({ item, id }: { item: ResaleDiscoveryCardDto; id?: string }) {
  const projectSlug = item.project?.slug;
  const targetUrl = item.slug ? `/buy/${item.slug}` : (projectSlug ? `/projects/${projectSlug}` : '#');
  const locationLabel = item.location?.name || item.project?.location?.name || 'Kolkata';
  const areaSummary = formatArea(item.carpetArea);
  const floorLabel = formatFloorCategory(item.floorCategory);
  const furnishLabel = formatFurnishing(item.furnishing);

  return (
    <Link
      href={targetUrl}
      id={id || `card-resale-${item.id}`}
      aria-label={`${item.bedroomCount} BHK Resale Home at ${item.project?.name || item.configuration}`}
      className="group flex flex-col bg-white border border-[rgba(17,17,17,0.08)] rounded-xl overflow-hidden hover:border-[rgba(17,17,17,0.2)] hover:shadow-md transition-all duration-200 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#111111] focus-visible:ring-offset-2"
    >
      <article className="flex flex-col flex-grow">
        {/* Media Header */}
        <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
          <ListingImage
            src={item.featuredImageUrl}
            alt={item.configuration}
            fallbackType="resale"
          />
          
          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
            <span className="bg-white/95 text-[#111111] border border-[rgba(17,17,17,0.12)] text-[11px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-md shadow-xs backdrop-blur-xs">
              RESALE
            </span>
          </div>

          <div className="absolute top-3 right-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
            {item.verificationStatus === 'VERIFIED' && (
              <span className="bg-[#218C5A] text-white text-[11px] font-medium px-2 py-1 rounded-md flex items-center gap-1 shadow-xs">
                <CheckCircle className="w-3 h-3" />
                Verified
              </span>
            )}
          </div>
        </div>

        {/* Body */}
        <div className="p-5 flex flex-col flex-grow justify-between">
          <div>
            <div className="flex items-baseline justify-between gap-2 mb-1">
              <h3 className="font-display font-semibold text-lg text-[#111111] group-hover:text-[#E85D3F] transition-colors line-clamp-1">
                {item.bedroomCount} BHK {formatPropertyType(item.propertyType)}
              </h3>
            </div>

            <p className="text-xs text-neutral-600 mb-2 font-medium">
              {item.project?.name ? item.project.name : item.configuration}
            </p>

            <div className="flex items-center gap-1 text-xs text-neutral-600 mb-3.5">
              <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
              <span className="line-clamp-1">{locationLabel}</span>
            </div>

            {/* Highlights */}
            <div className="py-2.5 px-3 bg-[#FAFAF8] rounded-lg border border-[rgba(17,17,17,0.06)] text-xs text-neutral-700 flex flex-wrap items-center justify-between gap-1 mb-4">
              <span className="font-medium text-neutral-800">
                {[floorLabel, furnishLabel].filter(Boolean).join(' · ')}
              </span>
              {areaSummary && <span className="text-neutral-500">{areaSummary}</span>}
            </div>
          </div>

          {/* Pricing & CTA - Strict rule: NO price/sq.ft. displayed */}
          <div className="pt-3 border-t border-[rgba(17,17,17,0.06)] flex items-end justify-between">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-neutral-500 block mb-0.5">Asking Price</span>
              <div className="flex items-baseline gap-1.5">
                <span className="font-display font-bold text-xl text-[#111111]">
                  {formatIndianPrice(item.askingPrice)}
                </span>
              </div>
              <span className="text-[11px] text-neutral-500 block mt-0.5">
                {item.listingPartyLabel || 'Verified Listing'}
              </span>
            </div>

            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#111111] group-hover:text-[#E85D3F] transition-colors py-2 px-3 rounded-lg border border-[rgba(17,17,17,0.12)] group-hover:border-[#E85D3F]">
              <span>View Property</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}

function RentCard({ item, id }: { item: RentDiscoveryCardDto; id?: string }) {
  const projectSlug = item.project?.slug;
  const targetUrl = item.slug ? `/rent/${item.slug}` : (projectSlug ? `/projects/${projectSlug}` : '#');
  const locationLabel = item.location?.name || item.project?.location?.name || 'Kolkata';
  const areaSummary = formatArea(item.carpetArea);
  const floorLabel = formatFloorCategory(item.floorCategory);
  const furnishLabel = formatFurnishing(item.furnishing);

  return (
    <Link
      href={targetUrl}
      id={id || `card-rent-${item.id}`}
      aria-label={`${item.bedroomCount} BHK Rental Home at ${item.project?.name || item.configuration}`}
      className="group flex flex-col bg-white border border-[rgba(17,17,17,0.08)] rounded-xl overflow-hidden hover:border-[rgba(17,17,17,0.2)] hover:shadow-md transition-all duration-200 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#111111] focus-visible:ring-offset-2"
    >
      <article className="flex flex-col flex-grow">
        {/* Media Header */}
        <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
          <ListingImage
            src={item.featuredImageUrl}
            alt={item.configuration}
            fallbackType="rent"
          />
          
          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
            <span className="bg-white/95 text-[#111111] border border-[rgba(17,17,17,0.12)] text-[11px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-md shadow-xs backdrop-blur-xs">
              RENT
            </span>
          </div>

          <div className="absolute top-3 right-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
            {item.verificationStatus === 'VERIFIED' && (
              <span className="bg-[#218C5A] text-white text-[11px] font-medium px-2 py-1 rounded-md flex items-center gap-1 shadow-xs">
                <CheckCircle className="w-3 h-3" />
                Verified Lease
              </span>
            )}
          </div>
        </div>

        {/* Body */}
        <div className="p-5 flex flex-col flex-grow justify-between">
          <div>
            <div className="flex items-baseline justify-between gap-2 mb-1">
              <h3 className="font-display font-semibold text-lg text-[#111111] group-hover:text-[#E85D3F] transition-colors line-clamp-1">
                {item.bedroomCount} BHK {formatPropertyType(item.propertyType)}
              </h3>
            </div>

            <p className="text-xs text-neutral-600 mb-2 font-medium">
              {item.project?.name ? item.project.name : item.configuration}
            </p>

            <div className="flex items-center gap-1 text-xs text-neutral-600 mb-3.5">
              <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
              <span className="line-clamp-1">{locationLabel}</span>
            </div>

            {/* Highlights */}
            <div className="py-2.5 px-3 bg-[#FAFAF8] rounded-lg border border-[rgba(17,17,17,0.06)] text-xs text-neutral-700 flex flex-wrap items-center justify-between gap-1 mb-4">
              <span className="font-medium text-neutral-800">
                {[floorLabel, furnishLabel].filter(Boolean).join(' · ')}
              </span>
              {areaSummary && <span className="text-neutral-500">{areaSummary}</span>}
            </div>
          </div>

          {/* Pricing & CTA - Strict rule: NO rent/sq.ft. displayed */}
          <div className="pt-3 border-t border-[rgba(17,17,17,0.06)] flex items-end justify-between">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-neutral-500 block mb-0.5">Monthly Rent</span>
              <div className="flex items-baseline gap-1">
                <span className="font-display font-bold text-xl text-[#111111]">
                  ₹{item.monthlyRent.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-neutral-500">/ mo</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5 text-[11px] text-neutral-500">
                {item.maintenance ? <span>+ ₹{item.maintenance.toLocaleString('en-IN')} maint.</span> : null}
                {item.securityDeposit ? <span>Deposit: ₹{item.securityDeposit.toLocaleString('en-IN')}</span> : null}
              </div>
            </div>

            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#111111] group-hover:text-[#E85D3F] transition-colors py-2 px-3 rounded-lg border border-[rgba(17,17,17,0.12)] group-hover:border-[#E85D3F]">
              <span>View Property</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}

function ProjectCard({ item, id }: { item: ProjectDiscoveryCardDto; id?: string }) {
  const targetUrl = `/projects/${item.slug}`;
  const locationLabel = item.location?.name || 'Kolkata';
  const devName = item.developer?.name;
  const configText = item.bhkSummary?.length > 0 ? `${item.bhkSummary.join(', ')} BHK` : 'Configurations Available';

  return (
    <Link
      href={targetUrl}
      id={id || `card-proj-${item.id}`}
      aria-label={`${item.name} development in ${locationLabel}`}
      className="group flex flex-col bg-white border border-[rgba(17,17,17,0.08)] rounded-xl overflow-hidden hover:border-[rgba(17,17,17,0.2)] hover:shadow-md transition-all duration-200 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#111111] focus-visible:ring-offset-2"
    >
      <article className="flex flex-col flex-grow">
        {/* Media Header */}
        <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
          <ListingImage
            src={item.featuredImageUrl}
            alt={item.name}
            fallbackType="project"
          />
          
          {/* Badges */}
          {item.status && (
            <div className="absolute top-3 left-3 flex items-center gap-1 bg-white/95 text-[#111111] border border-[rgba(17,17,17,0.12)] text-[10px] font-bold tracking-wider uppercase px-2.5 py-1 rounded-md shadow-xs backdrop-blur-xs z-10 pointer-events-none font-display">
              {formatProjectStatus(item.status)}
            </div>
          )}

          {item.reraVerified && (
            <div className="absolute top-3 right-3 flex items-center gap-1 bg-[#218C5A] text-white text-[11px] font-medium px-2 py-1 rounded-md shadow-xs z-10 pointer-events-none">
              <ShieldCheck className="w-3 h-3" />
              RERA Verified
            </div>
          )}
        </div>

        {/* Body */}
        <div className="p-5 flex flex-col flex-grow justify-between">
          <div>
            <h3 className="font-display font-semibold text-lg text-[#111111] group-hover:text-[#E85D3F] transition-colors line-clamp-1 mb-0.5">
              {item.name}
            </h3>

            {devName && (
              <p className="text-xs text-neutral-500 mb-2">by {devName}</p>
            )}

            <div className="flex items-center gap-1 text-xs text-neutral-600 mb-3.5">
              <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
              <span className="line-clamp-1">{locationLabel}</span>
            </div>

            <div className="py-2.5 px-3 bg-[#FAFAF8] rounded-lg border border-[rgba(17,17,17,0.06)] text-xs text-neutral-700 flex items-center justify-between mb-4">
              <span className="font-medium text-neutral-900">{configText}</span>
              <span className="text-neutral-500">
                {item.propertyTypes?.map(formatPropertyType).join(', ') || 'Residences'}
              </span>
            </div>
          </div>

          {/* Pricing & CTA */}
          <div className="pt-3 border-t border-[rgba(17,17,17,0.06)] flex items-end justify-between">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-neutral-500 block mb-0.5">Starting Price</span>
              <div className="flex items-baseline gap-1.5">
                <span className="font-display font-bold text-xl text-[#111111]">
                  {formatIndianPrice(item.startingPrice ?? 0)}
                </span>
                <span className="text-xs text-neutral-500">onwards</span>
              </div>
            </div>

            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#111111] group-hover:text-[#E85D3F] transition-colors py-2 px-3 rounded-lg border border-[rgba(17,17,17,0.12)] group-hover:border-[#E85D3F]">
              <span>View Project</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}
