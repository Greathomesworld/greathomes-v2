'use client';

import React, { useState } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { Search, Menu, X, ArrowRight, Phone, MessageSquare } from 'lucide-react';
import { CustomerNavControl } from '../customer/CustomerNavControl';
import { useEnquiry } from '../enquiry/EnquiryContext';

export function Header() {
  const pathname = usePathname();
  const { openEnquiry } = useEnquiry();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Suppress public consumer header on admin routes
  if (pathname?.startsWith('/admin')) {
    return null;
  }

  const handleOpenAssistance = () => {
    openEnquiry({
      contextType: 'GENERAL',
      title: 'Assisted Home-Buying Concierge',
      subtitle: 'Connect with a verified Kolkata residential advisor for shortlisting and site visits.',
    });
  };

  const navLinks = [
    { label: 'New Launches', href: '/buy?inventoryType=NEW_BOOKING' },
    { label: 'Projects', href: '/projects' },
    { label: 'Buy Resale', href: '/buy?inventoryType=RESALE' },
    { label: 'Rent', href: '/rent' },
    { label: 'Locations', href: '/locations' },
    { label: 'Developers', href: '/developers' },
    { label: 'Guides', href: '/guides' },
  ];

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b border-neutral-200/80 bg-white/95 backdrop-blur-md transition-shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between gap-4">
          {/* Brand Logo & Location Descriptor */}
          <div className="flex items-center gap-4 lg:gap-8 shrink-0">
            <Link
              href="/"
              className="group flex items-center gap-3 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E85D3F] rounded-md transition-opacity"
              aria-label="Great Homes — Home"
            >
              <div className="relative h-7 sm:h-8 w-auto aspect-[6.2/1] flex items-center">
                <Image
                  src="/assets/GH_logo.svg"
                  alt="Great Homes"
                  width={155}
                  height={25}
                  priority
                  className="h-7 sm:h-8 w-auto object-contain"
                />
              </div>
            </Link>

            {/* Desktop Navigation Links - Enabled from lg breakpoint up */}
            <nav className="hidden lg:flex items-center gap-4 xl:gap-6 text-xs xl:text-sm font-medium font-display text-neutral-700">
              {navLinks.map((link) => {
                const isActive = pathname === link.href || (link.href !== '/' && pathname?.startsWith(link.href.split('?')[0]) && link.href.includes('?') && pathname.includes(link.href.split('?')[1]));
                return (
                  <Link
                    key={link.label}
                    href={link.href}
                    className={`relative py-1 px-1 transition-colors whitespace-nowrap hover:text-[#E85D3F] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E85D3F] rounded ${
                      isActive ? 'text-[#E85D3F] font-bold' : 'text-neutral-700'
                    }`}
                  >
                    <span>{link.label}</span>
                    {isActive && (
                      <span className="absolute bottom-0 left-1 right-1 h-0.5 bg-[#E85D3F] rounded-full animate-fade-in" />
                    )}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Desktop Right Actions */}
          <div className="flex items-center gap-2.5 sm:gap-3.5 shrink-0">
            {/* Universal Search Shortcut Icon */}
            <Link
              href="/projects"
              aria-label="Universal property search"
              className="p-2 text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100/80 rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E85D3F]"
            >
              <Search className="w-4 h-4" />
            </Link>

            {/* Customer User Account */}
            <CustomerNavControl />

            {/* Prominent 'Get Assistance' CTA Button (Terracotta) */}
            <button
              type="button"
              onClick={handleOpenAssistance}
              className="hidden sm:inline-flex items-center justify-center px-4 py-2 sm:px-4.5 sm:py-2.5 rounded-lg bg-[#E85D3F] text-white text-xs sm:text-sm font-display font-semibold hover:bg-[#D44E32] active:scale-[0.98] shadow-xs hover:shadow-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E85D3F] focus-visible:ring-offset-2 cursor-pointer"
            >
              Get Assistance
            </button>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
              className="lg:hidden p-2 text-neutral-700 hover:text-neutral-950 hover:bg-neutral-100 rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E85D3F]"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer / Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 top-16 sm:top-18 z-30 bg-black/40 backdrop-blur-xs lg:hidden animate-fade-in">
          <div
            className="w-full bg-white border-b border-neutral-200 shadow-xl px-6 py-6 space-y-6 max-h-[calc(100vh-4.5rem)] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Mobile Nav Links */}
            <nav className="flex flex-col space-y-1 font-display">
              {navLinks.map((link) => {
                const isActive = pathname === link.href || (link.href !== '/' && pathname?.startsWith(link.href.split('?')[0]) && link.href.includes('?') && pathname.includes(link.href.split('?')[1]));
                return (
                  <Link
                    key={link.label}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center justify-between py-3 px-3.5 text-sm font-medium rounded-lg transition-colors ${
                      isActive
                        ? 'bg-[#FFF5EE] text-[#E85D3F] font-bold border-l-2 border-[#E85D3F]'
                        : 'text-neutral-800 hover:text-[#E85D3F] hover:bg-neutral-50'
                    }`}
                  >
                    <span>{link.label}</span>
                    <ArrowRight className={`w-4 h-4 ${isActive ? 'text-[#E85D3F]' : 'text-neutral-400'}`} />
                  </Link>
                );
              })}
            </nav>

            <div className="pt-4 border-t border-neutral-100 space-y-3">
              {/* Assistance Button in Mobile Drawer */}
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  handleOpenAssistance();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-lg bg-[#E85D3F] text-white text-sm font-display font-semibold hover:bg-[#D44E32] transition-colors shadow-sm cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Get Assistance</span>
              </button>

              <div className="flex items-center justify-center gap-2 text-xs text-neutral-500 font-body py-1">
                <Phone className="w-3.5 h-3.5 text-[#E85D3F]" />
                <span>Kolkata Property Advisory Hotline</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
