'use client';

import React from 'react';
import { IndianRupee, Info, AlertCircle } from 'lucide-react';
import { PriceIntelligenceDto, PriceMetricBasisSummaryDto } from '@/src/domain/marketIntelligence/dto/locationIntelligenceDto';
import { formatIndianPrice } from '@/src/components/discovery/formatters';

interface PricingIntelligenceSectionProps {
  locationName: string;
  pricing: PriceIntelligenceDto;
}

function PriceCard({
  title,
  subtitle,
  summary,
}: {
  title: string;
  subtitle: string;
  summary?: PriceMetricBasisSummaryDto | 'NO_DATA';
}) {
  if (!summary || summary === 'NO_DATA' || summary.sampleCount === 0) {
    return (
      <div className="bg-white border border-[rgba(17,17,17,0.08)] rounded-xl p-5 space-y-2 opacity-80">
        <span className="text-xs font-display font-semibold uppercase tracking-wider text-[#111111]/70">
          {title}
        </span>
        <div className="text-sm text-[#111111]/50 font-body py-3 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-neutral-400 shrink-0" />
          <span>Not enough verified data</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-[rgba(17,17,17,0.08)] rounded-xl p-5 space-y-3 hover:border-[rgba(17,17,17,0.18)] transition-all shadow-2xs">
      <div className="flex items-center justify-between border-b border-[rgba(17,17,17,0.06)] pb-2">
        <span className="text-xs font-display font-semibold uppercase tracking-wider text-[#111111]">
          {title}
        </span>
        <span className="text-[11px] font-mono text-[#111111]/50">
          {summary.sampleCount} {summary.sampleCount === 1 ? 'sample' : 'samples'}
        </span>
      </div>

      <div className="space-y-1">
        <div className="text-xl sm:text-2xl font-display font-bold text-[#111111]">
          ₹{summary.minRatePerSqft.toLocaleString('en-IN')} – ₹{summary.maxRatePerSqft.toLocaleString('en-IN')}
          <span className="text-xs font-body font-normal text-[#111111]/60"> / sq.ft.</span>
        </div>
        <div className="text-xs text-[#111111]/70 font-body flex items-center justify-between pt-1">
          <span>Median Rate:</span>
          <span className="font-semibold text-[#111111]">
            ₹{summary.medianRatePerSqft.toLocaleString('en-IN')} / sq.ft.
          </span>
        </div>
      </div>
    </div>
  );
}

export function PricingIntelligenceSection({
  locationName,
  pricing,
}: PricingIntelligenceSectionProps) {
  const hasData =
    pricing.status === 'CURRENT' &&
    pricing.newBooking &&
    (pricing.newBooking.carpetArea ||
      pricing.newBooking.builtUpArea ||
      pricing.newBooking.superBuiltUpArea);

  return (
    <section id="pricing" className="space-y-4 pt-8 border-t border-[rgba(17,17,17,0.08)]" aria-labelledby="pricing-heading">
      <div>
        <h2
          id="pricing-heading"
          className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight"
        >
          Property pricing in {locationName}
        </h2>
        <p className="text-xs sm:text-sm font-body text-[#111111]/60 mt-0.5">
          Factual price per square foot metrics categorized strictly by area measurement basis.
        </p>
      </div>

      {!hasData ? (
        <div className="p-6 rounded-xl border border-[rgba(17,17,17,0.08)] bg-white text-center space-y-2 max-w-xl mx-auto">
          <AlertCircle className="w-6 h-6 text-neutral-400 mx-auto" />
          <h3 className="text-sm font-display font-semibold text-[#111111]">
            Price data unavailable for {locationName}
          </h3>
          <p className="text-xs text-[#111111]/60 font-body">
            Not enough published project configuration data exists in this location to compute statistical price benchmarks.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <PriceCard
              title="Carpet Area Basis"
              subtitle="Net usable floor space"
              summary={pricing.newBooking?.carpetArea}
            />
            <PriceCard
              title="Built-Up Area Basis"
              subtitle="Carpet area + wall thickness"
              summary={pricing.newBooking?.builtUpArea}
            />
            <PriceCard
              title="Super Built-Up Area Basis"
              subtitle="Includes proportional common area"
              summary={pricing.newBooking?.superBuiltUpArea}
            />
          </div>

          {/* Pricing Disclaimer */}
          <div className="flex items-start gap-2 p-3.5 rounded-xl bg-[#FAFAF8] border border-[rgba(17,17,17,0.06)] text-xs text-[#111111]/70 font-body">
            <Info className="w-4 h-4 text-[#111111]/50 shrink-0 mt-0.5" />
            <span>
              Pricing shown is based on verified Great Homes project data and may vary by project, configuration and area basis.
            </span>
          </div>
        </div>
      )}
    </section>
  );
}
