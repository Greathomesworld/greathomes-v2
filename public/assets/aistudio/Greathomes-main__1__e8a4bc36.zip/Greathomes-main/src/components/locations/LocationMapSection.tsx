import React from 'react';
import { ProjectLocationMap } from '@/src/components/projects/ProjectLocationMap';
import { MapCoordinates } from '@/src/domain/locations/map/types';

interface LocationMapSectionProps {
  locationName: string;
  coordinates: MapCoordinates | null;
  hasValidCoordinates: boolean;
}

export function LocationMapSection({
  locationName,
  coordinates,
  hasValidCoordinates,
}: LocationMapSectionProps) {
  if (!hasValidCoordinates || !coordinates) {
    return null;
  }

  return (
    <section className="space-y-3.5 sm:space-y-4 pt-8 border-t border-[rgba(17,17,17,0.08)]" aria-labelledby="location-map-heading">
      <div>
        <h2
          id="location-map-heading"
          className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight"
        >
          Geographic Positioning
        </h2>
        <p className="text-xs sm:text-sm font-body text-[#111111]/60 mt-0.5 sm:mt-1">
          Cartographic coordinates and spatial alignment for {locationName}.
        </p>
      </div>

      <ProjectLocationMap
        coordinates={coordinates}
        projectName={locationName}
        locationName={locationName}
      />
    </section>
  );
}
