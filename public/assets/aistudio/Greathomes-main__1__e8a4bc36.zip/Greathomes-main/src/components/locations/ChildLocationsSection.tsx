import React from 'react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { ChildLocationCardDto } from '@/src/domain/locations/viewModels/locationPageViewModel';

interface ChildLocationsSectionProps {
  childrenLocations: ChildLocationCardDto[];
  title: string;
  subtitle: string;
  parentName: string;
}

export function ChildLocationsSection({
  childrenLocations,
  title,
  subtitle,
  parentName: _parentName,
}: ChildLocationsSectionProps) {
  if (!childrenLocations || childrenLocations.length === 0) {
    return null;
  }

  return (
    <section className="space-y-4 sm:space-y-5 pt-8 border-t border-[rgba(17,17,17,0.08)]" aria-labelledby="child-locations-heading">
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
        <div>
          <h2
            id="child-locations-heading"
            className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight"
          >
            {title}
          </h2>
          <p className="text-xs sm:text-sm font-body text-[#111111]/60 mt-0.5 sm:mt-1">
            {subtitle}
          </p>
        </div>
        <div className="text-xs font-mono text-[#111111]/50 shrink-0">
          {childrenLocations.length} {childrenLocations.length === 1 ? 'Location' : 'Locations'}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
        {childrenLocations.map(child => (
          <Link
            key={child.id}
            href={child.href}
            className="p-4 sm:p-5 rounded-xl border border-[rgba(17,17,17,0.08)] bg-white hover:border-[rgba(17,17,17,0.25)] hover:shadow-md transition-all group flex flex-col justify-between shadow-2xs focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F]"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-display uppercase tracking-wider text-[#111111]/50 font-semibold">
                  {child.levelDisplay}
                </span>
                {child.projectCount > 0 && (
                  <span className="text-[10px] font-display font-medium text-[#E85D3F] bg-[#E85D3F]/10 px-2 py-0.5 rounded">
                    {child.projectCount} {child.projectCount === 1 ? 'Project' : 'Projects'}
                  </span>
                )}
              </div>

              <h3 className="text-sm sm:text-base font-display font-semibold text-[#111111] group-hover:text-[#E85D3F] transition-colors leading-snug">
                {child.name}
              </h3>

              {(child.shortDescription || child.description) && (
                <p className="text-xs font-body text-[#111111]/70 line-clamp-2">
                  {child.shortDescription || child.description}
                </p>
              )}
            </div>

            <div className="mt-3.5 sm:mt-4 pt-3 border-t border-[rgba(17,17,17,0.06)] flex items-center justify-between text-xs font-display font-medium text-[#111111]/70 group-hover:text-[#E85D3F] transition-colors">
              <span>{`Explore ${child.name}`}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
