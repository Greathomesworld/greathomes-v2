'use client';

import React from 'react';
import Link from 'next/link';
import { Building2, Home, Key, ArrowRight } from 'lucide-react';

interface ExploreModesBarProps {
  locationSlug: string;
  locationName: string;
}

export function ExploreModesBar({ locationSlug, locationName }: ExploreModesBarProps) {
  return (
    <section className="bg-white border border-[rgba(17,17,17,0.08)] rounded-2xl p-5 sm:p-6 shadow-2xs space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
        <h2 className="text-base sm:text-lg font-display font-semibold text-[#111111]">
          Explore residential homes in {locationName}
        </h2>
        <span className="text-xs text-[#111111]/60 font-body">
          Direct navigation to verified discovery modes
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* New Launches */}
        <a
          href="#projects"
          className="group flex items-center justify-between p-4 rounded-xl bg-[#FAFAF8] border border-[rgba(17,17,17,0.08)] hover:border-[#111111] hover:bg-white transition-all cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-[#111111] text-white">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <span className="block font-display font-semibold text-sm text-[#111111] group-hover:text-[#E85D3F] transition-colors">
                New Launches
              </span>
              <span className="text-xs text-[#111111]/60">Projects & Bookings</span>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-[#111111]/40 group-hover:text-[#111111] group-hover:translate-x-0.5 transition-all" />
        </a>

        {/* Resale */}
        <a
          href="#resale"
          className="group flex items-center justify-between p-4 rounded-xl bg-[#FAFAF8] border border-[rgba(17,17,17,0.08)] hover:border-[#111111] hover:bg-white transition-all cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-[#E85D3F] text-white">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <span className="block font-display font-semibold text-sm text-[#111111] group-hover:text-[#E85D3F] transition-colors">
                Resale Homes
              </span>
              <span className="text-xs text-[#111111]/60">Verified Listings</span>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-[#111111]/40 group-hover:text-[#111111] group-hover:translate-x-0.5 transition-all" />
        </a>

        {/* Rent */}
        <a
          href="#rent"
          className="group flex items-center justify-between p-4 rounded-xl bg-[#FAFAF8] border border-[rgba(17,17,17,0.08)] hover:border-[#111111] hover:bg-white transition-all cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-[#218C5A] text-white">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <span className="block font-display font-semibold text-sm text-[#111111] group-hover:text-[#218C5A] transition-colors">
                Rental Homes
              </span>
              <span className="text-xs text-[#111111]/60">Monthly Rentals</span>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-[#111111]/40 group-hover:text-[#111111] group-hover:translate-x-0.5 transition-all" />
        </a>
      </div>
    </section>
  );
}
