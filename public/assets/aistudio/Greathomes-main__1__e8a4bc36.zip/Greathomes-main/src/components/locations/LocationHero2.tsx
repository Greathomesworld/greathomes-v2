'use client';

import React from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { ArrowRight, ShieldCheck, Scale } from 'lucide-react';
import { PublicLocationIntelligenceLocationDto, MarketOverviewDto } from '@/src/domain/marketIntelligence/dto/locationIntelligenceDto';
import { WatchLocationButton } from '../customer/WatchLocationButton';
import { EnquiryTriggerButton } from '../enquiry/EnquiryTriggerButton';

interface LocationHero2Props {
  location: PublicLocationIntelligenceLocationDto;
  marketOverview: MarketOverviewDto;
  activeScope: 'DIRECT' | 'DESCENDANT';
  hasChildLocations?: boolean;
}

export function LocationHero2({
  location,
  marketOverview,
  activeScope,
  hasChildLocations = false,
}: LocationHero2Props) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const scopeLabelDirect = location.level === 'CITY' ? 'Direct City' : 'Direct Area';
  const scopeLabelDescendant = location.level === 'CITY' ? 'Including All Sub-areas' : 'Including Nearby Areas';

  const handleScopeToggle = (scope: 'DIRECT' | 'DESCENDANT') => {
    const params = new URLSearchParams(searchParams.toString());
    if (scope === 'DIRECT') {
      params.set('scope', 'DIRECT');
    } else {
      params.delete('scope');
    }
    router.push(`/locations/${location.slug}${params.toString() ? `?${params.toString()}` : ''}`, { scroll: false });
  };

  return (
    <section className="relative bg-white border border-[rgba(17,17,17,0.08)] rounded-2xl overflow-hidden shadow-2xs">
      <div className="p-6 sm:p-8 lg:p-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Headline & Controls */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-[#FAFAF8] text-[#111111] border border-[rgba(17,17,17,0.12)]">
                  {location.levelDisplay || location.level}
                </span>
                {location.city && (
                  <span className="text-xs text-neutral-500 font-medium">
                    in {location.city}
                  </span>
                )}
                <div className="inline-flex items-center gap-1 text-xs text-[#218C5A] font-medium bg-[#218C5A]/10 px-2.5 py-0.5 rounded-full border border-[#218C5A]/20">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Verified Location</span>
                </div>
              </div>

              <h1 className="font-editorial text-3xl sm:text-4xl lg:text-5xl font-normal tracking-tight text-[#111111] leading-tight">
                {location.name}
              </h1>

              <p className="text-base sm:text-lg text-neutral-600 font-body leading-relaxed max-w-2xl">
                {location.description ||
                  `Explore verified residential projects, resale homes, rental properties and property intelligence across ${location.name}.`}
              </p>
            </div>

            {/* Scope Selector if child locations exist */}
            {hasChildLocations && (
              <div className="flex items-center gap-2 pt-1">
                <span className="text-xs font-medium text-neutral-500 uppercase tracking-wider">Scope:</span>
                <div className="inline-flex p-1 bg-[#FAFAF8] border border-[rgba(17,17,17,0.08)] rounded-xl">
                  <button
                    type="button"
                    onClick={() => handleScopeToggle('DIRECT')}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                      activeScope === 'DIRECT'
                        ? 'bg-white text-[#111111] shadow-xs font-semibold'
                        : 'text-neutral-600 hover:text-[#111111]'
                    }`}
                  >
                    {scopeLabelDirect}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleScopeToggle('DESCENDANT')}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
                      activeScope === 'DESCENDANT'
                        ? 'bg-white text-[#111111] shadow-xs font-semibold'
                        : 'text-neutral-600 hover:text-[#111111]'
                    }`}
                  >
                    {scopeLabelDescendant}
                  </button>
                </div>
              </div>
            )}

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <a
                href="#projects"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#111111] text-white font-medium text-sm hover:bg-[#222222] transition-colors shadow-xs cursor-pointer"
              >
                <span>Explore Projects</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <a
                href="#resale"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-[#111111] border border-[rgba(17,17,17,0.15)] font-medium text-sm hover:bg-[#FAFAF8] transition-colors cursor-pointer"
              >
                <span>View Resale</span>
              </a>

              <a
                href="#rent"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-[#111111] border border-[rgba(17,17,17,0.15)] font-medium text-sm hover:bg-[#FAFAF8] transition-colors cursor-pointer"
              >
                <span>View Rentals</span>
              </a>

              <WatchLocationButton
                locationId={location.id}
                locationName={location.name}
                variant="outline"
                size="md"
              />

              <Link
                href={`/compare/locations?locations=${location.slug},${location.slug === 'new-town' ? 'rajarhat' : 'new-town'}`}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white text-[#111111] border border-[rgba(17,17,17,0.15)] font-medium text-sm hover:bg-[#FAFAF8] transition-colors cursor-pointer min-h-[44px]"
                title="Compare with adjacent corridor"
              >
                <Scale className="w-4 h-4 text-stone-500" />
                <span>Compare</span>
              </Link>

              <EnquiryTriggerButton
                contextData={{
                  contextType: 'GENERAL',
                  title: `Enquiry for ${location.name}`,
                  locationName: location.name,
                }}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#E85D3F] text-white font-medium text-sm hover:bg-[#d44d31] transition-colors shadow-2xs cursor-pointer min-h-[44px]"
              >
                <span>Get Price & Availability</span>
              </EnquiryTriggerButton>
            </div>
          </div>

          {/* Right Column: Hero Visual Photography */}
          <div className="lg:col-span-5">
            <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-neutral-900 border border-[rgba(17,17,17,0.12)] shadow-sm">
              <img
                src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&w=1200&q=80"
                alt={location.name}
                className="w-full h-full object-cover opacity-90 hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

              <div className="absolute bottom-4 left-4 right-4 p-4 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 text-white">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-neutral-300 font-medium">{location.name} Overview</span>
                  <span className="flex items-center gap-1 text-[#218C5A] font-semibold bg-[#218C5A]/20 px-2 py-0.5 rounded-md">
                    <ShieldCheck className="w-3 h-3" />
                    Verified Market
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center pt-2 border-t border-white/10">
                  <div>
                    <span className="block font-display font-bold text-base">{marketOverview.publishedProjects}</span>
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider">Projects</span>
                  </div>
                  <div>
                    <span className="block font-display font-bold text-base">{marketOverview.resaleListings}</span>
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider">Resale</span>
                  </div>
                  <div>
                    <span className="block font-display font-bold text-base">{marketOverview.rentalListings}</span>
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider">Rentals</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
