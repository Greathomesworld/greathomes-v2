'use client';

import React from 'react';
import { Building2, Home, Key, ShieldCheck, Clock, CheckCircle2 } from 'lucide-react';
import { MarketOverviewDto, ReraIntelligenceDto } from '@/src/domain/marketIntelligence/dto/locationIntelligenceDto';
import { MarketFreshnessInfo } from '@/src/domain/marketIntelligence/entities';

interface MarketSnapshotSectionProps {
  locationName: string;
  marketOverview: MarketOverviewDto;
  rera: ReraIntelligenceDto;
  freshness: MarketFreshnessInfo;
}

export function MarketSnapshotSection({
  locationName,
  marketOverview,
  rera,
  freshness,
}: MarketSnapshotSectionProps) {
  const isStale = freshness.freshnessStatus === 'STALE';
  const formattedDate = freshness.dataAsOf
    ? new Date(freshness.dataAsOf).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })
    : 'recently';

  return (
    <section id="overview" className="space-y-4 pt-4" aria-labelledby="market-snapshot-heading">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[rgba(17,17,17,0.08)] pb-3">
        <div>
          <h2
            id="market-snapshot-heading"
            className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight"
          >
            Factual Market Snapshot
          </h2>
          <p className="text-xs sm:text-sm font-body text-[#111111]/60 mt-0.5">
            Verified property supply and regulatory coverage across {locationName}.
          </p>
        </div>

        {/* Freshness Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-[#FAFAF8] border border-[rgba(17,17,17,0.08)] text-[#111111]/80 shrink-0">
          <Clock className={`w-3.5 h-3.5 ${isStale ? 'text-amber-500' : 'text-[#218C5A]'}`} />
          <span>
            {isStale
              ? `Data last updated ${formattedDate}`
              : `Data updated ${formattedDate}`}
          </span>
        </div>
      </div>

      {/* Primary 4-6 Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
        {/* Published Projects */}
        <div className="bg-white border border-[rgba(17,17,17,0.08)] rounded-xl p-4 sm:p-5 flex flex-col justify-between space-y-2 hover:border-[rgba(17,17,17,0.18)] transition-all shadow-2xs">
          <div className="flex items-center justify-between text-[#111111]/60">
            <span className="text-xs font-display font-medium uppercase tracking-wider">
              Published Projects
            </span>
            <div className="p-2 rounded-lg bg-[rgba(17,17,17,0.04)] text-[#111111]">
              <Building2 className="w-4 h-4" />
            </div>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-display font-bold text-[#111111]">
              {marketOverview.publishedProjects}
            </span>
            <span className="text-xs text-[#111111]/60 font-body">
              Verified developments
            </span>
          </div>
        </div>

        {/* Resale Homes */}
        <div className="bg-white border border-[rgba(17,17,17,0.08)] rounded-xl p-4 sm:p-5 flex flex-col justify-between space-y-2 hover:border-[rgba(17,17,17,0.18)] transition-all shadow-2xs">
          <div className="flex items-center justify-between text-[#111111]/60">
            <span className="text-xs font-display font-medium uppercase tracking-wider">
              Resale Homes
            </span>
            <div className="p-2 rounded-lg bg-[rgba(17,17,17,0.04)] text-[#E85D3F]">
              <Home className="w-4 h-4" />
            </div>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-display font-bold text-[#111111]">
              {marketOverview.resaleListings}
            </span>
            <span className="text-xs text-[#111111]/60 font-body">
              Available properties
            </span>
          </div>
        </div>

        {/* Rental Homes */}
        <div className="bg-white border border-[rgba(17,17,17,0.08)] rounded-xl p-4 sm:p-5 flex flex-col justify-between space-y-2 hover:border-[rgba(17,17,17,0.18)] transition-all shadow-2xs">
          <div className="flex items-center justify-between text-[#111111]/60">
            <span className="text-xs font-display font-medium uppercase tracking-wider">
              Rental Homes
            </span>
            <div className="p-2 rounded-lg bg-[rgba(17,17,17,0.04)] text-[#111111]">
              <Key className="w-4 h-4" />
            </div>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-display font-bold text-[#111111]">
              {marketOverview.rentalListings}
            </span>
            <span className="text-xs text-[#111111]/60 font-body">
              Active listings
            </span>
          </div>
        </div>

        {/* RERA Verified */}
        <div className="bg-white border border-[rgba(17,17,17,0.08)] rounded-xl p-4 sm:p-5 flex flex-col justify-between space-y-2 hover:border-[#218C5A]/30 transition-all shadow-2xs">
          <div className="flex items-center justify-between text-[#218C5A]">
            <span className="text-xs font-display font-medium uppercase tracking-wider text-[#111111]/60">
              RERA Verified
            </span>
            <div className="p-2 rounded-lg bg-[#218C5A]/10 text-[#218C5A]">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div>
            <span className="block text-2xl sm:text-3xl font-display font-bold text-[#111111]">
              {rera.verifiedReraProjects}
            </span>
            <span className="text-xs text-[#218C5A] font-body font-medium flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              Official clearance
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
