import React from 'react';
import Link from 'next/link';
import { ShieldCheck, Building2, Layers } from 'lucide-react';
import { LocationPageViewModel } from '@/src/domain/locations/viewModels/locationPageViewModel';

interface LocationHeroProps {
  viewModel: LocationPageViewModel;
}

export function LocationHero({ viewModel }: LocationHeroProps) {
  const {
    name,
    levelDisplay,
    breadcrumb,
    description,
    shortDescription,
    projectCount,
    children,
  } = viewModel;

  // Ancestor path excluding the current location
  const ancestors = breadcrumb.slice(0, -1);

  return (
    <header className="space-y-3.5 sm:space-y-4 max-w-4xl">
      {/* Eyebrow / Badges */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="px-2.5 py-1 rounded-md bg-[rgba(17,17,17,0.05)] border border-[rgba(17,17,17,0.1)] text-xs font-display uppercase tracking-wider text-[#111111] font-semibold">
          {levelDisplay}
        </span>
        <div className="inline-flex items-center gap-1 text-xs text-[#218C5A] font-medium bg-[#218C5A]/10 px-2.5 py-1 rounded-md border border-[#218C5A]/20">
          <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
          <span>Verified Location</span>
        </div>
      </div>

      {/* Editorial Location Title (Playfair Display) */}
      <h1 className="text-2xl sm:text-4xl lg:text-5xl font-editorial font-normal text-[#111111] tracking-tight leading-tight break-words">
        {name}
      </h1>

      {/* Actual Persisted Contextual Ancestry */}
      {ancestors.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 text-xs sm:text-sm font-body text-[#111111]/70 break-words">
          <span>Located in</span>
          {ancestors.map((node, index) => (
            <React.Fragment key={node.id}>
              <Link
                href={node.href}
                className="font-medium text-[#111111] hover:text-[#E85D3F] hover:underline transition-colors focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F] rounded"
              >
                {node.name}
              </Link>
              {index < ancestors.length - 1 && (
                <span className="text-[#111111]/30">›</span>
              )}
            </React.Fragment>
          ))}
        </div>
      )}

      {/* Factual Highlights (Zero fabricated metrics) */}
      <div className="flex flex-wrap items-center gap-2 sm:gap-3 pt-1">
        {projectCount > 0 && (
          <div className="inline-flex items-center gap-1.5 text-xs font-display font-medium text-[#111111]/80 bg-white border border-[rgba(17,17,17,0.08)] px-2.5 sm:px-3 py-1.5 rounded-lg shadow-2xs">
            <Building2 className="w-3.5 h-3.5 text-[#E85D3F] shrink-0" />
            <span>
              {projectCount} {projectCount === 1 ? 'Residential Project' : 'Residential Projects'}
            </span>
          </div>
        )}

        {children.length > 0 && (
          <div className="inline-flex items-center gap-1.5 text-xs font-display font-medium text-[#111111]/80 bg-white border border-[rgba(17,17,17,0.08)] px-2.5 sm:px-3 py-1.5 rounded-lg shadow-2xs">
            <Layers className="w-3.5 h-3.5 text-[#111111]/60 shrink-0" />
            <span>
              {children.length} {children.length === 1 ? 'Sub-Location' : 'Sub-Locations'}
            </span>
          </div>
        )}
      </div>

      {/* Published Editorial Description */}
      {(description || shortDescription) && (
        <p className="text-xs sm:text-sm md:text-base font-body text-[#111111]/80 leading-relaxed pt-2 max-w-3xl">
          {description || shortDescription}
        </p>
      )}
    </header>
  );
}
