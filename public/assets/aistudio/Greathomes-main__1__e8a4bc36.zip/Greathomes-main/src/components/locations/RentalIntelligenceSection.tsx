'use client';

import React from 'react';
import Link from 'next/link';
import { Key, ArrowRight } from 'lucide-react';
import { RentDiscoveryCardDto } from '@/src/domain/projects/dto/discoveryDto';
import { PropertyCard } from '@/src/components/discovery/PropertyCard';

interface RentalIntelligenceSectionProps {
  locationName: string;
  locationSlug: string;
  rentalListings: RentDiscoveryCardDto[];
}

export function RentalIntelligenceSection({
  locationName,
  locationSlug,
  rentalListings,
}: RentalIntelligenceSectionProps) {
  const displayedListings = rentalListings.slice(0, 6);

  return (
    <section id="rent" className="space-y-5 pt-8 border-t border-[rgba(17,17,17,0.08)]" aria-labelledby="rental-heading">
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
        <div>
          <h2
            id="rental-heading"
            className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight"
          >
            Rental homes in {locationName}
          </h2>
          <p className="text-xs sm:text-sm font-body text-[#111111]/60 mt-0.5">
            Verified monthly residential rental properties in {locationName}.
          </p>
        </div>
        <div className="text-xs font-mono text-[#111111]/50 shrink-0">
          {rentalListings.length} {rentalListings.length === 1 ? 'Rental Home' : 'Rental Homes'}
        </div>
      </div>

      {displayedListings.length === 0 ? (
        <div className="p-8 sm:p-12 rounded-xl border border-[rgba(17,17,17,0.08)] bg-white text-center space-y-3.5 max-w-2xl mx-auto shadow-2xs">
          <div className="w-12 h-12 rounded-full bg-[rgba(17,17,17,0.04)] flex items-center justify-center mx-auto text-[#111111]/50">
            <Key className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <h3 className="text-sm sm:text-base font-display font-semibold text-[#111111]">
              No rental homes currently listed in {locationName}
            </h3>
            <p className="text-xs sm:text-sm font-body text-[#111111]/60 max-w-md mx-auto">
              Verified rental properties will appear here as property owners submit listings in {locationName}.
            </p>
          </div>

          <div className="pt-1">
            <a
              href="#projects"
              className="inline-flex items-center gap-1.5 text-xs font-display font-semibold text-[#E85D3F] hover:underline cursor-pointer"
            >
              <span>Explore primary projects in {locationName}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {displayedListings.map((listing) => (
            <PropertyCard
              key={`rental-${listing.id}`}
              item={listing}
            />
          ))}
        </div>
      )}

      {rentalListings.length > 0 && (
        <div className="flex justify-center pt-2">
          <Link
            href={`/rent?location=${locationSlug}`}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white border border-[rgba(17,17,17,0.15)] text-[#111111] font-display font-medium text-sm hover:bg-[#FAFAF8] hover:border-[#111111] transition-all shadow-2xs"
          >
            <span>View All {rentalListings.length} Rental Homes in {locationName}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      )}
    </section>
  );
}
