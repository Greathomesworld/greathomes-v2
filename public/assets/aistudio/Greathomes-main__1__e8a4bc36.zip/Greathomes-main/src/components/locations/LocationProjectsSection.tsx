'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Building2, ArrowRight } from 'lucide-react';
import { ProjectDiscoveryCardDto } from '@/src/domain/projects/dto/discoveryDto';
import { PropertyCard } from '@/src/components/discovery/PropertyCard';

interface LocationProjectsSectionProps {
  locationName: string;
  locationSlug: string;
  projects: ProjectDiscoveryCardDto[];
}

const STAGE_FILTERS = [
  { id: 'ALL', label: 'All' },
  { id: 'NEW_LAUNCH', label: 'New Launch' },
  { id: 'UNDER_CONSTRUCTION', label: 'Under Construction' },
  { id: 'READY_TO_MOVE', label: 'Ready to Move' },
  { id: 'COMPLETED', label: 'Completed' },
  { id: 'SOLD_OUT', label: 'Sold Out' },
];

export function LocationProjectsSection({
  locationName,
  locationSlug,
  projects,
}: LocationProjectsSectionProps) {
  const [activeStage, setActiveStage] = useState<string>('ALL');

  const filteredProjects = projects.filter((p) => {
    if (activeStage === 'ALL') return true;
    return (p as any).lifecycleStatus === activeStage || (p as any).stage === activeStage;
  });

  const displayedProjects = filteredProjects.slice(0, 6);

  return (
    <section id="projects" className="space-y-5 pt-8 border-t border-[rgba(17,17,17,0.08)]" aria-labelledby="projects-heading">
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
        <div>
          <h2
            id="projects-heading"
            className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight"
          >
            Residential Projects in {locationName}
          </h2>
          <p className="text-xs sm:text-sm font-body text-[#111111]/60 mt-0.5">
            Verified master developments, configurations, and pricing intelligence in {locationName}.
          </p>
        </div>
        <div className="text-xs font-mono text-[#111111]/50 shrink-0">
          {projects.length} {projects.length === 1 ? 'Project' : 'Projects'}
        </div>
      </div>

      {/* Stage Filter Chips */}
      {projects.length > 0 && (
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
          {STAGE_FILTERS.map((filter) => {
            const isActive = activeStage === filter.id;
            return (
              <button
                key={filter.id}
                type="button"
                onClick={() => setActiveStage(filter.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#111111] text-white font-semibold shadow-xs'
                    : 'bg-[#FAFAF8] text-[#111111]/70 border border-[rgba(17,17,17,0.08)] hover:bg-neutral-100 hover:text-[#111111]'
                }`}
              >
                {filter.label}
              </button>
            );
          })}
        </div>
      )}

      {/* Grid or Empty State */}
      {displayedProjects.length === 0 ? (
        <div className="p-8 sm:p-12 rounded-xl border border-[rgba(17,17,17,0.08)] bg-white text-center space-y-3.5 max-w-2xl mx-auto shadow-2xs">
          <div className="w-12 h-12 rounded-full bg-[rgba(17,17,17,0.04)] flex items-center justify-center mx-auto text-[#111111]/40">
            <Building2 className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <h3 className="text-sm sm:text-base font-display font-semibold text-[#111111]">
              No projects currently listed in {locationName}
            </h3>
            <p className="text-xs sm:text-sm font-body text-[#111111]/60 max-w-md mx-auto">
              Verified residential developments in {locationName} will appear here as they achieve regulatory clearance and publication.
            </p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {displayedProjects.map((project) => (
            <PropertyCard
              key={`location-project-${project.id}`}
              item={project}
            />
          ))}
        </div>
      )}

      {/* View All Projects CTA */}
      {projects.length > 0 && (
        <div className="flex justify-center pt-2">
          <Link
            href={`/projects?location=${locationSlug}`}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white border border-[rgba(17,17,17,0.15)] text-[#111111] font-display font-medium text-sm hover:bg-[#FAFAF8] hover:border-[#111111] transition-all shadow-2xs"
          >
            <span>View All {projects.length} Projects in {locationName}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      )}
    </section>
  );
}
