'use client';

import React from 'react';
import Link from 'next/link';
import { Home, ArrowRight } from 'lucide-react';
import { ResaleDiscoveryCardDto } from '@/src/domain/projects/dto/discoveryDto';
import { PropertyCard } from '@/src/components/discovery/PropertyCard';

interface ResaleIntelligenceSectionProps {
  locationName: string;
  locationSlug: string;
  resaleListings: ResaleDiscoveryCardDto[];
}

export function ResaleIntelligenceSection({
  locationName,
  locationSlug,
  resaleListings,
}: ResaleIntelligenceSectionProps) {
  const displayedListings = resaleListings.slice(0, 6);

  return (
    <section id="resale" className="space-y-5 pt-8 border-t border-[rgba(17,17,17,0.08)]" aria-labelledby="resale-heading">
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1">
        <div>
          <h2
            id="resale-heading"
            className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight"
          >
            Resale homes in {locationName}
          </h2>
          <p className="text-xs sm:text-sm font-body text-[#111111]/60 mt-0.5">
            Verified resale apartments and individual homes listed in {locationName}.
          </p>
        </div>
        <div className="text-xs font-mono text-[#111111]/50 shrink-0">
          {resaleListings.length} {resaleListings.length === 1 ? 'Resale Home' : 'Resale Homes'}
        </div>
      </div>

      {displayedListings.length === 0 ? (
        <div className="p-8 sm:p-12 rounded-xl border border-[rgba(17,17,17,0.08)] bg-white text-center space-y-3.5 max-w-2xl mx-auto shadow-2xs">
          <div className="w-12 h-12 rounded-full bg-[rgba(17,17,17,0.04)] flex items-center justify-center mx-auto text-[#E85D3F]">
            <Home className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <h3 className="text-sm sm:text-base font-display font-semibold text-[#111111]">
              No resale homes are currently listed in {locationName}
            </h3>
            <p className="text-xs sm:text-sm font-body text-[#111111]/60 max-w-md mx-auto">
              Verified resale listings will appear here as property owners and partners submit properties in {locationName}.
            </p>
          </div>

          <div className="pt-1">
            <a
              href="#projects"
              className="inline-flex items-center gap-1.5 text-xs font-display font-semibold text-[#E85D3F] hover:underline cursor-pointer"
            >
              <span>Explore primary projects in {locationName}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {displayedListings.map((listing) => (
            <PropertyCard
              key={`resale-${listing.id}`}
              item={listing}
            />
          ))}
        </div>
      )}

      {resaleListings.length > 0 && (
        <div className="flex justify-center pt-2">
          <Link
            href={`/buy?location=${locationSlug}`}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white border border-[rgba(17,17,17,0.15)] text-[#111111] font-display font-medium text-sm hover:bg-[#FAFAF8] hover:border-[#111111] transition-all shadow-2xs"
          >
            <span>View All {resaleListings.length} Resale Homes in {locationName}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      )}
    </section>
  );
}
