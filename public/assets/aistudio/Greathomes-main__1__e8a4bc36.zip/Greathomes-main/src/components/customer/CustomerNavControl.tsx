'use client';

import React, { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { User, Bookmark, History, Sliders, LogOut, ChevronDown } from 'lucide-react';
import { useCustomerAuth } from './CustomerAuthContext';

export function CustomerNavControl() {
  const { customer, loading, openAuthModal, logout } = useCustomerAuth();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (loading) {
    return (
      <div className="h-9 w-20 bg-slate-100 animate-pulse rounded-md" />
    );
  }

  if (!customer) {
    return (
      <button
        onClick={() => openAuthModal('login')}
        className="px-4 py-2 text-sm font-semibold text-slate-800 hover:text-slate-900 border border-slate-300 hover:border-slate-400 rounded-md transition-colors font-display"
      >
        Sign In
      </button>
    );
  }

  const initials = customer.name
    ? customer.name
        .split(' ')
        .map((n) => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase()
    : 'U';

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 p-1.5 rounded-md hover:bg-slate-100 transition-colors"
        aria-expanded={isOpen}
      >
        <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-semibold font-display">
          {initials}
        </div>
        <span className="text-sm font-medium text-slate-800 hidden sm:inline-block font-display max-w-[120px] truncate">
          {customer.name}
        </span>
        <ChevronDown className="w-4 h-4 text-slate-500" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-white border border-slate-200 shadow-xl rounded-lg py-2 z-50">
          <div className="px-4 py-2 border-b border-slate-100">
            <p className="text-sm font-semibold text-slate-900 font-display truncate">
              {customer.name}
            </p>
            <p className="text-xs text-slate-500 font-body truncate">{customer.email}</p>
          </div>

          <div className="py-1">
            <Link
              href="/account/saved"
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 transition-colors font-body"
            >
              <Bookmark className="w-4 h-4 text-slate-500" />
              <span>Saved Homes & Projects</span>
            </Link>

            <Link
              href="/account/recently-viewed"
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 transition-colors font-body"
            >
              <History className="w-4 h-4 text-slate-500" />
              <span>Recently Viewed</span>
            </Link>

            <Link
              href="/account/preferences"
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 transition-colors font-body"
            >
              <Sliders className="w-4 h-4 text-slate-500" />
              <span>Search Preferences & Alerts</span>
            </Link>

            <Link
              href="/account/profile"
              onClick={() => setIsOpen(false)}
              className="flex items-center gap-3 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 transition-colors font-body"
            >
              <User className="w-4 h-4 text-slate-500" />
              <span>Profile Settings</span>
            </Link>
          </div>

          <div className="border-t border-slate-100 pt-1">
            <button
              onClick={() => {
                setIsOpen(false);
                logout();
              }}
              className="flex items-center gap-3 w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors font-body cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
