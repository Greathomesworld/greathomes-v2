'use client';

import { useEffect } from 'react';
import { SavedItemResourceType } from '@/src/domain/customer/entities';
import { useCustomerAuth } from './CustomerAuthContext';

interface RecentlyViewedTrackerProps {
  resourceType: SavedItemResourceType;
  resourceId: string;
}

export function RecentlyViewedTracker({
  resourceType,
  resourceId,
}: RecentlyViewedTrackerProps) {
  const { customer } = useCustomerAuth();

  useEffect(() => {
    if (!customer || !resourceId) return;

    // Record view asynchronously after page loads
    const timer = setTimeout(() => {
      fetch('/api/customer/recently-viewed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resourceType, resourceId }),
      }).catch(() => {});
    }, 1000);

    return () => clearTimeout(timer);
  }, [customer, resourceType, resourceId]);

  return null;
}
