'use client';

import React, { useState, useEffect, useRef, useId } from 'react';
import { Search, X, MapPin, Building, Briefcase, ArrowRight, Loader2, ChevronDown, Check } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

interface SuggestionItem {
  id: string;
  type: 'PROJECT' | 'DEVELOPER' | 'LOCATION' | 'RESALE' | 'RENTAL';
  title: string;
  subtitle?: string;
  slug: string;
  url: string;
  imageUrl?: string;
  priceDisplay?: string;
}

export type SearchDiscoveryMode = 'PROJECTS' | 'BUY' | 'RENT';

interface UniversalSearchProps {
  placeholder?: string;
  className?: string;
  defaultMode?: SearchDiscoveryMode;
  showDiscoveryModes?: boolean;
}

interface DropdownOption<T> {
  label: string;
  value: T;
}

interface CustomSearchDropdownProps<T extends string | number> {
  options: DropdownOption<T>[];
  value: T;
  onChange: (value: T) => void;
  ariaLabel: string;
  className?: string;
}

function CustomSearchDropdown<T extends string | number>({
  options,
  value,
  onChange,
  ariaLabel,
  className = '',
}: CustomSearchDropdownProps<T>) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find((opt) => opt.value === value) || options[0];

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  return (
    <div ref={dropdownRef} className={`relative flex-1 lg:flex-initial min-w-0 ${className}`}>
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        aria-label={ariaLabel}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        className={`w-full h-10 sm:h-11 flex items-center justify-between gap-1.5 bg-neutral-50 hover:bg-neutral-100/80 text-neutral-800 text-xs sm:text-sm font-display font-medium py-2 px-2.5 sm:px-3 rounded-xl border transition-all cursor-pointer select-none ${
          isOpen
            ? 'bg-white border-[#E85D3F] ring-2 ring-[#E85D3F]/20 shadow-xs'
            : 'border-neutral-200/80 hover:border-neutral-300'
        }`}
      >
        <span className="truncate text-left text-neutral-900 font-medium">
          {selectedOption ? selectedOption.label : ''}
        </span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-neutral-500 transition-transform duration-200 shrink-0 ${
            isOpen ? 'rotate-180 text-[#E85D3F]' : ''
          }`}
        />
      </button>

      {isOpen && (
        <div
          role="listbox"
          aria-label={ariaLabel}
          className="absolute left-0 right-0 lg:right-auto lg:min-w-[170px] top-full mt-1.5 bg-white border border-neutral-200/90 rounded-xl shadow-xl z-50 py-1 max-h-60 overflow-y-auto animate-fade-in"
        >
          {options.map((option) => {
            const isSelected = option.value === value;
            return (
              <button
                key={String(option.value)}
                type="button"
                role="option"
                aria-selected={isSelected}
                onClick={() => {
                  onChange(option.value);
                  setIsOpen(false);
                }}
                className={`w-full text-left flex items-center justify-between px-3 py-2 text-xs sm:text-sm font-display transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-orange-50/80 text-[#E85D3F] font-semibold'
                    : 'text-neutral-700 hover:bg-neutral-50 hover:text-neutral-900 font-medium'
                }`}
              >
                <span className="truncate">{option.label}</span>
                {isSelected && <Check className="w-3.5 h-3.5 text-[#E85D3F] shrink-0 ml-2" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

const BHK_OPTIONS = [
  { label: 'All BHK', value: '' },
  { label: '1 BHK', value: '1' },
  { label: '2 BHK', value: '2' },
  { label: '3 BHK', value: '3' },
  { label: '4 BHK', value: '4' },
  { label: '5+ BHK', value: '5' },
];

const BUY_BUDGET_OPTIONS = [
  { label: 'Any Budget', min: '', max: '' },
  { label: 'Under ₹50 L', min: '', max: '5000000' },
  { label: '₹50 L – ₹1 Cr', min: '5000000', max: '10000000' },
  { label: '₹1 Cr – ₹2 Cr', min: '10000000', max: '20000000' },
  { label: '₹2 Cr – ₹5 Cr', min: '20000000', max: '50000000' },
  { label: 'Above ₹5 Cr', min: '50000000', max: '' },
];

const RENT_BUDGET_OPTIONS = [
  { label: 'Any Rent', min: '', max: '' },
  { label: 'Under ₹20,000', min: '', max: '20000' },
  { label: '₹20k – ₹40k', min: '20000', max: '40000' },
  { label: '₹40k – ₹75k', min: '40000', max: '75000' },
  { label: '₹75k – ₹1.5 L', min: '75000', max: '150000' },
  { label: 'Above ₹1.5 L', min: '150000', max: '' },
];

export function UniversalSearch({
  placeholder = 'Location, project or developer',
  className = '',
  defaultMode = 'PROJECTS',
  showDiscoveryModes = true,
}: UniversalSearchProps) {
  const [activeMode, setActiveMode] = useState<SearchDiscoveryMode>(defaultMode);
  const [query, setQuery] = useState('');
  const [selectedBhk, setSelectedBhk] = useState('');
  const [selectedBudgetIndex, setSelectedBudgetIndex] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<{
    projects: SuggestionItem[];
    locations: SuggestionItem[];
    developers: SuggestionItem[];
  }>({ projects: [], locations: [], developers: [] });
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputId = useId();
  const router = useRouter();

  const currentBudgetOptions = activeMode === 'RENT' ? RENT_BUDGET_OPTIONS : BUY_BUDGET_OPTIONS;

  useEffect(() => {
    const saved = localStorage.getItem('gh_recent_searches');
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch {}
    }
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (!query || query.trim().length < 2) {
      setSuggestions({ projects: [], locations: [], developers: [] });
      setLoading(false);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/search/suggestions?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (data.success && data.suggestions) {
          setSuggestions(data.suggestions);
        }
      } catch (err) {
        console.error('Failed to fetch suggestions:', err);
      } finally {
        setLoading(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [query]);

  const executeSearch = (searchQuery: string) => {
    const trimmed = searchQuery.trim();
    if (trimmed) {
      const updated = [trimmed, ...recentSearches.filter((s) => s !== trimmed)].slice(0, 5);
      setRecentSearches(updated);
      localStorage.setItem('gh_recent_searches', JSON.stringify(updated));
    }

    setIsOpen(false);

    // Build URL according to verified route contracts
    const params = new URLSearchParams();
    if (trimmed) {
      params.append('q', trimmed);
    }
    if (selectedBhk) {
      params.append('bhk', selectedBhk);
    }
    const budget = currentBudgetOptions[selectedBudgetIndex];
    if (budget && budget.min) {
      params.append('minPrice', budget.min);
    }
    if (budget && budget.max) {
      params.append('maxPrice', budget.max);
    }

    let basePath = '/projects';
    if (activeMode === 'BUY') {
      basePath = '/buy';
      params.append('inventoryType', 'RESALE');
    } else if (activeMode === 'RENT') {
      basePath = '/rent';
    }

    const queryString = params.toString();
    router.push(queryString ? `${basePath}?${queryString}` : basePath);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(query);
  };

  const handleSelectRecent = (term: string) => {
    setQuery(term);
    executeSearch(term);
  };

  const clearRecent = () => {
    setRecentSearches([]);
    localStorage.removeItem('gh_recent_searches');
  };

  const hasSuggestions =
    suggestions.projects.length > 0 ||
    suggestions.locations.length > 0 ||
    suggestions.developers.length > 0;

  return (
    <div ref={containerRef} className={`w-full relative ${className}`}>
      {/* 1. Discovery Mode Tabs (Above Search Bar - Centered) */}
      {showDiscoveryModes && (
        <div className="flex items-center justify-center gap-2 sm:gap-2.5 mb-2.5 sm:mb-3 overflow-x-auto no-scrollbar pb-1 px-1">
          {[
            { id: 'PROJECTS' as const, label: 'Projects' },
            { id: 'BUY' as const, label: 'Buy Resale' },
            { id: 'RENT' as const, label: 'Rent' },
          ].map((mode) => {
            const isActive = activeMode === mode.id;
            return (
              <button
                key={mode.id}
                type="button"
                onClick={() => {
                  setActiveMode(mode.id);
                  setSelectedBudgetIndex(0); // Reset budget range to match mode currency scale
                }}
                className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-display font-bold transition-all duration-200 cursor-pointer whitespace-nowrap shrink-0 active:scale-95 ${
                  isActive
                    ? 'bg-[#E85D3F] text-white shadow-md ring-2 ring-[#E85D3F]/20'
                    : 'bg-white/95 hover:bg-white text-neutral-700 hover:text-neutral-900 border border-neutral-200/90 shadow-2xs hover:border-neutral-300'
                }`}
              >
                {mode.label}
              </button>
            );
          })}
        </div>
      )}

      {/* 2. Compact Search Presentation Container */}
      <div className="relative bg-white rounded-2xl shadow-md border border-neutral-200/90 p-2.5 sm:p-3 lg:p-3.5 transition-all focus-within:ring-2 focus-within:ring-[#E85D3F]/60 focus-within:border-[#E85D3F]">
        <form onSubmit={handleSearchSubmit} className="flex flex-col lg:flex-row items-stretch lg:items-center gap-2 sm:gap-2.5">
          {/* ROW 1 (Mobile) / LEFT FLEX COLUMN (Desktop): Main Search Input */}
          <div className="relative flex-1 flex items-center min-w-0 h-11 sm:h-12 bg-neutral-50 lg:bg-transparent rounded-xl lg:rounded-none border border-neutral-200/70 lg:border-0 transition-colors">
            <Search className="absolute left-3 w-4 h-4 text-neutral-400 pointer-events-none shrink-0" />
            <input
              id={searchInputId}
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setIsOpen(true);
              }}
              onFocus={() => setIsOpen(true)}
              placeholder={placeholder}
              aria-label={placeholder}
              autoComplete="off"
              className="w-full bg-transparent border-0 py-2 pl-9 pr-8 text-neutral-900 placeholder:text-neutral-400 text-xs sm:text-sm md:text-base font-body focus:outline-none"
            />
            {loading && (
              <div className="absolute right-8 text-neutral-400">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
            )}
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="absolute right-2.5 p-1 text-neutral-400 hover:text-neutral-600 rounded-full transition-colors cursor-pointer"
                aria-label="Clear search query"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* ROW 2 (Mobile Single Line) / RIGHT GROUP (Desktop Inline): Budget, BHK & CTA Button */}
          <div className="flex items-center gap-2 border-t lg:border-t-0 lg:border-l border-neutral-100 pt-2 lg:pt-0 lg:pl-2.5">
            {/* Custom Floating Budget Selector */}
            <CustomSearchDropdown
              options={currentBudgetOptions.map((opt, idx) => ({ label: opt.label, value: idx }))}
              value={selectedBudgetIndex}
              onChange={(val) => setSelectedBudgetIndex(val)}
              ariaLabel="Filter by pricing budget"
            />

            {/* Custom Floating BHK Selector */}
            <CustomSearchDropdown
              options={BHK_OPTIONS.map((opt) => ({ label: opt.label, value: opt.value }))}
              value={selectedBhk}
              onChange={(val) => setSelectedBhk(val)}
              ariaLabel="Filter by bedroom count"
            />

            {/* Compact Square Icon CTA Button on Mobile (< lg), Full Labeled CTA Button on Desktop (>= lg) */}
            <button
              type="submit"
              aria-label="Search properties"
              className="h-10 sm:h-11 min-w-[40px] sm:min-w-[44px] inline-flex items-center justify-center gap-2 px-3 lg:px-6 rounded-xl bg-[#E85D3F] hover:bg-[#D44E32] active:scale-[0.98] text-white text-xs sm:text-sm font-display font-bold transition-all duration-150 shadow-xs hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E85D3F] focus-visible:ring-offset-2 shrink-0 cursor-pointer"
            >
              <Search className="w-4 h-4 lg:hidden" />
              <span className="hidden lg:inline">Search</span>
              <ArrowRight className="hidden lg:inline w-4 h-4 transition-transform group-hover:translate-x-0.5" />
            </button>
          </div>
        </form>

        {/* 3. Autocomplete Suggestions & History Overlay */}
        {isOpen && (
          <div className="absolute left-0 right-0 top-full mt-2 bg-white border border-neutral-200 rounded-2xl shadow-2xl z-50 font-body max-h-[60vh] sm:max-h-[70vh] overflow-y-auto overscroll-contain animate-fade-in">
            {/* Recent Searches Header */}
            {!query && recentSearches.length > 0 && (
              <div className="p-4 border-b border-neutral-100 bg-neutral-50/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider font-display">
                    Recent Searches
                  </span>
                  <button
                    type="button"
                    onClick={clearRecent}
                    className="text-xs text-[#E85D3F] hover:underline font-medium cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((term, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectRecent(term)}
                      className="text-xs bg-white text-neutral-700 px-3 py-1.5 rounded-md border border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50 transition-colors cursor-pointer"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Suggestions Grouping */}
            {query && hasSuggestions && (
              <div className="divide-y divide-neutral-100">
                {/* Projects */}
                {suggestions.projects.length > 0 && (
                  <div className="p-3">
                    <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-2 px-2 font-display">
                      Projects
                    </div>
                    {suggestions.projects.map((item) => (
                      <Link
                        key={item.id}
                        href={item.url}
                        onClick={() => setIsOpen(false)}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-neutral-50 transition-colors group"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center text-[#E85D3F] shrink-0">
                            <Building className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-neutral-900 group-hover:text-[#E85D3F] transition-colors">
                              {item.title}
                            </div>
                            <div className="text-xs text-neutral-500">{item.subtitle}</div>
                          </div>
                        </div>
                        {item.priceDisplay && (
                          <div className="text-xs font-semibold text-neutral-800 font-display">
                            {item.priceDisplay}
                          </div>
                        )}
                      </Link>
                    ))}
                  </div>
                )}

                {/* Locations */}
                {suggestions.locations.length > 0 && (
                  <div className="p-3">
                    <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-2 px-2 font-display">
                      Locations
                    </div>
                    {suggestions.locations.map((item) => (
                      <Link
                        key={item.id}
                        href={item.url}
                        onClick={() => setIsOpen(false)}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-neutral-50 transition-colors group"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600 shrink-0">
                            <MapPin className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-neutral-900 group-hover:text-[#E85D3F] transition-colors">
                              {item.title}
                            </div>
                            <div className="text-xs text-neutral-500">{item.subtitle}</div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}

                {/* Developers */}
                {suggestions.developers.length > 0 && (
                  <div className="p-3">
                    <div className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider mb-2 px-2 font-display">
                      Developers
                    </div>
                    {suggestions.developers.map((item) => (
                      <Link
                        key={item.id}
                        href={item.url}
                        onClick={() => setIsOpen(false)}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-neutral-50 transition-colors group"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 shrink-0">
                            <Briefcase className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-neutral-900 group-hover:text-[#E85D3F] transition-colors">
                              {item.title}
                            </div>
                            <div className="text-xs text-neutral-500">{item.subtitle}</div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Empty State */}
            {query && !hasSuggestions && !loading && (
              <div className="p-6 text-center text-neutral-500">
                <p className="text-sm">No exact suggestions found for "{query}".</p>
                <button
                  type="button"
                  onClick={handleSearchSubmit}
                  className="mt-3 inline-flex items-center space-x-2 text-xs font-semibold text-white bg-[#E85D3F] px-4 py-2 rounded-lg hover:bg-[#D44E32] transition-colors cursor-pointer"
                >
                  <span>Search all results for "{query}"</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
