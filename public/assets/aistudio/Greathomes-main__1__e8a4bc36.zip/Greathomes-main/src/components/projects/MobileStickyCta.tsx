'use client';

import Link from 'next/link';
import { ArrowRight, Calendar } from 'lucide-react';
import { PublicProjectDto } from '@/src/domain/projects/dto/projectDto';
import { formatIndianPrice } from '@/src/components/discovery/formatters';

interface MobileStickyCtaProps {
  project?: PublicProjectDto;
  projectName?: string;
  startingPrice?: number | null;
  ctaText?: string;
  targetSectionId?: string;
  className?: string;
  priceLabel?: string;
  formattedPrice?: string;
  ctaHref?: string;
}

export function MobileStickyCta({
  project,
  projectName,
  startingPrice,
  ctaText = 'Get Price & Availability',
  targetSectionId = 'contact-details',
  className = '',
  priceLabel,
  formattedPrice,
  ctaHref,
}: MobileStickyCtaProps) {
  const displayName = project?.name || projectName || 'Great Homes';

  // Determine pricing and label
  const effectiveStartingPrice = project ? project.pricing?.startingPrice : startingPrice;
  const derivedPrice =
    effectiveStartingPrice && effectiveStartingPrice > 0
      ? formatIndianPrice(effectiveStartingPrice)
      : project
      ? 'Price on Request'
      : null;

  const displayPrice = formattedPrice || derivedPrice;
  const displayLabel = priceLabel || (derivedPrice ? 'Starting Price' : 'Great Homes');

  const scrollToSection = (sectionId: string = targetSectionId) => {
    if (typeof window === 'undefined') return;
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      // Fallback: smooth scroll toward bottom
      window.scrollTo({
        top: document.body.scrollHeight - 600,
        behavior: 'smooth',
      });
    }
  };

  return (
    <aside
      id="mobile-sticky-conversion-bar"
      role="region"
      aria-label={`Conversion actions for ${displayName}`}
      className={`fixed inset-x-0 bottom-0 z-40 lg:hidden bg-white/95 backdrop-blur-md border-t border-[var(--color-border)] px-3.5 sm:px-4 py-2.5 shadow-lg select-none ${className}`}
      style={{ paddingBottom: 'max(0.625rem, env(safe-area-inset-bottom))' }}
    >
      <div className="max-w-md mx-auto flex items-center justify-between gap-2 sm:gap-3">
        {/* Left Column: Pricing or Great Homes Identity */}
        <div className="min-w-0 flex-1 flex flex-col justify-center">
          <span className="text-[9px] sm:text-[10px] uppercase tracking-wider font-semibold text-[var(--color-foreground)]/50 font-display truncate">
            {displayLabel}
          </span>
          <span className="text-sm sm:text-base font-display font-bold text-[#111111] leading-tight truncate">
            {displayPrice || displayName}
          </span>
        </div>

        {/* Right Actions: Secondary Visit + Primary Conversion CTA */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Secondary Action: Visit / Schedule Site Visit (visible on >=360px when not linking directly) */}
          {!ctaHref && (
            <button
              type="button"
              onClick={() => scrollToSection('contact-details')}
              className="hidden min-[360px]:inline-flex items-center justify-center gap-1 py-2.5 px-2.5 rounded-xl border border-[var(--color-border)] hover:bg-[#FAFAF8] text-[#111111] text-xs font-semibold font-display transition-colors shadow-2xs active:scale-95 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[var(--color-accent)]"
              aria-label={`Schedule a site visit for ${displayName}`}
            >
              <Calendar className="w-3.5 h-3.5 text-[#E85D3F]" />
              <span>Visit</span>
            </button>
          )}

          {/* Primary CTA: Link or Button */}
          {ctaHref ? (
            <Link
              href={ctaHref}
              className="py-2.5 px-3.5 sm:px-4 rounded-xl bg-[#E85D3F] hover:bg-[#D44C2F] active:scale-[0.98] text-white text-xs sm:text-sm font-semibold font-display flex items-center justify-center gap-1.5 transition-all shadow-xs focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F]"
              aria-label={`${ctaText} for ${displayName}`}
            >
              <span className="whitespace-nowrap">{ctaText}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          ) : (
            <button
              type="button"
              onClick={() => scrollToSection(targetSectionId)}
              className="py-2.5 px-3.5 sm:px-4 rounded-xl bg-[#E85D3F] hover:bg-[#D44C2F] active:scale-[0.98] text-white text-xs sm:text-sm font-semibold font-display flex items-center justify-center gap-1.5 transition-all shadow-xs focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F]"
              aria-label={`${ctaText} for ${displayName}`}
            >
              <span className="whitespace-nowrap">{ctaText}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </aside>
  );
}
