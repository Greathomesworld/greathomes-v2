'use client';

import React from 'react';
import { ArrowRight, Calendar, CheckCircle2, ShieldCheck } from 'lucide-react';
import { useEnquiry } from '@/src/components/enquiry/EnquiryContext';

interface ProjectFinalCtaProps {
  projectName: string;
  projectSlug?: string;
}

export function ProjectFinalCta({ projectName, projectSlug }: ProjectFinalCtaProps) {
  const { openEnquiry } = useEnquiry();

  const pillars = [
    'Guided Property Buying',
    'Site Visit Assistance',
    'Developer Booking Assistance',
    'No Brokerage on Developer Bookings',
    'Dedicated Great Homes Advisor',
  ];

  const handleOpenEnquiry = (requestVisit = false) => {
    openEnquiry({
      contextType: 'PROJECT',
      projectSlug,
      projectName,
      title: projectName,
      subtitle: requestVisit
        ? 'Schedule an assisted site visit with a Great Homes specialist'
        : 'Get verified project brochures, floor plans, and pricing intelligence',
    });
  };

  return (
    <section
      id="contact-details"
      aria-labelledby="final-cta-heading"
      className="pt-10 border-t border-[var(--color-border)]"
    >
      <div className="rounded-2xl border border-[var(--color-border)] bg-[var(--color-foreground)]/[0.02] p-8 md:p-12 text-center max-w-4xl mx-auto space-y-6">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold text-[var(--color-accent)] bg-[var(--color-accent)]/10 border border-[var(--color-accent)]/20">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Great Homes Assisted Buying</span>
        </div>

        <div className="space-y-2">
          <h2
            id="final-cta-heading"
            className="text-2xl sm:text-3xl md:text-4xl font-display font-semibold text-[var(--color-foreground)] tracking-tight"
          >
            Get Project Details & Advisory
          </h2>
          <p className="text-sm md:text-base text-[var(--color-foreground)]/70 max-w-2xl mx-auto leading-relaxed">
            Connect with our property specialists for verified availability, architectural specifications, and end-to-end guidance for {projectName}.
          </p>
        </div>

        {/* Assisted Buying Value Pillars */}
        <div className="flex flex-wrap items-center justify-center gap-2 md:gap-3 py-2">
          {pillars.map((pillar, idx) => (
            <span
              key={idx}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-white border border-[var(--color-border)] text-xs text-[var(--color-foreground)]/80 shadow-2xs"
            >
              <CheckCircle2 className="w-3 h-3 text-[var(--color-success)] shrink-0" />
              <span>{pillar}</span>
            </span>
          ))}
        </div>

        {/* Canonical Interactive CTAs */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            type="button"
            onClick={() => handleOpenEnquiry(false)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-[var(--color-accent)] hover:bg-[var(--color-accent)]/90 text-white font-semibold text-sm tracking-wide transition-all shadow-md active:scale-[0.98] focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[var(--color-accent)] focus-visible:ring-offset-2"
          >
            <span>Get Project Details</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => handleOpenEnquiry(true)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl border border-[var(--color-border)] bg-white hover:bg-[var(--color-foreground)]/5 text-[var(--color-foreground)] font-medium text-sm transition-all focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#111111] focus-visible:ring-offset-2"
          >
            <Calendar className="w-4 h-4 text-[var(--color-foreground)]/60" />
            <span>Schedule a Site Visit</span>
          </button>
        </div>

        <div className="pt-2 text-[11px] text-[var(--color-foreground)]/50">
          Independent advisory • Direct builder pricing • Strict privacy protection
        </div>
      </div>
    </section>
  );
}
