'use client';

import { useState } from 'react';
import {
  Headphones,
  CheckCircle2,
  TrendingUp,
  ArrowRight,
  Calendar,
  Phone,
  Share2,
} from 'lucide-react';
import { PublicProjectDto } from '@/src/domain/projects/dto/projectDto';
import { formatIndianPrice } from '@/src/components/discovery/formatters';
import { useEnquiry } from '@/src/components/enquiry/EnquiryContext';

interface GreatHomesAdvisoryCardProps {
  project: PublicProjectDto;
  className?: string;
}

export function GreatHomesAdvisoryCard({ project, className = '' }: GreatHomesAdvisoryCardProps) {
  const [copied, setCopied] = useState(false);
  const { openEnquiry } = useEnquiry();

  const handleOpenEnquiry = (requestVisit = false) => {
    openEnquiry({
      contextType: 'PROJECT',
      projectSlug: project.slug,
      projectName: project.name,
      title: project.name,
      locationName: project.location?.name,
      priceDisplay: startingPriceDisplay,
      subtitle: requestVisit
        ? 'Schedule a guided property inspection visit'
        : 'Get verified project brochures, floor plans, and pricing intelligence',
    });
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (typeof window !== 'undefined') {
      if (navigator.share) {
        try {
          await navigator.share({
            title: project.name,
            text: `Explore ${project.name} by ${project.developer.name} on Great Homes`,
            url: window.location.href,
          });
          return;
        } catch {
          // Fallback to clipboard
        }
      }
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  // Format pricing
  const startingPriceDisplay = project.pricing.startingPrice
    ? formatIndianPrice(project.pricing.startingPrice)
    : 'Price on Request';
  const ratePerSqftDisplay = project.pricing.lowestEffectivePricePerSqft
    ? `₹${Math.round(project.pricing.lowestEffectivePricePerSqft).toLocaleString('en-IN')}`
    : '₹—';

  return (
    <div
      id="great-homes-advisory-card"
      className={`h-[365px] bg-white rounded-2xl border border-[var(--color-border)] shadow-xs p-3 xl:p-3.5 flex flex-col justify-between select-none ${className}`}
    >
      {/* Header: Advisory Title */}
      <div className="flex items-center gap-2.5 pb-2 border-b border-[var(--color-border)]">
        <div className="w-8 h-8 rounded-lg bg-[#E85D3F]/10 text-[#E85D3F] flex items-center justify-center shrink-0 shadow-xs">
          <Headphones className="w-4 h-4" />
        </div>
        <div className="min-w-0">
          <h3 className="font-serif font-bold text-[#111111] text-sm leading-tight truncate">
            Great Homes Advisory
          </h3>
          <p className="text-[11px] text-[var(--color-foreground)]/60 truncate font-body">
            Expert guidance for {project.name}
          </p>
        </div>
      </div>

      {/* Pricing Intelligence Grid (Starting Price & Rate / Sq.Ft.) */}
      <div className="grid grid-cols-2 gap-1.5 p-2 bg-[#FAFAF8] rounded-xl border border-[var(--color-border)]">
        <div className="min-w-0">
          <span className="text-[9px] uppercase font-semibold tracking-wider text-[var(--color-foreground)]/50 block font-display truncate">
            Starting Price
          </span>
          <span className="text-base xl:text-lg font-serif font-bold text-[#111111] leading-tight block truncate">
            {startingPriceDisplay}
          </span>
        </div>
        <div className="border-l border-[var(--color-border)] pl-2 min-w-0">
          <span className="text-[9px] uppercase font-semibold tracking-wider text-[var(--color-foreground)]/50 block font-display truncate">
            Rate / Sq.Ft.
          </span>
          <span className="text-sm xl:text-base font-serif font-bold text-[#111111] leading-tight block truncate">
            {ratePerSqftDisplay}
          </span>
        </div>
      </div>

      {/* Advisory Value Proposition Checklist */}
      <div className="space-y-1 py-0.5 text-[11px] text-[#222222] font-body">
        <div className="flex items-center gap-1.5">
          <CheckCircle2 className="w-3 h-3 text-[#E85D3F] shrink-0" />
          <span className="leading-tight truncate">Project & RERA verified facts</span>
        </div>
        <div className="flex items-center gap-1.5">
          <CheckCircle2 className="w-3 h-3 text-[#E85D3F] shrink-0" />
          <span className="leading-tight truncate">Zero brokerage on builder bookings</span>
        </div>
        <div className="flex items-center gap-1.5">
          <CheckCircle2 className="w-3 h-3 text-[#E85D3F] shrink-0" />
          <span className="leading-tight truncate">Personalised site visit assistance</span>
        </div>
        <div className="flex items-center gap-1.5">
          <CheckCircle2 className="w-3 h-3 text-[#E85D3F] shrink-0" />
          <span className="leading-tight truncate">Latest price & availability</span>
        </div>
      </div>

      {/* Advisory Prompt Box */}
      <div className="p-1.5 rounded-lg bg-[#E85D3F]/5 border border-[#E85D3F]/10 text-[11px] min-w-0">
        <div className="flex items-center gap-1 font-semibold text-[#111111] font-display truncate">
          <TrendingUp className="w-3 h-3 text-[#E85D3F] shrink-0" />
          <span className="truncate">Want latest price & availability?</span>
        </div>
        <p className="text-[10px] text-[var(--color-foreground)]/65 font-body truncate">
          Get verified units, payment plans, and developer offers.
        </p>
      </div>

      {/* CTAs */}
      <div className="space-y-1.5 pt-0.5">
        <button
          type="button"
          onClick={() => handleOpenEnquiry(false)}
          className="w-full py-2 px-3 rounded-lg bg-[#E85D3F] hover:bg-[#D44C2F] text-white text-xs font-semibold font-display flex items-center justify-center gap-1.5 transition-colors shadow-xs focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F]"
        >
          <span>Get Price & Availability</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>

        {/* Utility Action Buttons: Visit, Call / Callback, Share */}
        <div className="grid grid-cols-3 gap-1">
          <button
            type="button"
            onClick={() => handleOpenEnquiry(true)}
            className="py-1 px-1.5 rounded-md border border-[var(--color-border)] hover:bg-[#FAFAF8] text-[#111111] text-[11px] font-medium font-display flex items-center justify-center gap-1 transition-colors"
          >
            <Calendar className="w-3 h-3 text-[var(--color-foreground)]/60" />
            <span>Visit</span>
          </button>

          <button
            type="button"
            onClick={() => handleOpenEnquiry(false)}
            className="py-1 px-1.5 rounded-md border border-[var(--color-border)] hover:bg-[#FAFAF8] text-[#111111] text-[11px] font-medium font-display flex items-center justify-center gap-1 transition-colors"
          >
            <Phone className="w-3 h-3 text-[var(--color-foreground)]/60" />
            <span>Call</span>
          </button>

          <button
            type="button"
            onClick={handleShare}
            className="py-1 px-1.5 rounded-md border border-[var(--color-border)] hover:bg-[#FAFAF8] text-[#111111] text-[11px] font-medium font-display flex items-center justify-center gap-1 transition-colors relative"
            title="Share property link"
          >
            <Share2 className="w-3 h-3 text-[var(--color-foreground)]/60" />
            <span>{copied ? 'Copied' : 'Share'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
