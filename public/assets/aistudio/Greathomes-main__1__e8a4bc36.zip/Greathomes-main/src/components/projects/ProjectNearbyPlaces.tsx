'use client';

import React, { useState, useMemo } from 'react';
import {
  Train,
  Plane,
  Bus,
  GraduationCap,
  Cross,
  Building2,
  ShoppingBag,
  Trees,
  Landmark,
  Compass,
  ShieldCheck,
} from 'lucide-react';
import { NearbyPlaceDto, PlaceCategory } from '@/src/domain/places/entities';

export interface ProjectNearbyPlacesProps {
  places: NearbyPlaceDto[];
  hasCoordinates: boolean;
  projectName: string;
  className?: string;
}

type FilterCategory = 'ALL' | PlaceCategory;

const CATEGORY_ICONS: Record<PlaceCategory, React.ElementType> = {
  METRO: Train,
  AIRPORT: Plane,
  TRANSIT: Bus,
  EDUCATION: GraduationCap,
  HEALTHCARE: Cross,
  COMMERCIAL: Building2,
  RETAIL: ShoppingBag,
  RECREATION: Trees,
  LANDMARK: Landmark,
};

export function ProjectNearbyPlaces({
  places,
  hasCoordinates,
  projectName,
  className = '',
}: ProjectNearbyPlacesProps) {
  const [selectedCategory, setSelectedCategory] = useState<FilterCategory>('ALL');

  // Compute available categories with counts
  const categoryCounts = useMemo(() => {
    const counts: Partial<Record<PlaceCategory, number>> = {};
    for (const p of places) {
      counts[p.category] = (counts[p.category] || 0) + 1;
    }
    return counts;
  }, [places]);

  const activeCategories = useMemo(() => {
    const unique = Array.from(new Set(places.map(p => p.category)));
    return unique;
  }, [places]);

  // Filtered places
  const filteredPlaces = useMemo(() => {
    if (selectedCategory === 'ALL') {
      return places;
    }
    return places.filter(p => p.category === selectedCategory);
  }, [places, selectedCategory]);

  if (!hasCoordinates) {
    return (
      <div className={`p-6 rounded-xl border border-[var(--color-border)] bg-[#FAFAF8] text-center ${className}`}>
        <div className="w-10 h-10 rounded-full bg-[var(--color-foreground)]/[0.04] border border-[var(--color-border)] flex items-center justify-center mx-auto mb-2 text-[var(--color-foreground)]/40">
          <Compass className="w-4 h-4" />
        </div>
        <h4 className="font-display font-medium text-xs text-[var(--color-foreground)] uppercase tracking-wider">
          Nearby Connectivity Pending
        </h4>
        <p className="text-xs text-[var(--color-foreground)]/60 max-w-md mx-auto mt-1 leading-relaxed">
          Nearby places and straight-line geodesic distance calculations for {projectName} will appear once pinpoint coordinates are verified.
        </p>
      </div>
    );
  }

  if (places.length === 0) {
    return (
      <div className={`p-6 rounded-xl border border-[var(--color-border)] bg-[#FAFAF8] text-center ${className}`}>
        <p className="text-xs text-[var(--color-foreground)]/60">
          No verified places within the current spatial radius for {projectName}.
        </p>
      </div>
    );
  }

  return (
    <div className={`space-y-4 pt-2 ${className}`}>
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1.5 border-b border-[var(--color-border)]/60 pb-3">
        <div>
          <h3 className="text-base sm:text-lg font-display font-semibold text-[var(--color-foreground)]">
            Nearby Places &amp; Connectivity
          </h3>
          <p className="text-xs text-[var(--color-foreground)]/60 mt-0.5">
            Verified straight-line geodesic distance from {projectName} pinpoint coordinates.
          </p>
        </div>
        <div className="inline-flex items-center gap-1 text-[11px] text-[var(--color-foreground)]/50 font-mono shrink-0">
          <ShieldCheck className="w-3.5 h-3.5 text-[#218C5A]" />
          <span>{places.length} Verified Locations</span>
        </div>
      </div>

      {/* Category Filter Row (Isolated horizontal scroll on mobile, wrap on tablet/desktop) */}
      <div 
        role="tablist"
        aria-label="Filter nearby places by category"
        className="flex items-center gap-1.5 py-1 overflow-x-auto no-scrollbar scroll-smooth -mx-4 px-4 sm:mx-0 sm:px-0 sm:flex-wrap"
      >
        <button
          type="button"
          role="tab"
          aria-selected={selectedCategory === 'ALL'}
          onClick={() => setSelectedCategory('ALL')}
          className={`shrink-0 min-h-[38px] sm:min-h-[32px] px-3.5 py-1.5 rounded-lg text-xs font-display font-medium transition-colors focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F] ${
            selectedCategory === 'ALL'
              ? 'bg-[#111111] text-white shadow-2xs'
              : 'bg-[var(--color-foreground)]/[0.05] text-[var(--color-foreground)]/75 hover:bg-[var(--color-foreground)]/[0.1] active:bg-[var(--color-foreground)]/[0.15]'
          }`}
        >
          All ({places.length})
        </button>

        {activeCategories.map(cat => {
          const count = categoryCounts[cat] || 0;
          const Icon = CATEGORY_ICONS[cat] || Compass;
          const isSelected = selectedCategory === cat;

          return (
            <button
              key={cat}
              type="button"
              role="tab"
              aria-selected={isSelected}
              onClick={() => setSelectedCategory(cat)}
              className={`shrink-0 min-h-[38px] sm:min-h-[32px] inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-display font-medium transition-colors focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F] ${
                isSelected
                  ? 'bg-[#111111] text-white shadow-2xs'
                  : 'bg-[var(--color-foreground)]/[0.05] text-[var(--color-foreground)]/75 hover:bg-[var(--color-foreground)]/[0.1] active:bg-[var(--color-foreground)]/[0.15]'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{cat}</span>
              <span className={`text-[10px] ${isSelected ? 'text-white/70' : 'text-[var(--color-foreground)]/50'}`}>
                ({count})
              </span>
            </button>
          );
        })}
      </div>

      {/* Places Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3">
        {filteredPlaces.map(place => {
          const Icon = CATEGORY_ICONS[place.category] || Compass;

          return (
            <div
              key={place.id}
              className="p-3 sm:p-3.5 rounded-xl border border-[var(--color-border)] bg-[#FAFAF8] hover:border-[var(--color-foreground)]/20 transition-all flex flex-col justify-between group shadow-2xs min-w-0"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5 min-w-0 flex-1">
                  <div className="w-7 h-7 rounded-lg bg-white border border-[var(--color-border)] flex items-center justify-center text-[var(--color-foreground)]/70 shrink-0 mt-0.5 group-hover:text-[#E85D3F] group-hover:border-[#E85D3F]/30 transition-colors">
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs sm:text-sm font-display font-medium text-[var(--color-foreground)] leading-snug line-clamp-2">
                      {place.name}
                    </h4>
                    {place.locality && (
                      <p className="text-[11px] text-[var(--color-foreground)]/50 truncate mt-0.5">
                        {place.locality}
                      </p>
                    )}
                  </div>
                </div>

                {/* Distance in KM Badge */}
                <div className="shrink-0 px-2 py-0.5 sm:py-1 rounded-md bg-white border border-[var(--color-border)] shadow-2xs font-mono font-semibold text-xs text-[var(--color-foreground)] whitespace-nowrap">
                  {place.formattedDistance}
                </div>
              </div>

              <div className="mt-2.5 sm:mt-3 pt-2 sm:pt-2.5 border-t border-[var(--color-border)]/40 flex items-center justify-between text-[10px] text-[var(--color-foreground)]/50">
                <span className="uppercase tracking-wider font-display font-medium text-[var(--color-accent)]">
                  {place.categoryDisplay}
                </span>
                <span className="inline-flex items-center gap-1 font-mono">
                  <span>Geodesic</span>
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
