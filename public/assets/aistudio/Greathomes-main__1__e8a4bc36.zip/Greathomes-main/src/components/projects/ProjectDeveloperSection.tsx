import Link from 'next/link';
import { Building2, ArrowRight, CheckCircle2 } from 'lucide-react';
import { BoundedDeveloperDto } from '@/src/domain/projects/dto/projectDto';

interface ProjectDeveloperSectionProps {
  developer: BoundedDeveloperDto;
  developerBio?: string | null;
  developerWebsite?: string | null;
}

export function ProjectDeveloperSection({
  developer,
  developerBio,
  developerWebsite,
}: ProjectDeveloperSectionProps) {
  return (
    <section id="developer" aria-labelledby="developer-heading" className="space-y-6 pt-8 border-t border-[var(--color-border)]">
      <div>
        <div className="text-xs uppercase font-semibold tracking-wider text-[var(--color-accent)] mb-1">
          Development Partner
        </div>
        <h2 id="developer-heading" className="text-2xl font-display font-semibold text-[var(--color-foreground)]">
          About {developer.name}
        </h2>
        <p className="text-xs text-[var(--color-foreground)]/65 mt-1">
          Architectural pedigree and developer history.
        </p>
      </div>

      <div className="p-6 md:p-8 rounded-xl border border-[var(--color-border)] bg-[var(--color-foreground)]/[0.01] space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[var(--color-foreground)]/5 border border-[var(--color-border)] flex items-center justify-center shrink-0">
              <Building2 className="w-6 h-6 text-[var(--color-accent)]" />
            </div>
            <div>
              <h3 className="text-lg font-display font-semibold text-[var(--color-foreground)]">
                {developer.name}
              </h3>
              <div className="flex items-center gap-1.5 text-xs text-[var(--color-success)] font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verified Builder Portfolio</span>
              </div>
            </div>
          </div>

          <Link
            href={`/developers/${developer.slug}`}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--color-accent)] hover:underline decoration-dotted underline-offset-4"
          >
            <span>View All Projects by {developer.name}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {developerBio && (
          <p className="text-sm font-editorial text-[var(--color-foreground)]/80 leading-relaxed max-w-3xl pt-2 border-t border-[var(--color-border)]/60">
            {developerBio}
          </p>
        )}

        {developerWebsite && (
          <div className="pt-2 text-xs text-[var(--color-foreground)]/60">
            <span>Official Portal: </span>
            <a
              href={developerWebsite}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[var(--color-foreground)] underline underline-offset-2 hover:text-[var(--color-accent)] transition-colors"
            >
              {developerWebsite.replace(/^https?:\/\//, '')}
            </a>
          </div>
        )}
      </div>
    </section>
  );
}
