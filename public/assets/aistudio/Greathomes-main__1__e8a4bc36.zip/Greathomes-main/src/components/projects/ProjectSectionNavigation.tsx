'use client';

import { useEffect, useState } from 'react';

export interface NavItem {
  id: string;
  label: string;
}

interface ProjectSectionNavigationProps {
  items: NavItem[];
}

export function ProjectSectionNavigation({ items }: ProjectSectionNavigationProps) {
  const [activeId, setActiveId] = useState<string>(items[0]?.id || '');

  useEffect(() => {
    if (!items || items.length === 0) return;

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 140;

      for (let i = items.length - 1; i >= 0; i--) {
        const section = document.getElementById(items[i].id);
        if (section) {
          const top = section.offsetTop;
          if (scrollPosition >= top) {
            setActiveId(items[i].id);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [items]);

  if (!items || items.length === 0) return null;

  const scrollToSection = (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (el) {
      const yOffset = -70; // Header & sticky bar offset
      const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
      setActiveId(id);
    }
  };

  return (
    <nav
      aria-label="Project section navigation"
      className="sticky top-0 z-30 bg-[var(--color-background)]/95 backdrop-blur-md border-b border-[var(--color-border)] transition-colors"
    >
      <div className="w-full">
        <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto py-2.5 pr-6 scrollbar-none [scrollbar-width:none] [-ms-overflow-style:none]">
          {items.map(item => {
            const isActive = activeId === item.id;
            return (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => scrollToSection(item.id, e)}
                className={`shrink-0 px-3.5 py-1.5 rounded-xl text-xs font-medium font-display transition-colors whitespace-nowrap focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#E85D3F] ${
                  isActive
                    ? 'bg-[#111111] text-white font-semibold shadow-xs'
                    : 'text-[var(--color-foreground)]/70 hover:text-[var(--color-foreground)] hover:bg-[var(--color-foreground)]/5'
                }`}
                aria-current={isActive ? 'true' : undefined}
              >
                {item.label}
              </a>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
