'use client';

import { PublicResaleListingDto } from '@/src/domain/projects/dto/resaleDto';
import Link from 'next/link';
import { ShieldCheck, CheckCircle, ArrowRight } from 'lucide-react';
import { formatIndianPrice, formatArea, formatFurnishing, formatFloorCategory, formatPropertyType } from '@/src/components/discovery/formatters';
import { ListingImage } from '@/src/components/discovery/ListingImage';

interface ResaleSectionProps {
  listings: PublicResaleListingDto[];
  projectSlug: string;
}

export function ResaleSection({ listings, projectSlug }: ResaleSectionProps) {
  if (!listings || listings.length === 0) return null;

  return (
    <section id="resale" aria-labelledby="resale-heading" className="space-y-6 pt-10 border-t border-[var(--color-border)]">
      {/* Editorial Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-4">
        <div>
          <div className="text-xs uppercase font-semibold tracking-wider text-[var(--color-accent)] mb-1">
            Resale Homes
          </div>
          <h2 id="resale-heading" className="text-2xl md:text-3xl font-display font-semibold text-[var(--color-foreground)]">
            Resale Homes ({listings.length})
          </h2>
          <p className="text-xs text-[var(--color-foreground)]/65 mt-1">
            Verified resale properties currently available in this project.
          </p>
        </div>
      </div>

      {/* Responsive Marketplace Card Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {listings.map(listing => {
          const featuredMedia = listing.media?.find(m => m.isFeatured) || listing.media?.[0];
          const imageUrl = featuredMedia?.url;
          const areaSummary = formatArea(listing.carpetArea);
          const floorSummary = formatFloorCategory(listing.floorCategory);
          const furnishSummary = formatFurnishing(listing.furnishing);
          const possessionLabel = listing.possession === 'READY' ? 'Ready' : listing.possession.replace(/_/g, ' ');
          const targetUrl = listing.slug ? `/buy/${listing.slug}` : `/projects/${projectSlug}`;

          return (
            <Link
              key={listing.id}
              id={`resale-${listing.id}`}
              href={targetUrl}
              aria-label={`${listing.configuration} Resale Home in ${projectSlug}`}
              className="group flex flex-col bg-[var(--color-background)] border border-[var(--color-border)] rounded-xl overflow-hidden hover:border-[var(--color-foreground)]/30 hover:shadow-md transition-all duration-200 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-[#111111] focus-visible:ring-offset-2"
            >
              <article className="flex flex-col flex-grow justify-between">
                <div>
                  {/* Media Header */}
                  <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
                    <ListingImage
                      src={imageUrl}
                      alt={listing.configuration}
                      fallbackType="resale"
                    />

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
                      <span className="bg-white/95 text-[#111111] border border-[rgba(17,17,17,0.12)] text-[11px] font-semibold tracking-wider uppercase px-2.5 py-1 rounded-md shadow-xs backdrop-blur-xs">
                        RESALE
                      </span>
                    </div>

                    <div className="absolute top-3 right-3 flex flex-wrap gap-1.5 items-center z-10 pointer-events-none">
                      {listing.isVerified && (
                        <span className="bg-[#218C5A] text-white text-[11px] font-medium px-2 py-1 rounded-md flex items-center gap-1 shadow-xs">
                          <CheckCircle className="w-3 h-3" />
                          Verified
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 space-y-4">
                    <div>
                      <h3 className="font-display font-semibold text-lg text-[var(--color-foreground)] group-hover:text-[var(--color-accent)] transition-colors line-clamp-1 mb-1">
                        {listing.configuration}
                      </h3>
                      <div className="text-xs text-[var(--color-foreground)]/60">
                        {listing.bedroomCount} BHK · {formatPropertyType(listing.propertyType)}
                      </div>
                    </div>

                    {/* Asking Price - NO per-sqft calculation */}
                    <div>
                      <span className="text-[11px] uppercase tracking-wider text-[var(--color-foreground)]/50 block mb-0.5">
                        Asking Price
                      </span>
                      <div className="text-2xl font-display font-bold text-[var(--color-foreground)]">
                        {formatIndianPrice(listing.askingPrice)}
                      </div>
                    </div>

                    {/* Property Highlights */}
                    <div className="py-2.5 px-3 bg-[var(--color-foreground)]/[0.02] rounded-lg border border-[var(--color-border)] text-xs text-[var(--color-foreground)]/75 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[var(--color-foreground)]/60">Area & Furnishing:</span>
                        <span className="font-medium text-[var(--color-foreground)]">
                          {[areaSummary, furnishSummary].filter(Boolean).join(' · ')}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-[var(--color-foreground)]/60">Floor & Status:</span>
                        <span className="font-medium text-[var(--color-foreground)]">
                          {[floorSummary, possessionLabel].filter(Boolean).join(' · ')}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer with Listing Party & CTA */}
                <div className="p-5 pt-0">
                  <div className="pt-3 border-t border-[var(--color-border)] flex items-center justify-between text-xs">
                    <span className="text-[11px] font-medium text-[var(--color-foreground)]/65">
                      {listing.listingParty.label}
                    </span>

                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--color-foreground)] group-hover:text-[var(--color-accent)] transition-colors py-1.5 px-3 rounded-lg border border-[var(--color-border)] group-hover:border-[var(--color-accent)]">
                      <span>View Property</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </article>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
