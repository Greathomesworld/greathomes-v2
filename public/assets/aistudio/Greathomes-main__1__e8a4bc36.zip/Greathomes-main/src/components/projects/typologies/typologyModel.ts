import {
  PublicProjectConfigurationDto,
  PublicProjectMediaDto,
  getConfigurationCardAreaInfo,
  formatStartingPrice,
  sortConfigurations,
} from '@/src/domain/projects/dto/projectDto';
import { PriceBasis } from '@/src/domain/projects/entities';

/**
 * Future Floor Plan Viewer Contract definition (Phase 05F.5.A foundation)
 */
export interface OpenFloorPlansParams {
  projectId: string;
  configurationId?: string;
  initialMediaId?: string;
}

/**
 * Clean Frontend View Model for a Project Configuration
 * Derived purely from the PublicProjectConfigurationDto and media list.
 */
export interface ProjectConfigurationViewModel {
  id: string;
  projectId?: string;
  name: string;
  typologyCategory: string; // Dynamic typology category (e.g. "1 BHK", "2 BHK", "2.5 BHK", "3 BHK", "Penthouse")
  bedroomCount: number | null;
  carpetArea: number | null;
  builtUpArea: number | null;
  superBuiltUpArea: number | null;
  startingPrice: number;
  startingPriceFormatted: string;
  priceBasis: PriceBasis;
  effectivePricePerSqft: number | null;
  rateDisplay: string | null; // e.g. "₹8,450/sq.ft. · Carpet"
  rateBasisLabel: string; // "Carpet", "Built-up", or "Super Built-up"
  hasRate: boolean;
  carpetAreaDisplay: string | null;
  secondaryAreaLabel: string | null;
  secondaryAreaDisplay: string | null;
  floorPlans: PublicProjectMediaDto[];
  floorPlanCount: number;
  hasFloorPlans: boolean;
  availability: string;
}

/**
 * Typology Filter item for dynamic client-side filtering
 */
export interface TypologyFilterItem {
  key: string;
  label: string;
  count: number;
}

/**
 * Extracts a normalized typology category string from configuration name/bedroomCount.
 * Strictly data-driven: matches any "N BHK" or "N.N BHK", or descriptive names like "Studio", "Duplex", "Penthouse", "Villa".
 */
export function extractTypologyCategory(config: PublicProjectConfigurationDto): string {
  // Check for any BHK pattern in the name (e.g., "1 BHK", "2 BHK", "2.5 BHK", "3 BHK", "4 BHK", "5 BHK")
  const bhkMatch = config.name.match(/(\d+(\.\d+)?)\s*BHK/i);
  if (bhkMatch) {
    return `${bhkMatch[1]} BHK`;
  }

  if (config.bedroomCount != null && config.bedroomCount > 0) {
    return `${config.bedroomCount} BHK`;
  }

  // Non-BHK categories: extract known words or clean the name
  const lower = config.name.toLowerCase();
  if (lower.includes('studio')) return 'Studio';
  if (lower.includes('penthouse')) return 'Penthouse';
  if (lower.includes('duplex')) return 'Duplex';
  if (lower.includes('villa')) return 'Villa';
  if (lower.includes('plot')) return 'Plot';

  // Fallback: trimmed name
  return config.name.trim();
}

/**
 * Maps a PublicProjectConfigurationDto to the clean ProjectConfigurationViewModel.
 * Adheres strictly to canonical pricing rules and area breakdown.
 */
export function mapDtoToConfigurationViewModel(
  dto: PublicProjectConfigurationDto,
  mediaList: PublicProjectMediaDto[] = [],
  projectId?: string
): ProjectConfigurationViewModel {
  const areaInfo = getConfigurationCardAreaInfo(dto);

  // Resolve floor plans for this specific configuration
  const configFloorPlans: PublicProjectMediaDto[] = (() => {
    // 1. Direct floorPlans array on the DTO
    if (dto.floorPlans && dto.floorPlans.length > 0) {
      return dto.floorPlans;
    }
    // 2. Search project media matching configurationId or floorPlanMediaId
    if (mediaList.length > 0) {
      const matched = mediaList.filter(
        (m) =>
          (m.configurationId === dto.id || (dto.floorPlanMediaId && (m.id === dto.floorPlanMediaId || m.mediaId === dto.floorPlanMediaId))) &&
          m.category === 'FLOOR_PLANS'
      );
      if (matched.length > 0) return matched;

      if (dto.floorPlanMediaId) {
        const direct = mediaList.find((m) => m.id === dto.floorPlanMediaId || m.mediaId === dto.floorPlanMediaId);
        if (direct) return [direct];
      }
    }
    return [];
  })();

  const typologyCategory = extractTypologyCategory(dto);

  return {
    id: dto.id,
    projectId,
    name: dto.name,
    typologyCategory,
    bedroomCount: dto.bedroomCount ?? null,
    carpetArea: dto.carpetArea ?? null,
    builtUpArea: dto.builtUpArea ?? null,
    superBuiltUpArea: dto.superBuiltUpArea ?? null,
    startingPrice: dto.price ?? 0,
    startingPriceFormatted: formatStartingPrice(dto.price),
    priceBasis: dto.priceBasis,
    effectivePricePerSqft: dto.effectivePricePerSqft ?? null,
    rateDisplay: areaInfo.rateDisplay,
    rateBasisLabel: areaInfo.rateBasisLabel,
    hasRate: Boolean(areaInfo.rateDisplay),
    carpetAreaDisplay: areaInfo.carpetAreaDisplay,
    secondaryAreaLabel: areaInfo.secondaryAreaLabel,
    secondaryAreaDisplay: areaInfo.secondaryAreaDisplay,
    floorPlans: configFloorPlans,
    floorPlanCount: configFloorPlans.length,
    hasFloorPlans: configFloorPlans.length > 0,
    availability: dto.availability || 'AVAILABLE',
  };
}

/**
 * Dynamically generates typology filters from the actual configuration set.
 * Zero hardcoded values: dynamically discovers all categories.
 */
export function extractDynamicTypologyFilters(
  configs: ProjectConfigurationViewModel[]
): TypologyFilterItem[] {
  if (configs.length === 0) return [];

  const categoryCounts = new Map<string, number>();

  for (const c of configs) {
    const cat = c.typologyCategory;
    categoryCounts.set(cat, (categoryCounts.get(cat) || 0) + 1);
  }

  // Helper to extract numerical BHK value for sorting
  const getBhkNumber = (cat: string): number | null => {
    const match = cat.match(/(\d+(\.\d+)?)\s*BHK/i);
    return match ? parseFloat(match[1]) : null;
  };

  const categories = Array.from(categoryCounts.keys()).sort((a, b) => {
    const aNum = getBhkNumber(a);
    const bNum = getBhkNumber(b);

    if (aNum != null && bNum != null) {
      return aNum - bNum;
    }
    if (aNum != null) return -1;
    if (bNum != null) return 1;
    return a.localeCompare(b);
  });

  const filters: TypologyFilterItem[] = [
    { key: 'ALL', label: 'All', count: configs.length },
    ...categories.map((cat) => ({
      key: cat,
      label: cat,
      count: categoryCounts.get(cat) || 0,
    })),
  ];

  return filters;
}

/**
 * Transforms a list of DTOs into sorted, view models.
 */
export function prepareProjectConfigurations(
  configurations: PublicProjectConfigurationDto[],
  mediaList: PublicProjectMediaDto[] = [],
  projectId?: string
): ProjectConfigurationViewModel[] {
  const sortedDtos = sortConfigurations(configurations || []);
  return sortedDtos.map((dto) => mapDtoToConfigurationViewModel(dto, mediaList, projectId));
}
