import { PublicProjectDto } from '@/src/domain/projects/dto/projectDto';

interface ProjectStructuredDataProps {
  project: PublicProjectDto;
}

export function ProjectStructuredData({ project }: ProjectStructuredDataProps) {
  const projectSchema = {
    '@type': project.propertyType === 'VILLA' ? 'SingleFamilyResidence' : 'ApartmentComplex',
    name: project.name,
    description: project.shortDescription || project.description,
    url: `https://greathomes.co.in/projects/${project.slug}`,
    address: {
      '@type': 'PostalAddress',
      addressLocality: project.location.name,
      addressRegion: project.location.path?.[0]?.name || project.location.name,
      addressCountry: 'IN',
    },
    developer: {
      '@type': 'Organization',
      name: project.developer.name,
      url: `https://greathomes.co.in/developers/${project.developer.slug}`,
    },
    offers: {
      '@type': 'AggregateOffer',
      priceCurrency: 'INR',
      lowPrice: project.pricing.startingPrice || undefined,
      highPrice: project.pricing.maximumPrice || undefined,
      offerCount: project.configurations.length,
    },
    image: project.media.map(m => m.url),
  };

  // Build canonical BreadcrumbList JSON-LD
  const breadcrumbElements = [
    {
      '@type': 'ListItem',
      position: 1,
      name: 'Home',
      item: 'https://greathomes.co.in',
    },
    {
      '@type': 'ListItem',
      position: 2,
      name: 'Projects',
      item: 'https://greathomes.co.in/projects',
    },
  ];

  let currentPos = 3;
  if (project.location.path && project.location.path.length > 0) {
    for (const node of project.location.path) {
      breadcrumbElements.push({
        '@type': 'ListItem',
        position: currentPos++,
        name: node.name,
        item: `https://greathomes.co.in/locations/${node.slug}`,
      });
    }
  } else {
    breadcrumbElements.push({
      '@type': 'ListItem',
      position: currentPos++,
      name: project.location.name,
      item: `https://greathomes.co.in/locations/${project.location.slug}`,
    });
  }

  breadcrumbElements.push({
    '@type': 'ListItem',
    position: currentPos,
    name: project.name,
    item: `https://greathomes.co.in/projects/${project.slug}`,
  });

  const breadcrumbListSchema = {
    '@type': 'BreadcrumbList',
    itemListElement: breadcrumbElements,
  };

  const graphData = {
    '@context': 'https://schema.org',
    '@graph': [projectSchema, breadcrumbListSchema],
  };

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(graphData) }}
    />
  );
}
