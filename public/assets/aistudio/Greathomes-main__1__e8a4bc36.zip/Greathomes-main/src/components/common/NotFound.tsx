export function NotFound() {
  return (
    <div className="min-h-[50vh] flex flex-col items-center justify-center p-6 text-center">
      <h1 className="text-2xl font-display font-semibold text-[var(--color-foreground)] mb-2">
        Page Not Found
      </h1>
      <p className="text-sm font-body text-[var(--color-foreground)]/60">
        The requested property, project, or location could not be found.
      </p>
    </div>
  );
}
