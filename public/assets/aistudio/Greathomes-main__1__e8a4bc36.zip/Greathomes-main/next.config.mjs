/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=(), payment=()',
          },
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=31536000; includeSubDomains',
          },
        ],
      },
    ];
  },
  async redirects() {
    return [
      {
        source: '/resale/:slug',
        destination: '/buy/:slug',
        permanent: true,
      },
    ];
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'picsum.photos',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'media.greathomes.co.in',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'pub-8e680bcad96e4b29adac1756755a344b.r2.dev',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: '*.r2.dev',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: '*.r2.cloudflarestorage.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'www.propvestors.in',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'propvestors.in',
        port: '',
        pathname: '/**',
      },
    ],
  },
  allowedDevOrigins: [
    '*.run.app',
    '*.asia-southeast1.run.app',
    'localhost:3000',
    '127.0.0.1:3000',
    'ais-dev-gplf76f5j6sat3wusaxbzb-118859849686.asia-southeast1.run.app',
    'ais-pre-gplf76f5j6sat3wusaxbzb-118859849686.asia-southeast1.run.app',
  ],
};

export default nextConfig;
