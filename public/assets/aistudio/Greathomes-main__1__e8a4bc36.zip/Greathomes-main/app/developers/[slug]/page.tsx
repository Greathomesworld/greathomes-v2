import { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

import { developerService } from '@/src/domain/developers/services/developerService';
import { ensureSeedData } from '@/src/infrastructure/seed';
import {
  Building2,
  MapPin,
  Globe,
  ExternalLink,
  ShieldCheck,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface DeveloperPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata(
  props: DeveloperPageProps
): Promise<Metadata> {
  await ensureSeedData();
  const { slug } = await props.params;
  const developer = await developerService.getPublicDeveloperDtoBySlug(slug);

  if (!developer) {
    return {
      title: 'Developer Not Found | Great Homes',
      description: 'The requested real estate developer profile could not be found.',
    };
  }

  const title = `${developer.name} — Real Estate Projects & Intelligence | Great Homes`;
  const description =
    developer.shortDescription ||
    developer.description ||
    `Explore verified residential developments, locations, and real estate intelligence for ${developer.name} on Great Homes V2.`;

  return {
    title,
    description,
    alternates: {
      canonical: `/developers/${developer.slug}`,
    },
    openGraph: {
      title,
      description,
      url: `/developers/${developer.slug}`,
      siteName: 'Great Homes',
      type: 'profile',
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
    },
  };
}

function formatPrice(price?: number): string | null {
  if (!price) return null;
  if (price >= 10000000) {
    const cr = (price / 10000000).toFixed(2).replace(/\.00$/, '');
    return `₹${cr} Cr`;
  }
  if (price >= 100000) {
    const l = (price / 100000).toFixed(2).replace(/\.00$/, '');
    return `₹${l} L`;
  }
  return `₹${price.toLocaleString('en-IN')}`;
}

export default async function DeveloperDetailPage(props: DeveloperPageProps) {
  await ensureSeedData();
  const { slug } = await props.params;
  const developer = await developerService.getPublicDeveloperDtoBySlug(slug);

  if (!developer) {
    notFound();
  }

  const projects = await developerService.getDeveloperPublicProjects(developer.id);
  const reraVerifiedCount = projects.filter(p => p.hasVerifiedReraBadge).length;

  return (
    <div className="min-h-screen bg-[var(--color-background)] text-[var(--color-foreground)]">
      {/* Editorial Breadcrumb */}
      <nav aria-label="Breadcrumb" className="border-b border-[var(--color-border)] bg-[var(--color-background)]">
        <div className="max-w-6xl mx-auto px-6 py-3.5">
          <ol className="flex items-center space-x-2 text-xs text-[var(--color-foreground)]/60">
            <li>
              <Link href="/" className="hover:text-[var(--color-foreground)] transition-colors">
                Home
              </Link>
            </li>
            <li>
              <ChevronRight className="w-3.5 h-3.5 text-[var(--color-foreground)]/40" />
            </li>
            <li>
              <span className="text-[var(--color-foreground)]/70">Developers</span>
            </li>
            <li>
              <ChevronRight className="w-3.5 h-3.5 text-[var(--color-foreground)]/40" />
            </li>
            <li className="text-[var(--color-foreground)] font-medium truncate max-w-[200px] sm:max-w-none" aria-current="page">
              {developer.name}
            </li>
          </ol>
        </div>
      </nav>

      {/* Developer Hero & Identity */}
      <header className="border-b border-[var(--color-border)] py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-8">
            <div className="max-w-3xl space-y-4">
              <div className="flex flex-wrap items-center gap-2.5">
                {developer.logoUrl && (
                  <div className="relative w-24 h-14 md:w-32 md:h-20 mb-2">
                    <Image
                      src={developer.logoUrl}
                      alt={`${developer.name} logo`}
                      fill
                      className="object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                )}
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs tracking-wider uppercase font-semibold text-[var(--color-foreground)]/80 bg-[var(--color-foreground)]/5 border border-[var(--color-border)] rounded">
                  Developer Profile
                </span>
                {developer.featured && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold text-[var(--color-accent)] bg-[var(--color-accent)]/10 border border-[var(--color-accent)]/20 rounded">
                    <Sparkles className="w-3 h-3" />
                    Featured Partner
                  </span>
                )}
              </div>

              <h1 className="text-3xl md:text-5xl font-display font-semibold tracking-tight text-[var(--color-foreground)]">
                {developer.name}
              </h1>

              {developer.shortDescription && (
                <p className="text-lg md:text-xl font-editorial text-[var(--color-foreground)]/85 leading-relaxed">
                  {developer.shortDescription}
                </p>
              )}

              {developer.description && (
                <p className="text-sm md:text-base text-[var(--color-foreground)]/75 leading-relaxed max-w-2xl pt-1">
                  {developer.description}
                </p>
              )}

              {developer.websiteUrl && (
                <div className="pt-2">
                  <a
                    href={developer.websiteUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-xs uppercase tracking-wider font-semibold text-[var(--color-accent)] hover:underline"
                  >
                    <Globe className="w-4 h-4" />
                    Official Website
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>

            {/* Trust / Intelligence Stats Panel */}
            <div className="w-full md:w-72 shrink-0 bg-[var(--color-foreground)]/[0.02] border border-[var(--color-border)] rounded-lg p-5 space-y-4">
              <div className="text-xs uppercase font-semibold tracking-wider text-[var(--color-foreground)]/60">
                Developer Intelligence
              </div>

              <div className="grid grid-cols-2 gap-4 divide-x divide-[var(--color-border)]">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-[var(--color-foreground)]/65">
                    <Building2 className="w-3.5 h-3.5 text-[var(--color-accent)]" />
                    Published Projects
                  </div>
                  <div className="text-2xl font-display font-bold text-[var(--color-foreground)]">
                    {developer.projectCount}
                  </div>
                </div>

                <div className="space-y-1 pl-4">
                  <div className="flex items-center gap-1.5 text-xs text-[var(--color-foreground)]/65">
                    <MapPin className="w-3.5 h-3.5 text-[var(--color-accent)]" />
                    Active Hubs
                  </div>
                  <div className="text-2xl font-display font-bold text-[var(--color-foreground)]">
                    {developer.locations.length}
                  </div>
                </div>
              </div>

              {reraVerifiedCount > 0 && (
                <div className="pt-3 border-t border-[var(--color-border)] flex items-center gap-2 text-xs text-[var(--color-success)] font-medium">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>{reraVerifiedCount} RERA Verified Development{reraVerifiedCount > 1 ? 's' : ''}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content: Projects by Developer & Associated Locations */}
      <main className="max-w-6xl mx-auto px-6 py-12 space-y-12">
        {/* Projects Section */}
        <section aria-labelledby="developer-projects-heading" className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 border-b border-[var(--color-border)] pb-4">
            <div>
              <h2 id="developer-projects-heading" className="text-2xl font-display font-semibold text-[var(--color-foreground)]">
                Projects by {developer.name}
              </h2>
              <p className="text-xs text-[var(--color-foreground)]/65 mt-1">
                Canonical real estate projects published under {developer.name}.
              </p>
            </div>
            <span className="text-xs font-medium text-[var(--color-foreground)]/60">
              Showing {projects.length} verified project{projects.length === 1 ? '' : 's'}
            </span>
          </div>

          {projects.length === 0 ? (
            <div className="p-12 text-center border border-dashed border-[var(--color-border)] rounded-lg text-sm text-[var(--color-foreground)]/60">
              No published projects currently on record for this developer.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map(project => (
                <article
                  key={project.id}
                  id={`project-card-${project.id}`}
                  className="bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg p-5 flex flex-col justify-between hover:border-[var(--color-foreground)]/25 transition-colors space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-semibold uppercase tracking-wider text-[var(--color-accent)]">
                        {project.propertyType.replace('_', ' ')}
                      </span>
                      <span className="px-2 py-0.5 text-[11px] font-medium rounded bg-[var(--color-foreground)]/5 text-[var(--color-foreground)]/70">
                        {project.status.replace('_', ' ')}
                      </span>
                    </div>

                    <h3 className="text-lg font-display font-semibold text-[var(--color-foreground)] leading-snug">
                      {project.name}
                    </h3>

                    {project.location && (
                      <div className="flex items-center gap-1.5 text-xs text-[var(--color-foreground)]/70">
                        <MapPin className="w-3.5 h-3.5 text-[var(--color-foreground)]/50 shrink-0" />
                        <span>{project.location.name}</span>
                        <span className="text-[10px] text-[var(--color-foreground)]/45">({project.location.type})</span>
                      </div>
                    )}

                    {project.startingPrice && (
                      <div className="text-sm font-semibold text-[var(--color-foreground)]">
                        Starts at {formatPrice(project.startingPrice)}
                      </div>
                    )}
                  </div>

                  {/* RERA Badge Integrity */}
                  <div className="pt-3 border-t border-[var(--color-border)] flex items-center justify-between text-xs">
                    {project.hasVerifiedReraBadge ? (
                      <div className="inline-flex items-center gap-1 text-[var(--color-success)] font-medium">
                        <ShieldCheck className="w-4 h-4 shrink-0" />
                        <span>RERA Verified</span>
                      </div>
                    ) : project.reraRegistrationNumber ? (
                      <div className="text-[var(--color-foreground)]/55 text-[11px] truncate max-w-[200px]" title={project.reraRegistrationNumber}>
                        RERA: {project.reraRegistrationNumber} (Pending)
                      </div>
                    ) : (
                      <div className="text-[var(--color-foreground)]/45 text-[11px]">
                        RERA Not Provided
                      </div>
                    )}

                    <span className="text-[11px] text-[var(--color-foreground)]/50 font-mono">
                      {project.slug}
                    </span>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        {/* Associated Locations Derived from Projects */}
        <section aria-labelledby="developer-locations-heading" className="space-y-4 pt-6 border-t border-[var(--color-border)]">
          <div>
            <h2 id="developer-locations-heading" className="text-xl font-display font-semibold text-[var(--color-foreground)]">
              Active Regions & Locations
            </h2>
            <p className="text-xs text-[var(--color-foreground)]/65 mt-1">
              Geographic footprint derived from {developer.name}&apos;s published portfolio.
            </p>
          </div>

          {developer.locations.length === 0 ? (
            <p className="text-sm text-[var(--color-foreground)]/60">
              No geographic associations derived yet.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2.5">
              {developer.locations.map(location => (
                <div
                  key={location.id}
                  className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[var(--color-border)] bg-[var(--color-foreground)]/[0.02] text-xs text-[var(--color-foreground)]/80"
                >
                  <MapPin className="w-3 h-3 text-[var(--color-accent)]" />
                  <span className="font-medium">{location.name}</span>
                  <span className="text-[10px] text-[var(--color-foreground)]/50 uppercase tracking-wider">
                    {location.type}
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
