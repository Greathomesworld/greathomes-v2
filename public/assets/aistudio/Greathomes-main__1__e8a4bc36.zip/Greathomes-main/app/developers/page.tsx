import { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { developerService } from '@/src/domain/developers/services/developerService';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { Building2, MapPin, ChevronRight, ExternalLink, Sparkles } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Developers — Real Estate Developer Directory | Great Homes',
  description: 'Explore verified real estate developers, their project portfolios, and regional footprints across India.',
  alternates: {
    canonical: '/developers',
  },
};

export default async function DevelopersDirectoryPage() {
  await ensureSeedData();
  const { items: developers } = await developerService.listPublicDevelopers({
    page: 1,
    limit: 50,
    sort: 'name:asc',
  });

  return (
    <div className="min-h-screen bg-[var(--color-background)] text-[var(--color-foreground)]">
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="border-b border-[var(--color-border)] bg-[var(--color-background)]">
        <div className="max-w-6xl mx-auto px-6 py-3.5">
          <ol className="flex items-center space-x-2 text-xs text-[var(--color-foreground)]/60">
            <li>
              <Link href="/" className="hover:text-[var(--color-foreground)] transition-colors">
                Home
              </Link>
            </li>
            <li>
              <ChevronRight className="w-3.5 h-3.5 text-[var(--color-foreground)]/40" />
            </li>
            <li className="text-[var(--color-foreground)] font-medium" aria-current="page">
              Developers
            </li>
          </ol>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-6 py-12 space-y-8">
        <header className="space-y-3">
          <span className="text-xs uppercase tracking-wider font-semibold text-[var(--color-accent)]">
            Canonical Directory
          </span>
          <h1 className="text-3xl md:text-4xl font-display font-semibold text-[var(--color-foreground)]">
            Real Estate Developers
          </h1>
          <p className="text-base text-[var(--color-foreground)]/70 max-w-2xl">
            Verified property developers and builders. Explore comprehensive project portfolios, active development hubs, and verified credentials.
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {developers.map(dev => (
            <Link
              key={dev.id}
              href={`/developers/${dev.slug}`}
              className="group block bg-[var(--color-background)] border border-[var(--color-border)] rounded-lg p-6 hover:border-[var(--color-foreground)]/30 transition-colors"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-2">
                  {dev.logoUrl ? (
                    <div className="relative w-16 h-10">
                      <Image
                        src={dev.logoUrl}
                        alt={`${dev.name} logo`}
                        fill
                        className="object-contain"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  ) : (
                    <div className="w-16 h-10 flex items-center justify-center bg-[var(--color-foreground)]/5 border border-[var(--color-border)] rounded text-[10px] font-bold text-[var(--color-foreground)]/40 uppercase">
                      {dev.name.slice(0, 2)}
                    </div>
                  )}
                  {dev.featured && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[var(--color-accent)]">
                      <Sparkles className="w-3 h-3" />
                      Featured
                    </span>
                  )}
                </div>

                <div>
                  <h2 className="text-xl font-display font-semibold text-[var(--color-foreground)] group-hover:text-[var(--color-accent)] transition-colors">
                    {dev.name}
                  </h2>
                  {dev.shortDescription && (
                    <p className="text-xs text-[var(--color-foreground)]/70 mt-2 line-clamp-2 leading-relaxed">
                      {dev.shortDescription}
                    </p>
                  )}
                </div>

                <div className="pt-4 border-t border-[var(--color-border)] flex items-center justify-between text-xs text-[var(--color-foreground)]/70">
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-[var(--color-accent)]" />
                    <span>{dev.projectCount} Project{dev.projectCount === 1 ? '' : 's'}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[var(--color-foreground)]/45" />
                    <span>{dev.locations.length} Hub{dev.locations.length === 1 ? '' : 's'}</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  );
}
