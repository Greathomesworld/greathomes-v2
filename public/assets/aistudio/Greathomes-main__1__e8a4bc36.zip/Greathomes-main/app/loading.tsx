import { HomePageSkeleton } from '@/src/components/home/HomePageSkeleton';

export default function LoadingPage() {
  return <HomePageSkeleton />;
}
