import type { Metadata } from 'next';
import { ensureSeedData } from '@/src/infrastructure/seed';
import {
  projectRepository,
  projectMediaRepository,
  projectConfigurationRepository,
  projectReraRepository,
} from '@/src/infrastructure/repositories/projectProvider';
import { locationRepository } from '@/src/infrastructure/repositories/locationProvider';
import { developerRepository } from '@/src/infrastructure/repositories/developerProvider';
import { resaleListingService } from '@/src/domain/projects/services/resaleService';
import { rentalListingService } from '@/src/domain/projects/services/rentalService';
import { editorialService } from '@/src/domain/editorial/services/editorialService';

import { HomeHero } from '@/src/components/home/HomeHero';
import { HomeExplorePillars } from '@/src/components/home/HomeExplorePillars';
import { HomeProjectSpotlight } from '@/src/components/home/HomeProjectSpotlight';
import { HomeProjectStages } from '@/src/components/home/HomeProjectStages';
import { HomeExploreProjects, HomeProjectCardData } from '@/src/components/home/HomeExploreProjects';
import { HomeResaleSection, HomeListingCardData } from '@/src/components/home/HomeResaleSection';
import { HomeRentalSection } from '@/src/components/home/HomeRentalSection';
import { HomeLocationSection, HomeLocationCardData } from '@/src/components/home/HomeLocationSection';
import { HomePersonalizedSection } from '@/src/components/home/HomePersonalizedSection';
import { HomeWhyGreatHomes } from '@/src/components/home/HomeWhyGreatHomes';
import { HomeTrustCredibility } from '@/src/components/home/HomeTrustCredibility';
import { HomeExpertAssistance } from '@/src/components/home/HomeExpertAssistance';
import { HomeIntelligenceGuides } from '@/src/components/home/HomeIntelligenceGuides';
import { HomeAssistanceCta } from '@/src/components/home/HomeAssistanceCta';

export const metadata: Metadata = {
  title: 'Great Homes | Verified Residential Property Discovery in Kolkata',
  description:
    'Discover verified projects, resale homes and rentals across Kolkata — with the property intelligence and assistance you need to make a confident decision.',
  alternates: {
    canonical: '/',
  },
  openGraph: {
    title: 'Great Homes | Verified Residential Property Discovery in Kolkata',
    description:
      'Discover verified projects, resale homes and rentals across Kolkata with Great Homes property intelligence.',
    url: '/',
    siteName: 'Great Homes',
    locale: 'en_IN',
    type: 'website',
  },
};

function formatIndianPrice(amount?: number | null): string | undefined {
  if (amount === undefined || amount === null || isNaN(amount) || amount <= 0) return undefined;
  if (amount >= 10_000_000) {
    const cr = (amount / 10_000_000).toFixed(2).replace(/\.00$/, '');
    return `₹${cr} Cr`;
  }
  if (amount >= 100_000) {
    const l = (amount / 100_000).toFixed(2).replace(/\.00$/, '');
    return `₹${l} L`;
  }
  return `₹${amount.toLocaleString('en-IN')}`;
}

export default async function HomePage() {
  await ensureSeedData();

  // 1. Fetch Primary Master Data concurrently to eliminate blocking sequential roundtrips
  const [allProjects, allLocations, allDevelopers] = await Promise.all([
    projectRepository.findAll(),
    locationRepository.findAll(),
    developerRepository.list(),
  ]);

  const locationMap = new Map(allLocations.map((l) => [l.id, l]));
  const developerMap = new Map(allDevelopers.map((d) => [d.id, d]));

  const publishedProjects = allProjects.filter(
    (p: any) => p.lifecycleStatus === 'PUBLISHED' || p.isPublished === true
  );

  // The homepage renders one spotlight and at most eight project cards. Keep full
  // published data for counts, but fetch media/configuration/RERA details only for
  // those nine candidates instead of issuing three extra queries for every project.
  const spotlightCandidate =
    publishedProjects.find((p: any) => Boolean(p.featured)) ||
    publishedProjects[0] ||
    null;
  const exploreCandidates = spotlightCandidate
    ? publishedProjects.filter((p: any) => p.id !== spotlightCandidate.id).slice(0, 8)
    : [];
  const projectsForHomepage = spotlightCandidate
    ? [spotlightCandidate, ...exploreCandidates]
    : [];

  // 2. Fetch only the sub-entities required by visible homepage project cards.
  const homeProjectCards: HomeProjectCardData[] = await Promise.all(
    projectsForHomepage.map(async (p: any) => {
      const [media, configs, rera] = await Promise.all([
        projectMediaRepository.findByProjectId(p.id),
        projectConfigurationRepository.findByProjectId(p.id),
        projectReraRepository.findByProjectId(p.id),
      ]);

      const loc = p.locationId ? locationMap.get(p.locationId) : null;
      const dev = p.developerId ? developerMap.get(p.developerId) : null;

      // Filter out technical floor plans (.svg) for project card covers
      const imageMedia = media.filter(
        (m) =>
          m.mediaType === 'IMAGE' &&
          m.category !== 'FLOOR_PLANS' &&
          !m.url.endsWith('.svg')
      );
      const featuredMedia = imageMedia.find((m) => m.isFeatured) || imageMedia[0] || media.find((m) => m.isFeatured) || media[0];

      const bhkList = Array.from(
        new Set(
          configs
            .map((c: any) => c.bedroomCount || c.bedrooms)
            .filter((b): b is number => Boolean(b && b > 0))
            .sort((a, b) => a - b)
        )
      );

      const configStr = bhkList.length > 0 ? `${bhkList.join(', ')} BHK` : undefined;

      const carpetAreas = configs
        .map((c: any) => c.carpetArea || c.area)
        .filter((a: any): a is number => Boolean(a && a > 0));
      const minArea = carpetAreas.length > 0 ? Math.min(...carpetAreas) : null;
      const maxArea = carpetAreas.length > 0 ? Math.max(...carpetAreas) : null;
      const areaStr = minArea && maxArea
        ? minArea === maxArea
          ? `${minArea.toLocaleString('en-IN')} sq.ft`
          : `${minArea.toLocaleString('en-IN')} – ${maxArea.toLocaleString('en-IN')} sq.ft`
        : undefined;

      // Strict RERA verification semantics: Only VERIFIED if repository record status is strictly 'VERIFIED'
      const isReraVerified = rera?.status === 'VERIFIED';
      const reraNumber = isReraVerified
        ? rera?.registrationNumber || p.reraRegistrationNumber
        : undefined;

      return {
        id: p.id,
        name: p.name,
        slug: p.slug,
        developerName: dev?.name || 'Leading Developer',
        locationName: loc?.name || 'Kolkata',
        status: p.status,
        startingPrice: p.startingPrice,
        priceDisplay: formatIndianPrice(p.startingPrice),
        configurationString: configStr,
        areaString: areaStr,
        imageUrl: featuredMedia?.url,
        isReraVerified,
        reraNumber,
        isFeatured: Boolean(p.featured),
      };
    })
  );

  // 3. Featured Project Selection: Deterministic selection checking `featured === true`
  // Merlin Rise (featured: true, UNDER_CONSTRUCTION, verified RERA) has natural deterministic priority
  const eligibleFeaturedProjects = homeProjectCards.filter((p) => p.isFeatured === true);
  const spotlightProject = eligibleFeaturedProjects[0] || homeProjectCards[0] || null;

  // 4. Explore Projects Cards: Exclude the Spotlight project to avoid duplicate content on the homepage
  const exploreProjectsList = spotlightProject
    ? homeProjectCards.filter((p) => p.id !== spotlightProject.id)
    : homeProjectCards;

  // 5. Stage Discovery Counts from published projects (truthful, no fallback or fabrication)
  const stageCounts = {
    UPCOMING: publishedProjects.filter((p: any) => p.status === 'UPCOMING').length,
    NEW_LAUNCH: publishedProjects.filter((p: any) => p.status === 'NEW_LAUNCH').length,
    UNDER_CONSTRUCTION: publishedProjects.filter((p: any) => p.status === 'UNDER_CONSTRUCTION').length,
    READY_TO_MOVE: publishedProjects.filter((p: any) => p.status === 'READY_TO_MOVE').length,
  };

  // 6. Locations with Project Counts
  const publishedLocations = allLocations.filter(
    (l: any) => l.status === 'PUBLISHED' || l.lifecycleStatus === 'PUBLISHED' || !l.status
  );

  // Count projects in one pass instead of filtering the full project list per location.
  const projectCountByLocation = new Map<string, number>();
  for (const project of publishedProjects) {
    if (!project.locationId) continue;
    const locationId = String(project.locationId);
    projectCountByLocation.set(locationId, (projectCountByLocation.get(locationId) || 0) + 1);
  }

  const homeLocationCards: HomeLocationCardData[] = publishedLocations.map((loc) => ({
    id: loc.id,
    name: loc.name,
    slug: loc.slug,
    type: loc.type,
    description: loc.shortDescription || loc.description,
    projectCount: projectCountByLocation.get(String(loc.id)) || 0,
  }));

  // 6. Fetch Resale, Rental Listings & Published Editorial Guides concurrently
  const [resaleListings, rentalListings, publishedGuides] = await Promise.all([
    (async (): Promise<HomeListingCardData[]> => {
      try {
        const list = await resaleListingService.listPublicListings({ limit: 4 });
        if (Array.isArray(list)) {
          return list.map((item: any) => ({
            id: item.id,
            title: item.title || `${item.bedroomCount || 3} BHK Resale Home`,
            slug: item.slug || item.id,
            type: 'RESALE' as const,
            bhk: item.bedroomCount || 3,
            locationName: item.location?.name || 'Kolkata',
            projectName: item.project?.name,
            priceDisplay: formatIndianPrice(item.askingPrice) || 'Price on Request',
            imageUrl: item.media?.[0]?.url,
            isVerified: item.isVerified ?? true,
            areaString: item.carpetArea ? `${item.carpetArea.toLocaleString('en-IN')} sq.ft` : undefined,
          }));
        }
      } catch {
        // Graceful fallback
      }
      return [];
    })(),
    (async (): Promise<HomeListingCardData[]> => {
      try {
        const list = await rentalListingService.listPublicListings({ limit: 4 });
        if (Array.isArray(list)) {
          return list.map((item: any) => ({
            id: item.id,
            title: item.title || `${item.bedroomCount || 2} BHK Rental Home`,
            slug: item.slug || item.id,
            type: 'RENTAL' as const,
            bhk: item.bedroomCount || 2,
            locationName: item.location?.name || 'Kolkata',
            projectName: item.project?.name,
            priceDisplay: `${formatIndianPrice(item.monthlyRent) || 'Rent on Request'}/mo`,
            imageUrl: item.media?.[0]?.url,
            isVerified: item.isVerified ?? true,
            areaString: item.carpetArea ? `${item.carpetArea.toLocaleString('en-IN')} sq.ft` : undefined,
          }));
        }
      } catch {
        // Graceful fallback
      }
      return [];
    })(),
    (async () => {
      try {
        const res = await editorialService.getPublicArticles({ limit: 3 });
        return res.items || [];
      } catch {
        return [];
      }
    })(),
  ]);

  // Structured Data (JSON-LD)
  const websiteStructuredData = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: 'Great Homes',
    url: 'https://greathomes.in',
    potentialAction: {
      '@type': 'SearchAction',
      target: 'https://greathomes.in/discovery/search?q={search_term_string}',
      'query-input': 'required name=search_term_string',
    },
  };

  const realEstateAgentData = {
    '@context': 'https://schema.org',
    '@type': 'RealEstateAgent',
    name: 'Great Homes',
    description:
      'Residential property discovery and assisted home-buying web platform for Kolkata.',
    areaServed: {
      '@type': 'City',
      name: 'Kolkata',
      addressCountry: 'IN',
    },
    currenciesAccepted: 'INR',
    priceRange: '₹30 Lakh - ₹15 Crore',
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteStructuredData) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(realEstateAgentData) }}
      />

      <main className="min-h-screen bg-[#FAFAF8] text-[#111111]">
        {/* 1. Hero with Universal Search & Discovery Modes */}
        <HomeHero />

        {/* 2. Explore / Discovery Modes (New Launch, Resale, Rent with property photography) */}
        <HomeExplorePillars />

        {/* 3. Featured Project Spotlight (Verified featured===true, no duplication) */}
        {spotlightProject && <HomeProjectSpotlight project={spotlightProject} />}

        {/* 4. Project Stage Discovery (Timeline & Handover with truthful published counts) */}
        <HomeProjectStages stageCounts={stageCounts} />

        {/* 5. Explore Projects (Excludes spotlighted project to prevent duplicate content) */}
        <HomeExploreProjects projects={exploreProjectsList.slice(0, 8)} />

        {/* 6. Why Great Homes — Your Home Journey, Simplified (Design A) */}
        <HomeWhyGreatHomes />

        {/* 7. Verified Resale Homes in Kolkata (4-column grid) */}
        <HomeResaleSection listings={resaleListings} />

        {/* 8. Trust & Credibility — A More Confident Way to Find a Home (Design B) */}
        <HomeTrustCredibility />

        {/* 9. Rental Homes in Kolkata (4-column grid) */}
        <HomeRentalSection listings={rentalListings} />

        {/* 10. Popular Residential Locations in Kolkata (4-column grid) */}
        <HomeLocationSection locations={homeLocationCards} />

        {/* 11. Expert Assistance — Let Us Help You Find the Right Home (Design C) */}
        <HomeExpertAssistance />

        {/* 12. Account-Aware Continue Exploring / Set Preferences row */}
        <HomePersonalizedSection />

        {/* 13. Know Before You Buy (Intelligence pillar) */}
        <HomeIntelligenceGuides articles={publishedGuides} />

        {/* 14. Final Assistance (Talk to Great Homes) */}
        <HomeAssistanceCta />
      </main>
    </>
  );
}
