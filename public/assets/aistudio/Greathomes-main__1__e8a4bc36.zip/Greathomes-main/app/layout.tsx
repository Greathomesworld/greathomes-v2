import type { Metadata } from 'next';
import { Fjalla_One, Plus_Jakarta_Sans, Inter } from 'next/font/google';
import './../src/index.css';
import { Header } from './../src/components/layout/Header';
import { Footer } from './../src/components/layout/Footer';
import { EnquiryProvider } from './../src/components/enquiry/EnquiryContext';
import { GreatHomesEnquiryDialog } from './../src/components/enquiry/GreatHomesEnquiryDialog';
import { CustomerAuthProvider } from './../src/components/customer/CustomerAuthContext';
import { CustomerAuthModal } from './../src/components/customer/CustomerAuthModal';
import { MobileBottomNav } from './../src/components/layout/MobileBottomNav';
import { ComparisonTray } from './../src/components/comparison/ComparisonTray';

const fjallaOne = Fjalla_One({
  weight: '400',
  subsets: ['latin'],
  variable: '--font-fjalla',
  display: 'swap',
});

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-plus-jakarta',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Great Homes',
  description: 'Great Homes is a residential property discovery and assisted home-buying platform.',
  openGraph: {
    title: 'Great Homes',
    description: 'Great Homes is a residential property discovery and assisted home-buying platform.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${fjallaOne.variable} ${plusJakartaSans.variable} ${inter.variable}`}>
      <body className="flex min-h-screen flex-col bg-background text-foreground font-body antialiased">
        <EnquiryProvider>
          <CustomerAuthProvider>
            <Header />
            <main className="flex-grow">{children}</main>
            <Footer />
            <MobileBottomNav />
            <ComparisonTray />
            <GreatHomesEnquiryDialog />
            <CustomerAuthModal />
          </CustomerAuthProvider>
        </EnquiryProvider>
      </body>
    </html>
  );
}

