import React, { Suspense } from 'react';
import { Metadata } from 'next';
import { Header } from '@/src/components/layout/Header';
import { Footer } from '@/src/components/layout/Footer';
import { editorialService } from '@/src/domain/editorial/services/editorialService';
import { GuidesDirectoryView } from '@/src/components/editorial/GuidesDirectoryView';

export const metadata: Metadata = {
  title: 'Buyer Guides & Editorial Intelligence | Great Homes',
  description: 'Factual, independent property guides, area explanations, legal checks, and residential market intelligence for homebuyers in Kolkata.',
  openGraph: {
    title: 'Buyer Guides & Editorial Intelligence | Great Homes',
    description: 'Factual property guides, area explanations, legal checks, and market intelligence for homebuyers in Kolkata.',
  },
};

export default async function GuidesPage() {
  const { items, total } = await editorialService.getPublicArticles({ limit: 50 });

  return (
    <>
      <Header />
      <Suspense fallback={<div className="p-12 text-center font-display text-stone-500">Loading guides...</div>}>
        <GuidesDirectoryView initialArticles={items} totalArticles={total} />
      </Suspense>
      <Footer />
    </>
  );
}
