import { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

import { ChevronRight } from 'lucide-react';
import { projectIntelligenceService } from '@/src/domain/projects/services/projectIntelligenceService';
import { newBookingService } from '@/src/domain/projects/services/newBookingService';
import { resaleListingService } from '@/src/domain/projects/services/resaleService';
import { rentalListingService } from '@/src/domain/projects/services/rentalService';
import { developerService } from '@/src/domain/developers/services/developerService';
import { ensureSeedData } from '@/src/infrastructure/seed';

import { ProjectHero } from '@/src/components/projects/ProjectHero';
import { GreatHomesAdvisoryCard } from '@/src/components/projects/GreatHomesAdvisoryCard';
import { ProjectSectionNavigation, NavItem } from '@/src/components/projects/ProjectSectionNavigation';
import { ProjectSnapshot } from '@/src/components/projects/ProjectSnapshot';
import { ProjectConsiderations } from '@/src/components/projects/ProjectConsiderations';
import { ProjectConfigurationsSection } from '@/src/components/projects/ProjectConfigurationsSection';
import { ResaleSection } from '@/src/components/projects/ResaleSection';
import { RentalSection } from '@/src/components/projects/RentalSection';
import { ProjectMediaGallery } from '@/src/components/projects/ProjectMediaGallery';
import { ProjectMasterPlan } from '@/src/components/projects/ProjectMasterPlan';
import { ProjectConstructionGallery } from '@/src/components/projects/ProjectConstructionGallery';
import { ProjectWalkthrough } from '@/src/components/projects/ProjectWalkthrough';
import { ProjectAmenities } from '@/src/components/projects/ProjectAmenities';
import { ProjectLocationSection } from '@/src/components/projects/ProjectLocationSection';
import { buildProjectLocationViewModel } from '@/src/domain/projects/viewModels/projectLocationViewModel';
import { nearbyPlaceService } from '@/src/domain/places/services/nearbyPlaceService';
import { ProjectDeveloperSection } from '@/src/components/projects/ProjectDeveloperSection';
import { ProjectFaqAccordion } from '@/src/components/projects/ProjectFaqAccordion';
import { ProjectFinalCta } from '@/src/components/projects/ProjectFinalCta';
import { MobileStickyCta } from '@/src/components/projects/MobileStickyCta';
import { ProjectStructuredData } from '@/src/components/projects/ProjectStructuredData';
import { ProjectFloorPlanViewer } from '@/src/components/projects/ProjectFloorPlanViewer';
import { ProjectInteractionProvider } from '@/src/components/projects/ProjectInteractionContext';
import { Breadcrumbs, BreadcrumbItem } from '@/src/components/navigation/Breadcrumbs';
import { RecentlyViewedTracker } from '@/src/components/customer/RecentlyViewedTracker';
import { SaveButton } from '@/src/components/customer/SaveButton';

interface ProjectPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata(
  props: ProjectPageProps
): Promise<Metadata> {
  await ensureSeedData();
  const { slug } = await props.params;
  const project = await projectIntelligenceService.getProjectBySlug(slug);

  if (!project) {
    notFound();
  }

  const title = `${project.name} in ${project.location.name} — Real Estate Intelligence | Great Homes`;
  const description =
    project.shortDescription ||
    project.description ||
    `Explore verified residential configurations, pricing intelligence, RERA details, and amenities for ${project.name} by ${project.developer.name} on Great Homes V2.`;

  const canonicalUrl = `/projects/${project.slug}`;

  return {
    title,
    description,
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title,
      description,
      url: canonicalUrl,
      siteName: 'Great Homes',
      type: 'article',
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
    },
  };
}

export default async function ProjectDetailPage(props: ProjectPageProps) {
  await ensureSeedData();
  const { slug } = await props.params;
  const project = await projectIntelligenceService.getProjectBySlug(slug);

  if (!project) {
    notFound();
  }

  const newBookingConfigs = await newBookingService.getPublicNewBookingConfigurations(project.id);
  const resaleListings = await resaleListingService.getPublicListingsForProject(project.id);
  const rentalListings = await rentalListingService.getPublicListingsForProject(project.id);
  const developerDto = await developerService.getPublicDeveloperDtoById(project.developer.id).catch(() => null);

  const locationVm = buildProjectLocationViewModel(project.location, null, project);
  const nearbyPlaces =
    locationVm.hasValidCoordinates && locationVm.latitude !== null && locationVm.longitude !== null
      ? await nearbyPlaceService.getNearbyPlaces({
          latitude: locationVm.latitude,
          longitude: locationVm.longitude,
        })
      : [];

  // Check which sections actually exist to build clean navigation items
  const navItems: NavItem[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'snapshot', label: 'Snapshot' },
    { id: 'considerations', label: 'Why Consider' },
  ];

  if (project.configurations && project.configurations.length > 0) {
    navItems.push({ id: 'configurations', label: 'Configurations' });
  }

  if (resaleListings && resaleListings.length > 0) {
    navItems.push({ id: 'resale', label: `Resale (${resaleListings.length})` });
  }

  if (rentalListings && rentalListings.length > 0) {
    navItems.push({ id: 'rent', label: `For Rent (${rentalListings.length})` });
  }

  if (project.media && project.media.length > 0) {
    navItems.push({ id: 'gallery', label: 'Gallery' });
  }

  if (project.amenities && project.amenities.length > 0) {
    navItems.push({ id: 'amenities', label: 'Amenities' });
  }

  navItems.push({ id: 'location', label: 'Location & Connectivity' });
  navItems.push({ id: 'developer', label: 'Developer' });

  if (project.faqs && project.faqs.length > 0) {
    navItems.push({ id: 'faq', label: 'FAQs' });
  }

  // Construct canonical breadcrumb navigation
  const breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Home', href: '/' },
    { label: 'Projects', href: '/projects' },
  ];

  if (locationVm.breadcrumb && locationVm.breadcrumb.length > 0) {
    for (const node of locationVm.breadcrumb) {
      breadcrumbItems.push({
        label: node.name,
        href: `/locations/${node.slug}`,
      });
    }
  } else {
    breadcrumbItems.push({
      label: locationVm.name,
      href: `/locations/${locationVm.slug}`,
    });
  }

  breadcrumbItems.push({
    label: project.name,
    current: true,
  });

  return (
    <ProjectInteractionProvider>
      <div className="min-h-screen bg-[var(--color-background)] text-[var(--color-foreground)]">
      {/* JSON-LD Structured Data */}
      <ProjectStructuredData project={project} />

      {/* Editorial Breadcrumbs & Save Action */}
      <div className="bg-[var(--color-background)] border-b border-[var(--color-border)]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          <Breadcrumbs items={breadcrumbItems} />
          <SaveButton resourceType="PROJECT" resourceId={project.id} showLabel />
        </div>
      </div>

      <RecentlyViewedTracker resourceType="PROJECT" resourceId={project.id} />

      {/* Flagship Desktop & Mobile Layout Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-2 pb-28 lg:pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 xl:gap-4 items-start">
          {/* Main Left Column: Hero (6-col image + 3-col teasers on lg) + Sticky Nav + Content Sections */}
          <div className="col-span-1 lg:col-span-9 space-y-6 min-w-0">
            {/* Flagship Editorial Hero with Bento Grid & Mobile Layout */}
            <ProjectHero project={project} />

            {/* Sticky Section Navigation */}
            <ProjectSectionNavigation items={navItems} />

            {/* Main Content Sections with Balanced Visual Density */}
            <main className="space-y-12 pt-2">
              {/* Project Snapshot */}
              <ProjectSnapshot project={project} />

              {/* Project Description & Editorial Overview */}
              {project.description && (
                <section id="overview" aria-labelledby="project-overview-heading" className="space-y-4 pt-6 border-t border-[var(--color-border)]">
                  <div className="text-xs uppercase font-semibold tracking-wider text-[var(--color-accent)] mb-1">
                    Project Architecture
                  </div>
                  <h2 id="project-overview-heading" className="text-2xl font-display font-semibold text-[var(--color-foreground)]">
                    Editorial Project Overview
                  </h2>
                  <p className="text-base md:text-lg font-editorial text-[var(--color-foreground)]/85 leading-relaxed">
                    {project.description}
                  </p>
                </section>
              )}

              {/* Walkthrough (only if valid video media exists) */}
              <ProjectWalkthrough mediaList={project.media} projectName={project.name} />

              {/* Why Consider & Things to Keep in Mind */}
              <ProjectConsiderations project={project} />

              {/* Configurations Section */}
              <ProjectConfigurationsSection
                configurations={project.configurations}
                mediaList={project.media}
                projectName={project.name}
              />

              {/* Resale Intelligence Section (published only) */}
              <ResaleSection listings={resaleListings} projectSlug={project.slug} />

              {/* Rental Intelligence Section (published only) */}
              <RentalSection listings={rentalListings} projectSlug={project.slug} />

              {/* Rich Media Gallery */}
              <ProjectMediaGallery mediaList={project.media} projectName={project.name} />

              {/* Master Plan Section */}
              <ProjectMasterPlan mediaList={project.media} projectName={project.name} />

              {/* Construction Progress Section */}
              <ProjectConstructionGallery mediaList={project.media} projectName={project.name} />

              {/* Curated Amenities Section */}
              <ProjectAmenities amenities={project.amenities} />

              {/* Location & Connectivity Section */}
              <ProjectLocationSection
                location={locationVm}
                projectName={project.name}
                nearbyPlaces={nearbyPlaces}
              />

              {/* Developer Profile Section */}
              <ProjectDeveloperSection
                developer={project.developer}
                developerBio={developerDto?.shortDescription || developerDto?.description}
                developerWebsite={developerDto?.websiteUrl}
              />

              {/* FAQs Section */}
              <ProjectFaqAccordion faqs={project.faqs} />

              {/* Project Final CTA / Assisted Buying Anchor */}
              <ProjectFinalCta projectName={project.name} projectSlug={project.slug} />
            </main>
          </div>

          {/* Right Column: Desktop Sticky Great Homes Advisory Card */}
          <aside
            aria-label="Great Homes Advisory Sidebar"
            className="hidden lg:block lg:col-span-3 min-w-0 self-stretch"
          >
            <div className="sticky top-6 z-20">
              <GreatHomesAdvisoryCard project={project} />
            </div>
          </aside>
        </div>
      </div>

      {/* Mobile Sticky Conversion CTA Bar */}
      <MobileStickyCta project={project} />

      {/* Canonical Global Floor Plan Viewer */}
      <ProjectFloorPlanViewer
        configurations={project.configurations}
        mediaList={project.media}
        projectName={project.name}
      />
      </div>
    </ProjectInteractionProvider>
  );
}
