import { ProjectDetailSkeleton } from '@/src/components/projects/ProjectDetailSkeleton';

export default function Loading() {
  return (
    <div className="container mx-auto px-4 py-8">
      <ProjectDetailSkeleton />
    </div>
  );
}
