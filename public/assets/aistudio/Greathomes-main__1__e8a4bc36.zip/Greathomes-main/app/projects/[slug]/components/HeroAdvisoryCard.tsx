'use client';

import { Phone, Mail } from 'lucide-react';
import Image from 'next/image';

export function HeroAdvisoryCard() {
  return (
    <div className="w-full md:w-[380px] bg-white rounded-2xl p-6 shadow-[0_8px_30px_rgb(0,0,0,0.08)] border border-[#E5E5E5]">
      <div className="flex items-center gap-4 mb-6 pb-6 border-b border-[#E5E5E5]">
        <div className="relative w-14 h-14 rounded-full overflow-hidden shrink-0 border-2 border-[#FAFAF8]">
          <Image
            src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80"
            alt="Advisory Expert"
            fill
            className="object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div>
          <h3 className="text-[#111111] font-medium text-lg">Priya Sharma</h3>
          <p className="text-[#666666] text-sm">Principal Portfolio Advisor</p>
        </div>
      </div>

      <div className="space-y-4 mb-6">
        <p className="text-[#444444] text-sm leading-relaxed">
          Get exclusive insights, floorplan recommendations, and structured financing guidance for this property.
        </p>
      </div>

      <div className="flex flex-col gap-3">
        <button className="w-full bg-[#111111] hover:bg-black text-white font-medium py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors">
          <Phone className="w-4 h-4" />
          Request Callback
        </button>
        <button className="w-full bg-white hover:bg-[#FAFAF8] text-[#111111] font-medium py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 border border-[#E5E5E5] transition-colors">
          <Mail className="w-4 h-4" />
          Email Floorplans
        </button>
      </div>
    </div>
  );
}
