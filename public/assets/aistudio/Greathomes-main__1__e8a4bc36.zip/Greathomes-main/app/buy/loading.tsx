import { PropertyGridSkeleton } from '@/src/components/discovery/PropertyGridSkeleton';

export default function Loading() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="h-12 w-full bg-neutral-100 rounded-lg mb-6 animate-pulse" /> {/* Filter Bar Skeleton */}
      <PropertyGridSkeleton />
    </div>
  );
}
