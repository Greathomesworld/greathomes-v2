import { MetadataRoute } from 'next';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { locationSeoService } from '@/src/domain/locations/services/locationSeoService';
import { projectIntelligenceService } from '@/src/domain/projects/services/projectIntelligenceService';
import { developerRepository } from '@/src/infrastructure/repositories/developerProvider';
import { resaleListingRepository } from '@/src/domain/projects/repositories/resaleRepository';
import { rentalListingRepository } from '@/src/domain/projects/repositories/rentalRepository';

export const dynamic = 'force-dynamic';
export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  try {
    await ensureSeedData();
  } catch (seedErr) {
    console.warn("Seed initialization note during sitemap rendering:", seedErr);
  }

  const baseUrl = 'https://greathomes.co.in';

  // 1. Static high-level routes
  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: `${baseUrl}`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1.0,
    },
    {
      url: `${baseUrl}/locations`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.8,
    },
    {
      url: `${baseUrl}/projects`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.8,
    },
    {
      url: `${baseUrl}/developers`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.8,
    },
    {
      url: `${baseUrl}/buy`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.8,
    },
    {
      url: `${baseUrl}/rent`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.8,
    },
  ];

  // 2. SEO-eligible, published locations only
  let locationRoutes: MetadataRoute.Sitemap = [];
  try {
    const indexableLocations = await locationSeoService.getIndexableLocations();
    locationRoutes = indexableLocations.map((loc) => ({
      url: `${baseUrl}/locations/${loc.slug}`,
      lastModified: loc.updatedAt ? new Date(loc.updatedAt) : new Date(),
      changeFrequency: 'weekly',
      priority: 0.7,
    }));
  } catch (error) {
    console.error("Error fetching locations for sitemap, skipping locations:", error);
  }

  // 3. Published projects
  let projectRoutes: MetadataRoute.Sitemap = [];
  try {
    const projectsRes = await projectIntelligenceService.listProjects({ limit: 500 }, false);
    const publishedProjects = projectsRes.data.filter(
      (p) => p.lifecycleStatus === 'PUBLISHED'
    );
    projectRoutes = publishedProjects.map((p) => ({
      url: `${baseUrl}/projects/${p.slug}`,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 0.8,
    }));
  } catch (error) {
    console.error("Error fetching projects for sitemap, skipping projects:", error);
  }

  // 4. Published developers
  let developerRoutes: MetadataRoute.Sitemap = [];
  try {
    const publishedDevs = await developerRepository.list({ status: 'PUBLISHED' });
    developerRoutes = publishedDevs.map((d) => ({
      url: `${baseUrl}/developers/${d.slug}`,
      lastModified: d.updatedAt ? new Date(d.updatedAt) : new Date(),
      changeFrequency: 'weekly',
      priority: 0.7,
    }));
  } catch (error) {
    console.error("Error fetching developers for sitemap, skipping developers:", error);
  }

  // 5. Published resale listings
  let resaleRoutes: MetadataRoute.Sitemap = [];
  try {
    const publishedResales = await resaleListingRepository.findAll({ lifecycleStatus: 'PUBLISHED' });
    resaleRoutes = publishedResales.map((r) => ({
      url: `${baseUrl}/buy/${r.slug}`,
      lastModified: r.updatedAt ? new Date(r.updatedAt) : new Date(),
      changeFrequency: 'weekly',
      priority: 0.7,
    }));
  } catch (error) {
    console.error("Error fetching resale listings for sitemap, skipping resale:", error);
  }

  // 6. Published rental listings
  let rentalRoutes: MetadataRoute.Sitemap = [];
  try {
    const publishedRentals = await rentalListingRepository.findAll({ lifecycleStatus: 'PUBLISHED' });
    rentalRoutes = publishedRentals.map((r) => ({
      url: `${baseUrl}/rent/${r.slug}`,
      lastModified: r.updatedAt ? new Date(r.updatedAt) : new Date(),
      changeFrequency: 'weekly',
      priority: 0.7,
    }));
  } catch (error) {
    console.error("Error fetching rental listings for sitemap, skipping rentals:", error);
  }

  return [
    ...staticRoutes,
    ...locationRoutes,
    ...projectRoutes,
    ...developerRoutes,
    ...resaleRoutes,
    ...rentalRoutes,
  ];
}
