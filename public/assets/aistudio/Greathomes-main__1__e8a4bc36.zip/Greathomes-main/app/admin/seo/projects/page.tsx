'use client';

import React from 'react';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { AdminEmptyState } from '@/src/components/admin/AdminEmptyState';
import { Search, Sparkles } from 'lucide-react';

export default function AdminProjectSeoPage() {
  return (
    <div className="space-y-6 pb-12">
      <AdminPageHeader
        title="Project SEO Intelligence"
        description="Audit OpenGraph cards, meta titles, descriptions, canonical URLs, and schema.org JSON-LD structured data for project pages."
        breadcrumbs={[
          { label: 'Content / SEO', href: '/admin/seo/projects' },
          { label: 'Project SEO' },
        ]}
      />

      <div className="px-6">
        <AdminEmptyState
          title="Project SEO Optimization Console"
          description="SEO metadata, canonical tags, and RealEstateListing JSON-LD schema are auto-calculated from project domain models. Custom overrides will open in Phase 06.7."
          icon={<Search className="h-8 w-8 text-neutral-400" />}
          actionLabel="View Projects Catalog"
          onAction={() => window.location.href = '/admin/projects'}
        />
      </div>
    </div>
  );
}
