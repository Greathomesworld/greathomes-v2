'use client';

import React from 'react';
import { AdminPageHeader } from '@/src/components/admin/AdminPageHeader';
import { AdminEmptyState } from '@/src/components/admin/AdminEmptyState';
import { HelpCircle, Plus } from 'lucide-react';

export default function AdminFaqsPage() {
  return (
    <div className="space-y-6 pb-12">
      <AdminPageHeader
        title="Project FAQs Intelligence"
        description="Curate project-level frequently asked questions, buyer answers, possession timelines, and pricing disclosures."
        breadcrumbs={[
          { label: 'Project Intelligence', href: '/admin/intelligence/configurations' },
          { label: 'Project FAQs' },
        ]}
        primaryAction={{
          label: 'Add Project FAQ (Phase 06.3)',
          onClick: () => alert('Project FAQ editor is scheduled for Phase 06.3.'),
          icon: <Plus className="h-4 w-4" />,
        }}
      />

      <div className="px-6">
        <AdminEmptyState
          title="Project FAQ Management"
          description="Frequently asked questions for residential projects are linked directly to project intelligence. FAQ editors will open in Phase 06.3."
          icon={<HelpCircle className="h-8 w-8 text-neutral-400" />}
          actionLabel="View Projects Catalog"
          onAction={() => window.location.href = '/admin/projects'}
        />
      </div>
    </div>
  );
}
