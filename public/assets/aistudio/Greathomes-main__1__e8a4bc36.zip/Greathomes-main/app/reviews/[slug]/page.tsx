import React from 'react';
import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Header } from '@/src/components/layout/Header';
import { Footer } from '@/src/components/layout/Footer';
import { editorialService } from '@/src/domain/editorial/services/editorialService';
import { ReviewDetailView } from '@/src/components/editorial/ReviewDetailView';

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const review = await editorialService.getPublicArticleBySlug(slug);
  if (!review) return { title: 'Project Review Not Found | Great Homes' };

  return {
    title: `${review.seoTitle || review.title} | Great Homes Review`,
    description: review.seoDescription || review.excerpt,
    alternates: {
      canonical: review.canonicalUrl,
    },
    openGraph: {
      title: review.seoTitle || review.title,
      description: review.seoDescription || review.excerpt,
      type: 'article',
    },
  };
}

export default async function ReviewDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const review = await editorialService.getPublicArticleBySlug(slug);

  if (!review) {
    notFound();
  }

  return (
    <>
      <Header />
      <ReviewDetailView review={review} />
      <Footer />
    </>
  );
}
