import { notFound } from 'next/navigation';
import { Metadata } from 'next';
import Link from 'next/link';
import {
  CheckCircle2,
  MapPin,
  Building2,
  Compass,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Calendar,
  Sparkles,
  Home,
  Shield,
  Award,
  FileText,
  Lock,
  Dumbbell,
  Waves,
  Trees,
  Car,
  Zap,
  PhoneCall,
  BedDouble,
  Layers,
  Clock,
  Maximize2,
  FileCheck,
  Receipt,
  Check,
} from 'lucide-react';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { rentalService } from '@/src/domain/projects/services/rentalService';
import { RentalListingDetailViewModel } from '@/src/domain/projects/viewModels/listingDetailViewModel';
import { ListingMediaGallery } from '@/src/components/discovery/ListingMediaGallery';
import { MobileStickyCta } from '@/src/components/projects/MobileStickyCta';
import { RecentlyViewedTracker } from '@/src/components/customer/RecentlyViewedTracker';
import { SaveButton } from '@/src/components/customer/SaveButton';

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  await ensureSeedData();
  const { slug } = await params;
  const listing = await rentalService.getPublicListingDetailBySlug(slug);

  if (!listing) {
    return {
      title: 'Rental Property Not Found | Great Homes',
      description: 'The requested rental property listing is not available or has been unlisted.',
      robots: { index: false, follow: false },
    };
  }

  const locationContext = listing.project?.locationName
    ? ` in ${listing.project.locationName}`
    : listing.project?.name
    ? ` at ${listing.project.name}`
    : '';

  const title = `${listing.configuration} For Rent${locationContext} · ${listing.formattedMonthlyRent} | Great Homes`;
  const description = listing.description
    ? listing.description.slice(0, 155)
    : `Explore this verified ${listing.configuration} rental apartment${locationContext}. Monthly rent: ${listing.formattedMonthlyRent}.`;

  const canonicalUrl = `https://greathomes.co.in/rent/${listing.slug}`;

  return {
    title,
    description,
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title,
      description,
      url: canonicalUrl,
      type: 'website',
      images: listing.media.length > 0 ? [{ url: listing.media[0].url }] : undefined,
    },
  };
}

// Helper to choose appropriate icon for amenities
function getAmenityIcon(name: string) {
  const lower = name.toLowerCase();
  if (lower.includes('gym') || lower.includes('fitness')) return Dumbbell;
  if (lower.includes('pool') || lower.includes('swim')) return Waves;
  if (lower.includes('garden') || lower.includes('park') || lower.includes('landscape')) return Trees;
  if (lower.includes('club') || lower.includes('lounge')) return Building2;
  if (lower.includes('parking') || lower.includes('garage')) return Car;
  if (lower.includes('power') || lower.includes('backup')) return Zap;
  if (lower.includes('security') || lower.includes('cctv') || lower.includes('guard')) return Shield;
  return Sparkles;
}

export default async function RentalListingDetailPage({ params }: PageProps) {
  await ensureSeedData();
  const { slug } = await params;
  const listing = await rentalService.getPublicListingDetailBySlug(slug);

  if (!listing) {
    notFound();
  }

  // Structured Data (JSON-LD) - strictly verified public facts only
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'Apartment',
    name: listing.title,
    description: listing.description || `${listing.configuration} rental apartment in Kolkata`,
    url: `https://greathomes.co.in/rent/${listing.slug}`,
    numberOfRooms: listing.bedroomCount,
    numberOfBedrooms: listing.bedroomCount,
    floorSize: listing.carpetArea
      ? {
          '@type': 'QuantitativeValue',
          value: listing.carpetArea,
          unitCode: 'FTK',
        }
      : undefined,
    offers: {
      '@type': 'Offer',
      price: listing.monthlyRent,
      priceCurrency: 'INR',
      businessFunction: 'http://purl.org/goodrelations/v1#LeaseOut',
      availability: 'https://schema.org/InStock',
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <main className="min-h-screen bg-[#FAFAF8] text-[#111111] pb-24 lg:pb-16 select-none sm:select-auto">
        {/* A. Breadcrumb / Context Navigation */}
        <nav
          aria-label="Breadcrumb"
          className="border-b border-[var(--color-border)]/60 bg-white"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
            <ol className="flex items-center flex-wrap gap-1.5 text-xs text-[#111111]/60 font-body">
              <li>
                <Link href="/" className="hover:text-[#111111] transition-colors flex items-center gap-1">
                  <Home className="w-3.5 h-3.5" />
                  <span>Home</span>
                </Link>
              </li>
              <li><ChevronRight className="w-3.5 h-3.5 text-[#111111]/30" /></li>
              <li>
                <Link href="/rent" className="hover:text-[#111111] transition-colors">
                  Rent
                </Link>
              </li>
              {listing.project && (
                <>
                  <li><ChevronRight className="w-3.5 h-3.5 text-[#111111]/30" /></li>
                  <li>
                    <Link
                      href={listing.project.url}
                      className="hover:text-[#111111] transition-colors truncate max-w-[160px] sm:max-w-xs"
                    >
                      {listing.project.name}
                    </Link>
                  </li>
                </>
              )}
              <li><ChevronRight className="w-3.5 h-3.5 text-[#111111]/30" /></li>
              <li
                aria-current="page"
                className="text-[#111111] font-medium truncate max-w-[200px] sm:max-w-sm"
              >
                {listing.configuration}
              </li>
            </ol>
            <SaveButton resourceType="RENTAL_LISTING" resourceId={listing.id} showLabel />
          </div>
        </nav>

        <RecentlyViewedTracker resourceType="RENTAL_LISTING" resourceId={listing.id} />

        {/* B. Rental Hero / Gallery Section */}
        <section className="bg-[#111111] text-white py-6 sm:py-8 lg:py-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 sm:space-y-8">
            {/* Hero Header Details */}
            <div className="flex flex-col lg:flex-row gap-6 items-start lg:items-end justify-between pb-6 border-b border-white/10">
              <div className="space-y-3 max-w-3xl">
                {/* Badges */}
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded text-[11px] font-semibold bg-[#218C5A] text-white font-display tracking-wider uppercase">
                    For Rent
                  </span>
                  {listing.isVerified && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[11px] font-medium bg-[#218C5A]/80 text-white font-display">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Verified Listing
                    </span>
                  )}
                  <span className="px-2.5 py-0.5 rounded text-[11px] font-medium bg-white/10 text-white/90 border border-white/15 font-display">
                    {listing.listingPartyLabel}
                  </span>
                </div>

                {/* Primary Editorial Title */}
                <h1 className="text-2xl sm:text-3xl md:text-4xl font-serif font-bold text-white tracking-tight">
                  {listing.title}
                </h1>

                {/* Micro-Location & Project Connection */}
                <div className="flex items-center flex-wrap gap-2 text-xs sm:text-sm text-white/70 font-body">
                  <MapPin className="w-4 h-4 text-[#E85D3F] shrink-0" />
                  <span>{listing.project?.locationName || 'Prime Residential Corridor, Kolkata'}</span>
                  {listing.project && (
                    <>
                      <span className="text-white/30">·</span>
                      <Link
                        href={listing.project.url}
                        className="hover:text-white underline decoration-white/30 underline-offset-4 font-display font-medium text-white/90"
                      >
                        Part of {listing.project.name}
                      </Link>
                    </>
                  )}
                </div>
              </div>

              {/* C. Monthly Rent Price Block (Strictly NO rent/sq.ft. calculation) */}
              <div className="bg-white/5 border border-white/10 rounded-2xl p-4 sm:p-5 w-full sm:w-auto shrink-0 flex flex-col justify-end space-y-1">
                <span className="text-[11px] font-display uppercase tracking-wider text-white/60 block">
                  Monthly Rent
                </span>
                <span className="text-3xl sm:text-4xl font-display font-bold text-white tracking-tight">
                  {listing.formattedMonthlyRent}
                </span>

                {listing.formattedMaintenance && (
                  <span className="text-xs text-white/70 font-body block pt-0.5">
                    + Maintenance: {listing.formattedMaintenance}
                  </span>
                )}

                {listing.formattedSecurityDeposit && (
                  <span className="text-[11px] text-white/50 font-body block">
                    Security Deposit: {listing.formattedSecurityDeposit}
                  </span>
                )}
              </div>
            </div>

            {/* Reusable Gallery Component */}
            <ListingMediaGallery media={listing.media} title={listing.title} category="rental" />
          </div>
        </section>

        {/* Content Layout Grid */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 sm:gap-10 items-start">
            {/* Left 2 Columns: Core Content Sections in Canonical Order */}
            <div className="lg:col-span-2 space-y-8 sm:space-y-10">
              {/* C. Monthly Rent + Rental Summary Bar */}
              <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 shadow-xs">
                <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                  Overview
                </span>
                <h2 className="text-lg sm:text-xl font-display font-bold text-[#111111] mb-5">
                  Rental Highlights
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 flex flex-col justify-between">
                    <div className="flex items-center justify-between text-[#111111]/40 mb-2">
                      <span className="text-[11px] font-display uppercase tracking-wider">Bedrooms</span>
                      <BedDouble className="w-4 h-4 text-[#111111]/60" />
                    </div>
                    <span className="text-base sm:text-lg font-display font-bold text-[#111111]">
                      {listing.bedroomCount} BHK
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 flex flex-col justify-between">
                    <div className="flex items-center justify-between text-[#111111]/40 mb-2">
                      <span className="text-[11px] font-display uppercase tracking-wider">Carpet Area</span>
                      <Maximize2 className="w-4 h-4 text-[#111111]/60" />
                    </div>
                    <span className="text-base sm:text-lg font-display font-bold text-[#111111]">
                      {listing.carpetAreaDisplay || 'On Request'}
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 flex flex-col justify-between">
                    <div className="flex items-center justify-between text-[#111111]/40 mb-2">
                      <span className="text-[11px] font-display uppercase tracking-wider">Floor Level</span>
                      <Layers className="w-4 h-4 text-[#111111]/60" />
                    </div>
                    <span className="text-base sm:text-lg font-display font-bold text-[#111111]">
                      {listing.floorCategoryDisplay}
                    </span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 flex flex-col justify-between">
                    <div className="flex items-center justify-between text-[#111111]/40 mb-2">
                      <span className="text-[11px] font-display uppercase tracking-wider">Availability</span>
                      <Clock className="w-4 h-4 text-[#111111]/60" />
                    </div>
                    <span className="text-base sm:text-lg font-display font-bold text-[#111111]">
                      {listing.possessionDisplay}
                    </span>
                  </div>
                </div>
              </div>

              {/* D. Rental Property Facts */}
              <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-8 shadow-xs space-y-5">
                <div>
                  <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                    Specifications
                  </span>
                  <h2 className="text-lg sm:text-xl font-display font-bold text-[#111111]">
                    Rental Property Facts
                  </h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3.5 gap-x-8 text-sm divide-y sm:divide-y-0 divide-[var(--color-border)]/60">
                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Property Type</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.propertyTypeDisplay}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Configuration</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.configuration}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Carpet Area</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.carpetAreaDisplay || 'On Request'}</span>
                  </div>

                  {listing.builtUpAreaDisplay && (
                    <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                      <span className="text-[#111111]/60 font-body">Built-Up Area</span>
                      <span className="font-display font-semibold text-[#111111]">{listing.builtUpAreaDisplay}</span>
                    </div>
                  )}

                  {listing.superBuiltUpAreaDisplay && (
                    <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                      <span className="text-[#111111]/60 font-body">Super Built-Up Area</span>
                      <span className="font-display font-semibold text-[#111111]">{listing.superBuiltUpAreaDisplay}</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Furnishing Status</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.furnishingDisplay}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Facing Direction</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.facingDisplay}</span>
                  </div>

                  {/* EXACT FLOOR PRIVACY: floor category only, never exact floor number */}
                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Floor Level</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.floorCategoryDisplay}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Availability Status</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.possessionDisplay}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Listing Category</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.listingPartyLabel}</span>
                  </div>
                </div>
              </div>

              {/* E. About This Home */}
              <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-8 shadow-xs space-y-4">
                <div>
                  <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                    Editorial Overview
                  </span>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#111111]">
                    About This Home
                  </h2>
                </div>
                <div className="text-sm sm:text-base text-[#111111]/80 font-body leading-relaxed whitespace-pre-line">
                  {listing.description ||
                    'A well-appointed rental residence offering practical living space, ventilation, and convenient proximity to transit routes.'}
                </div>
              </div>

              {/* F. Amenities */}
              <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-8 shadow-xs space-y-5">
                <div>
                  <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                    Lifestyle & Facilities
                  </span>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#111111]">
                    Amenities & Community Facilities
                  </h2>
                </div>

                {listing.amenities && listing.amenities.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                    {listing.amenities.map((amenity) => {
                      const IconComponent = getAmenityIcon(amenity.name);
                      return (
                        <div
                          key={amenity.id}
                          className="p-3.5 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 flex items-center gap-3 transition-colors hover:border-[#111111]/20"
                        >
                          <div className="w-8 h-8 rounded-lg bg-white border border-[var(--color-border)] flex items-center justify-center text-[#218C5A] shrink-0">
                            <IconComponent className="w-4 h-4" />
                          </div>
                          <span className="text-xs sm:text-sm font-display font-medium text-[#111111]">
                            {amenity.name}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 text-xs sm:text-sm text-[#111111]/70 font-body flex items-center gap-2.5">
                    <Sparkles className="w-4 h-4 text-[#218C5A] shrink-0" />
                    <span>
                      Residents enjoy full access to community amenities, designated parking, round-the-clock security, and dedicated maintenance teams.
                    </span>
                  </div>
                )}
              </div>

              {/* G. Rental Terms & Lease Conditions */}
              <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-8 shadow-xs space-y-5">
                <div>
                  <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                    Lease Conditions
                  </span>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#111111]">
                    Rental Terms & Financial Breakdown
                  </h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3.5 gap-x-8 text-sm divide-y sm:divide-y-0 divide-[var(--color-border)]/60">
                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Monthly Rent</span>
                    <span className="font-display font-bold text-[#111111]">{listing.formattedMonthlyRent}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Security Deposit</span>
                    <span className="font-display font-semibold text-[#111111]">
                      {listing.formattedSecurityDeposit ? `${listing.formattedSecurityDeposit} (Refundable)` : 'Standard refundable deposit applicable'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Monthly Maintenance</span>
                    <span className="font-display font-semibold text-[#111111]">
                      {listing.formattedMaintenance ? `${listing.formattedMaintenance} (Direct to society)` : 'Included in rent / As per society'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Lease Duration</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.leaseDuration || '11 Months (Renewable)'}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Notice Period</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.noticePeriod || '1 Month Standard'}</span>
                  </div>

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Possession / Move-in</span>
                    <span className="font-display font-semibold text-[#111111]">{listing.possessionDisplay}</span>
                  </div>

                  {listing.availabilityDate && (
                    <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                      <span className="text-[#111111]/60 font-body">Available From</span>
                      <span className="font-display font-semibold text-[#111111]">
                        {new Date(listing.availabilityDate).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </span>
                    </div>
                  )}

                  <div className="flex justify-between items-center py-2 sm:border-b sm:border-[var(--color-border)]/60">
                    <span className="text-[#111111]/60 font-body">Tenancy Agreement</span>
                    <span className="font-display font-semibold text-[#111111]">Standard Registered Agreement</span>
                  </div>
                </div>
              </div>

              {/* H. Project Context — Only rendered when listing is linked to a Project */}
              {listing.project && (
                <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-8 shadow-xs space-y-4">
                  <div>
                    <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                      Parent Enclave
                    </span>
                    <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#111111]">
                      Connected Project Enclave
                    </h2>
                  </div>

                  <div className="p-5 rounded-xl bg-neutral-900 text-white space-y-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div>
                        <span className="text-xs uppercase tracking-wider text-white/50 font-display block">
                          Master Project
                        </span>
                        <h3 className="text-lg sm:text-xl font-display font-bold text-white">
                          {listing.project.name}
                        </h3>
                        {listing.project.locationName && (
                          <div className="flex items-center gap-1.5 text-xs text-white/70 font-body mt-1">
                            <MapPin className="w-3.5 h-3.5 text-[#218C5A]" />
                            <span>{listing.project.locationName}</span>
                          </div>
                        )}
                      </div>

                      <Link
                        href={listing.project.url}
                        className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#218C5A] hover:bg-[#1a7047] text-white text-xs font-semibold font-display transition-colors shrink-0 shadow-xs"
                      >
                        <span>Explore Enclave Details</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </Link>
                    </div>

                    <p className="text-xs text-white/70 font-body leading-relaxed pt-2 border-t border-white/10">
                      Explore clubhouse amenities, master layout, and residential community facilities in the complete {listing.project.name} enclave.
                    </p>
                  </div>
                </div>
              )}

              {/* I. Location Context */}
              <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-8 shadow-xs space-y-4">
                <div>
                  <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                    Connectivity & Neighborhood
                  </span>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#111111]">
                    Location Context
                  </h2>
                </div>

                <div className="space-y-3 text-sm text-[#111111]/80 font-body leading-relaxed">
                  <p>
                    Strategically located in{' '}
                    <strong className="font-semibold text-[#111111]">
                      {listing.project?.locationName || 'Kolkata’s established residential corridor'}
                    </strong>
                    , this rental property offers straightforward access to major transit lines, arterial roadways, commercial business parks, healthcare institutions, and daily convenience hubs.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="p-3.5 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 text-xs font-body space-y-1">
                      <span className="font-display font-semibold text-[#111111] block">Transit Connectivity</span>
                      <span className="text-[#111111]/70">Smooth commute via major city thoroughfares and upcoming metro infrastructure.</span>
                    </div>
                    <div className="p-3.5 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 text-xs font-body space-y-1">
                      <span className="font-display font-semibold text-[#111111] block">Civic Essentials</span>
                      <span className="text-[#111111]/70">Convenient access to neighborhood groceries, schools, diagnostic clinics, and dining.</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* J. Listing Information / Trust */}
              <div className="bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-8 shadow-xs space-y-6">
                <div>
                  <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold block mb-1">
                    Tenant Assurance
                  </span>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-[#111111]">
                    Great Homes Trust & Verification Standards
                  </h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 space-y-2">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-[#218C5A] shrink-0" />
                      <h3 className="text-sm font-display font-bold text-[#111111]">Verified Ownership</h3>
                    </div>
                    <p className="text-xs text-[#111111]/70 font-body leading-relaxed">
                      Landlord credentials, property title documents, and lease terms are verified before this listing is published.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 space-y-2">
                    <div className="flex items-center gap-2">
                      <Lock className="w-5 h-5 text-[#E85D3F] shrink-0" />
                      <h3 className="text-sm font-display font-bold text-[#111111]">Floor & Unit Privacy</h3>
                    </div>
                    <p className="text-xs text-[#111111]/70 font-body leading-relaxed">
                      Exact unit and floor numbers are protected for resident privacy until your assisted in-person viewing is scheduled.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 space-y-2">
                    <div className="flex items-center gap-2">
                      <Receipt className="w-5 h-5 text-[#111111] shrink-0" />
                      <h3 className="text-sm font-display font-bold text-[#111111]">Transparent Terms</h3>
                    </div>
                    <p className="text-xs text-[#111111]/70 font-body leading-relaxed">
                      Clear demarcation of monthly rent, maintenance dues, and refundable deposit with zero unexpected tenant surprises.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#FAFAF8] border border-[var(--color-border)]/60 space-y-2">
                    <div className="flex items-center gap-2">
                      <FileCheck className="w-5 h-5 text-[#111111]/70 shrink-0" />
                      <h3 className="text-sm font-display font-bold text-[#111111]">Registered Agreement</h3>
                    </div>
                    <p className="text-xs text-[#111111]/70 font-body leading-relaxed">
                      Assistance with standardized residential rental agreement drafting, police verification guidelines, and move-in checklists.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: K. Great Homes Assistance (Desktop Sticky Sidebar) */}
            <aside className="space-y-6">
              <div className="sticky top-6 bg-white rounded-2xl border border-[var(--color-border)] p-6 sm:p-7 shadow-xs space-y-6">
                <div className="space-y-1.5 border-b border-[var(--color-border)] pb-5">
                  <span className="text-[11px] font-display uppercase tracking-wider text-[#218C5A] font-semibold">
                    Great Homes Rental Concierge
                  </span>
                  <h3 className="text-xl font-serif font-bold text-[#111111]">
                    Interested in renting this home?
                  </h3>
                  <p className="text-xs text-[#111111]/70 font-body leading-relaxed">
                    We coordinate scheduled property viewings, verified tenant onboarding, and registered rent agreement drafting.
                  </p>
                </div>

                <div className="space-y-3.5">
                  <div className="flex items-start gap-2.5 text-xs text-[#111111]/80 font-body">
                    <ShieldCheck className="w-4 h-4 text-[#218C5A] shrink-0 mt-0.5" />
                    <span>Verified owner credentials and documented lease terms</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-[#111111]/80 font-body">
                    <Sparkles className="w-4 h-4 text-[#E85D3F] shrink-0 mt-0.5" />
                    <span>Dedicated rental concierge support throughout move-in</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-[#111111]/80 font-body">
                    <Clock className="w-4 h-4 text-[#111111]/60 shrink-0 mt-0.5" />
                    <span>Prompt verification and scheduled visit slots</span>
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <Link
                    href={`/rent?enquire=${listing.slug}`}
                    className="w-full py-3.5 px-4 rounded-xl bg-[#E85D3F] hover:bg-[#D44C2F] text-white text-xs font-semibold font-display flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <span>Schedule Site Visit</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>

                  <p className="text-[11px] text-center text-[#111111]/50 font-body">
                    Zero spam · Direct concierge assistance from Great Homes
                  </p>
                </div>

                <div className="pt-4 border-t border-[var(--color-border)] text-xs text-[#111111]/60 font-body space-y-1">
                  <div className="flex justify-between">
                    <span>Listing Reference:</span>
                    <span className="font-mono text-[#111111]">{listing.slug}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Listed By:</span>
                    <span className="font-medium text-[#111111]">{listing.listingPartyLabel}</span>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </section>

        {/* L. Mobile Sticky CTA: Reusing MobileStickyCta from src/components/projects/MobileStickyCta.tsx */}
        <MobileStickyCta
          projectName={listing.title}
          priceLabel="Monthly Rent"
          formattedPrice={listing.formattedMonthlyRent}
          ctaText="Schedule Visit"
          ctaHref={`/rent?enquire=${listing.slug}`}
        />
      </main>
    </>
  );
}
