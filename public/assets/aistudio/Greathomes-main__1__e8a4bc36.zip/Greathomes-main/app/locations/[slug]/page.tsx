import React from 'react';
import { Metadata } from 'next';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

import { locationService, LOCATION_ALIASES } from '@/src/domain/locations/services/locationService';
import { locationSeoService } from '@/src/domain/locations/services/locationSeoService';
import { locationIntelligenceService } from '@/src/domain/marketIntelligence/services/locationIntelligenceService';
import { propertyDiscoveryService } from '@/src/domain/projects/services/propertyDiscoveryService';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { Breadcrumbs, BreadcrumbItem } from '@/src/components/navigation/Breadcrumbs';
import { Header } from '@/src/components/layout/Header';
import { Footer } from '@/src/components/layout/Footer';
import { LocationSectionNav } from '@/src/components/locations/LocationSectionNav';
import { LocationHero2 } from '@/src/components/locations/LocationHero2';
import { MarketSnapshotSection } from '@/src/components/locations/MarketSnapshotSection';
import { ExploreModesBar } from '@/src/components/locations/ExploreModesBar';
import { LocationProjectsSection } from '@/src/components/locations/LocationProjectsSection';
import { ConfigurationIntelligenceSection } from '@/src/components/locations/ConfigurationIntelligenceSection';
import { PricingIntelligenceSection } from '@/src/components/locations/PricingIntelligenceSection';
import { ResaleIntelligenceSection } from '@/src/components/locations/ResaleIntelligenceSection';
import { RentalIntelligenceSection } from '@/src/components/locations/RentalIntelligenceSection';
import { ReraIntelligenceSection } from '@/src/components/locations/ReraIntelligenceSection';
import { LocationConnectivitySection } from '@/src/components/locations/LocationConnectivitySection';
import { MarketActivitySection } from '@/src/components/locations/MarketActivitySection';
import { NearbyLocationsSection } from '@/src/components/locations/NearbyLocationsSection';
import { MarketChartsSection } from '@/src/components/locations/MarketChartsSection';

interface LocationPageProps {
  params: Promise<{ slug: string }>;
  searchParams?: Promise<{ scope?: string }>;
}

export async function generateMetadata(
  props: LocationPageProps
): Promise<Metadata> {
  await ensureSeedData();
  const { slug } = await props.params;
  const normalizedSlug = slug.toLowerCase().trim();
  const isAlias = LOCATION_ALIASES[normalizedSlug] !== undefined;

  const location = await locationService.resolveLocationBySlug(normalizedSlug, { publishedOnly: true });

  if (!location || location.status !== 'PUBLISHED') {
    notFound();
  }

  const path = await locationService.getLocationPath(location.id, { publishedOnly: true });
  const childLocations = await locationService.getChildLocations(location.id, { publishedOnly: true });

  const projectsRes = await propertyDiscoveryService.discoverProjects({ location: normalizedSlug }, 1, 50);

  const eligibility = locationSeoService.evaluateEligibility({
    location,
    path,
    childLocations,
    projects: projectsRes.data.map(p => ({ id: p.id, lifecycleStatus: (p as any).lifecycleStatus || 'PUBLISHED' })),
    isAlias,
  });

  return locationSeoService.buildMetadata(eligibility);
}

export default async function LocationDetailPage(props: LocationPageProps) {
  await ensureSeedData();
  const { slug } = await props.params;
  const rawSearchParams = props.searchParams ? await props.searchParams : {};
  const normalizedSlug = slug.toLowerCase().trim();
  const scopeParam = rawSearchParams.scope === 'DIRECT' ? 'DIRECT' : 'DESCENDANT';

  // 1. Resolve Location Intelligence DTO from Phase 15.1 service
  const intel = await locationIntelligenceService.getLocationIntelligence(normalizedSlug, {
    scope: scopeParam,
  });

  const history = intel ? await locationIntelligenceService.getLocationHistory(intel.location.id, scopeParam) : [];

  if (!intel) {
    notFound();
  }

  // 2. Resolve published canonical location & ancestry path
  const location = await locationService.resolveLocationBySlug(normalizedSlug, { publishedOnly: true });
  if (!location || location.status !== 'PUBLISHED') {
    notFound();
  }

  const path = await locationService.getLocationPath(location.id, { publishedOnly: true });
  const childLocations = await locationService.getChildLocations(location.id, { publishedOnly: true });

  // 3. Resolve sibling/nearby locations for spatial discovery
  let nearbyLocations: Array<{ id: string; name: string; slug: string; levelDisplay?: string; projectCount?: number }> = [];
  if (childLocations.length > 0) {
    nearbyLocations = childLocations.map(c => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      levelDisplay: c.type,
    }));
  } else if (location.parentId) {
    const siblings = await locationService.getChildLocations(location.parentId, { publishedOnly: true });
    nearbyLocations = siblings
      .filter(s => s.id !== location.id)
      .map(s => ({
        id: s.id,
        name: s.name,
        slug: s.slug,
        levelDisplay: s.type,
      }));
  }

  // 4. Resolve real property discovery listings for projects, resale, and rentals
  const projectsRes = await propertyDiscoveryService.discoverProjects({ location: normalizedSlug }, 1, 20);
  const resaleRes = await propertyDiscoveryService.discoverBuy({ location: normalizedSlug, inventoryType: 'RESALE' }, 1, 20);
  const rentalRes = await propertyDiscoveryService.discoverRent({ location: normalizedSlug }, 1, 20);

  const projects = projectsRes.data;
  const resaleListings = resaleRes.data.filter(item => item.type === 'RESALE') as any[];
  const rentalListings = rentalRes.data.filter(item => item.type === 'RENT') as any[];

  // 5. Construct canonical UI Breadcrumb items
  const breadcrumbItems: BreadcrumbItem[] = [
    { label: 'Home', href: '/' },
    { label: 'Locations', href: '/locations' },
  ];

  for (const ancestor of path) {
    if (ancestor.id !== location.id) {
      breadcrumbItems.push({
        label: ancestor.name,
        href: `/locations/${ancestor.slug}`,
      });
    }
  }

  breadcrumbItems.push({
    label: location.name,
    current: true,
  });

  // 6. Construct JSON-LD Structured Data
  const structuredData = locationSeoService.buildJsonLd({
    location,
    path,
    canonicalUrl: `https://greathomes.co.in/locations/${location.slug}`,
    description: intel.location.description || undefined,
  });

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#111111] flex flex-col font-sans">
      {/* Global Header */}
      <Header />

      {/* Structured Data (Place + BreadcrumbList JSON-LD) */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      {/* Breadcrumb Bar */}
      <div className="bg-white border-b border-[rgba(17,17,17,0.08)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <Breadcrumbs items={breadcrumbItems} />
        </div>
      </div>

      {/* Section Sticky Navigation Bar */}
      <LocationSectionNav />

      {/* Main Location Intelligence Page Body */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 space-y-10 sm:space-y-12 flex-grow pb-20">
        {/* 1. Location Hero 2.0 */}
        <div id="overview">
          <LocationHero2
            location={intel.location}
            marketOverview={intel.marketOverview}
            activeScope={intel.scope}
            hasChildLocations={childLocations.length > 0}
          />
        </div>

        {/* 2. Factual Market Snapshot */}
        <div id="overview">
          <MarketSnapshotSection
            locationName={intel.location.name}
            marketOverview={intel.marketOverview}
            rera={intel.rera}
            freshness={intel.freshness}
          />
        </div>

        {/* 3. Explore Modes Bar */}
        <ExploreModesBar
          locationSlug={intel.location.slug}
          locationName={intel.location.name}
        />

        {/* 4. Primary Projects Discovery Section */}
        <div id="projects">
          <LocationProjectsSection
            locationName={intel.location.name}
            locationSlug={intel.location.slug}
            projects={projects}
          />
        </div>

        {/* 5. Configuration Intelligence */}
        <div id="configurations">
          <ConfigurationIntelligenceSection
            locationName={intel.location.name}
            configDistribution={intel.supply.projectConfigurationDistribution}
          />
        </div>

        {/* 6. Price Intelligence (Separate Area Bases) */}
        <div id="pricing">
          <PricingIntelligenceSection
            locationName={intel.location.name}
            pricing={intel.pricing}
          />
        </div>

        {/* 7. Resale Intelligence Section */}
        <div id="resale">
          <ResaleIntelligenceSection
            locationName={intel.location.name}
            locationSlug={intel.location.slug}
            resaleListings={resaleListings}
          />
        </div>

        {/* 8. Rental Intelligence Section */}
        <div id="rent">
          <RentalIntelligenceSection
            locationName={intel.location.name}
            locationSlug={intel.location.slug}
            rentalListings={rentalListings}
          />
        </div>

        {/* 9. RERA Coverage & Verification */}
        <div id="rera">
          <ReraIntelligenceSection
            locationName={intel.location.name}
            rera={intel.rera}
          />
        </div>

        {/* 10. Location & Connectivity (Map & Distance Metrics) */}
        <div id="connectivity">
          <LocationConnectivitySection
            locationName={intel.location.name}
            coordinates={
              intel.location.latitude !== null && intel.location.longitude !== null
                ? { latitude: intel.location.latitude, longitude: intel.location.longitude }
                : null
            }
            connectivity={intel.connectivity}
          />
        </div>

        {/* 11. Recent Market Activity */}
        <div id="activity">
          <MarketActivitySection
            locationName={intel.location.name}
            activity={intel.recentActivity}
          />
        </div>

        {/* 12. Market Trends */}
        <div id="trends">
          <MarketChartsSection
            locationName={intel.location.name}
            history={history}
          />
        </div>
        
        {/* 13. Explore Nearby Locations */}
        <div id="nearby">
          <NearbyLocationsSection
            locationName={intel.location.name}
            nearbyLocations={nearbyLocations}
          />
        </div>

      </main>

      {/* Global Footer */}
      <Footer />
    </div>
  );
}
