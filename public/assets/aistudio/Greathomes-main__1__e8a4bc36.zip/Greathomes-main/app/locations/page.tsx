import { Metadata } from 'next';
import Link from 'next/link';
import { ArrowRight, MapPin, ShieldCheck, Building2 } from 'lucide-react';
import { locationRepository } from '@/src/infrastructure/repositories/memory/locationRepositoryMemory';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { LOCATION_LEVEL_DISPLAY_NAMES } from '@/src/domain/projects/viewModels/projectLocationViewModel';
import { Breadcrumbs } from '@/src/components/navigation/Breadcrumbs';

export const metadata: Metadata = {
  title: 'Locations Directory — Real Estate Intelligence | Great Homes',
  description: 'Explore canonical residential locations, cities, regions, and areas across West Bengal and Kolkata with verified intelligence on Great Homes V2.',
  alternates: {
    canonical: 'https://greathomes.co.in/locations',
  },
  openGraph: {
    title: 'Locations Directory — Real Estate Intelligence | Great Homes',
    description: 'Explore canonical residential locations, cities, regions, and areas across West Bengal and Kolkata with verified intelligence on Great Homes V2.',
    url: 'https://greathomes.co.in/locations',
    siteName: 'Great Homes',
    type: 'website',
  },
  twitter: {
    card: 'summary',
    title: 'Locations Directory — Real Estate Intelligence | Great Homes',
    description: 'Explore canonical residential locations, cities, regions, and areas across West Bengal and Kolkata with verified intelligence on Great Homes V2.',
  },
};

export default async function LocationsDirectoryPage() {
  await ensureSeedData();

  const allLocations = await locationRepository.findAll();
  const published = allLocations.filter(l => l.status === 'PUBLISHED');

  const states = published.filter(l => l.type === 'STATE');
  const cities = published.filter(l => l.type === 'CITY');
  const areas = published.filter(l => l.type === 'AREA');

  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'Locations', current: true },
  ];

  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      {
        '@type': 'ListItem',
        position: 1,
        name: 'Home',
        item: 'https://greathomes.co.in',
      },
      {
        '@type': 'ListItem',
        position: 2,
        name: 'Locations',
        item: 'https://greathomes.co.in/locations',
      },
    ],
  };

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#111111]">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <div className="bg-white border-b border-[rgba(17,17,17,0.08)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
          <Breadcrumbs items={breadcrumbItems} />
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-12">
        <div className="space-y-4 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 text-xs text-[#218C5A] font-medium bg-[#218C5A]/10 px-2.5 py-1 rounded-md border border-[#218C5A]/20">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Verified Location Directory</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-normal text-[#111111] tracking-tight leading-tight">
            Explore Residential Locations
          </h1>

          <p className="text-sm sm:text-base font-body text-[#111111]/75 leading-relaxed">
            Discover verified residential areas, cities, and connectivity with authoritative location intelligence.
          </p>
        </div>

        {/* Primary Areas Grid */}
        <div className="space-y-5">
          <div className="flex items-baseline justify-between border-b border-[rgba(17,17,17,0.08)] pb-3">
            <h2 className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight">
              Key Residential Areas
            </h2>
            <span className="text-xs font-mono text-[#111111]/50">
              {areas.length} Verified Areas
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {areas.map(loc => {
              const levelDisplay = LOCATION_LEVEL_DISPLAY_NAMES[loc.type] || loc.type;

              return (
                <Link
                  key={loc.id}
                  href={`/locations/${loc.slug}`}
                  className="p-6 rounded-xl border border-[rgba(17,17,17,0.08)] bg-white hover:border-[rgba(17,17,17,0.25)] hover:shadow-md transition-all group flex flex-col justify-between"
                >
                  <div className="space-y-2.5">
                    <span className="text-[10px] font-display uppercase tracking-wider text-[#111111]/50 font-semibold block">
                      {levelDisplay}
                    </span>

                    <h3 className="text-lg font-display font-semibold text-[#111111] group-hover:text-[#E85D3F] transition-colors">
                      {loc.name}
                    </h3>

                    {loc.description && (
                      <p className="text-xs font-body text-[#111111]/70 line-clamp-2">
                        {loc.description}
                      </p>
                    )}
                  </div>

                  <div className="mt-5 pt-3.5 border-t border-[rgba(17,17,17,0.06)] flex items-center justify-between text-xs font-display font-medium text-[#111111]/70 group-hover:text-[#E85D3F] transition-colors">
                    <span>Explore location intelligence</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Metropolitan Cities */}
        {cities.length > 0 && (
          <div className="space-y-5 pt-6 border-t border-[rgba(17,17,17,0.08)]">
            <div className="flex items-baseline justify-between border-b border-[rgba(17,17,17,0.08)] pb-3">
              <h2 className="text-xl sm:text-2xl font-display font-semibold text-[#111111] tracking-tight">
                Cities &amp; Municipalities
              </h2>
              <span className="text-xs font-mono text-[#111111]/50">
                {cities.length} Cities
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {cities.map(city => (
                <Link
                  key={city.id}
                  href={`/locations/${city.slug}`}
                  className="p-5 rounded-xl border border-[rgba(17,17,17,0.08)] bg-white hover:border-[rgba(17,17,17,0.25)] hover:shadow-md transition-all group flex items-center justify-between"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-lg bg-[rgba(17,17,17,0.04)] border border-[rgba(17,17,17,0.08)] flex items-center justify-center text-[#111111]/70">
                      <MapPin className="w-5 h-5 text-[#E85D3F]" />
                    </div>
                    <div>
                      <h3 className="text-base font-display font-semibold text-[#111111] group-hover:text-[#E85D3F] transition-colors">
                        {city.name}
                      </h3>
                      <span className="text-xs font-body text-[#111111]/50">
                        West Bengal
                      </span>
                    </div>
                  </div>

                  <ArrowRight className="w-4 h-4 text-[#111111]/40 group-hover:text-[#E85D3F] group-hover:translate-x-1 transition-all" />
                </Link>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
