import { NextRequest, NextResponse } from 'next/server';
import {
  developerService,
  ValidationError,
  NotFoundError,
  DuplicateSlugError,
} from '@/src/domain/developers/services/developerService';
import { verifyInternalStaff } from '@/src/domain/auth/authorizationBoundary';
import { ensureSeedData } from '@/src/infrastructure/seed';

export async function GET(
  request: NextRequest,
  props: { params: Promise<{ id: string }> }
) {
  try {
    await ensureSeedData();
    const { id } = await props.params;
    const auth = await verifyInternalStaff(request);
    const isInternalStaff = auth.authorized;

    const developer = await developerService.getPublicDeveloperDtoById(id, isInternalStaff);
    if (!developer) {
      return NextResponse.json(
        { error: `Developer with id '${id}' not found` },
        { status: 404 }
      );
    }

    return NextResponse.json(developer);
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  request: NextRequest,
  props: { params: Promise<{ id: string }> }
) {
  const auth = await verifyInternalStaff(request);
  if (!auth.authorized) {
    return NextResponse.json(
      { error: auth.error || 'Unauthorized' },
      { status: auth.statusCode || 401 }
    );
  }

  try {
    const { id } = await props.params;
    const body = await request.json();

    const updated = await developerService.updateDeveloper(id, body);
    return NextResponse.json(updated);
  } catch (error: any) {
    if (error instanceof NotFoundError) {
      return NextResponse.json({ error: error.message }, { status: 404 });
    }
    if (error instanceof ValidationError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    if (error instanceof DuplicateSlugError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  props: { params: Promise<{ id: string }> }
) {
  const auth = await verifyInternalStaff(request);
  if (!auth.authorized) {
    return NextResponse.json(
      { error: auth.error || 'Unauthorized' },
      { status: auth.statusCode || 401 }
    );
  }

  try {
    const { id } = await props.params;
    const archived = await developerService.archiveDeveloper(id);
    return NextResponse.json({
      success: true,
      message: 'Developer archived successfully',
      developer: archived,
    });
  } catch (error: any) {
    if (error instanceof NotFoundError) {
      return NextResponse.json({ error: error.message }, { status: 404 });
    }
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}
