import { NextRequest, NextResponse } from 'next/server';
import { resaleListingService } from '@/src/domain/projects/services/resaleService';
import { verifyStaffCapability } from '@/src/domain/auth/capabilities';
import { ensureSeedData } from '@/src/infrastructure/seed';

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function GET(req: NextRequest, context: RouteContext) {
  try {
    await ensureSeedData();
    const { id } = await context.params;
    const media = await resaleListingService.findMediaByListingId(id);
    return NextResponse.json({ success: true, data: media });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest, context: RouteContext) {
  try {
    await ensureSeedData();
    const auth = await verifyStaffCapability(req, 'listing.manageMedia');
    const authManage = await verifyStaffCapability(req, 'MANAGE_RESALE');
    if (!auth.authorized && !authManage.authorized) {
      return NextResponse.json({ success: false, error: 'Unauthorized to manage media' }, { status: 403 });
    }

    const { id } = await context.params;
    const body = await req.json();

    if (!body.url) {
      return NextResponse.json({ success: false, error: 'Media URL is required' }, { status: 400 });
    }

    const media = await resaleListingService.addMedia(id, {
      mediaType: body.mediaType || 'IMAGE',
      category: body.category || 'EXTERIOR',
      url: body.url,
      altText: body.altText || null,
      caption: body.caption || null,
      sortOrder: body.sortOrder || 0,
      isFeatured: !!body.isFeatured,
    });

    return NextResponse.json({ success: true, data: media }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
