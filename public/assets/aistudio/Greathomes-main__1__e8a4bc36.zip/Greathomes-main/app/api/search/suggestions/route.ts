import { NextRequest, NextResponse } from 'next/server';
import { searchService } from '@/src/domain/search/searchService';
import { extractRequestContext, withCorrelationHeaders } from '@/src/lib/requestContext';

export async function GET(req: NextRequest) {
  const { requestId } = extractRequestContext(req);

  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get('q') || '';

    if (q.length > 100) {
      return NextResponse.json({ success: true, suggestions: { projects: [], locations: [], developers: [] } }, { status: 200 });
    }

    const result = await searchService.search(q, 'ALL', 1, 5);
    const response = NextResponse.json(
      {
        success: true,
        suggestions: result.suggestions,
      },
      { status: 200 }
    );
    return withCorrelationHeaders(response, requestId);
  } catch (error: any) {
    console.error('Suggestions API error:', error);
    const response = NextResponse.json(
      { success: false, message: 'Failed to fetch suggestions.' },
      { status: 500 }
    );
    return withCorrelationHeaders(response, requestId);
  }
}
