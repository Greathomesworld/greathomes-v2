import { NextRequest, NextResponse } from 'next/server';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { enquiryService, EnquiryValidationError } from '@/src/domain/enquiry/services/enquiryService';
import { extractRequestContext, withCorrelationHeaders } from '@/src/lib/requestContext';
import { checkRateLimit, createRateLimitResponse } from '@/src/lib/rateLimit';

export async function POST(req: NextRequest) {
  const { requestId, ipAddress } = extractRequestContext(req);

  // Rate limiting: max 100 enquiry submissions per minute per IP
  const rateLimitKey = `enquiry_post_${ipAddress || 'anonymous'}`;
  const rateLimitResult = checkRateLimit(rateLimitKey, 100, 60000);

  if (!rateLimitResult.allowed) {
    return createRateLimitResponse(requestId, rateLimitResult);
  }

  try {
    await ensureSeedData();
    const body = await req.json();

    // Strip client-provided private/sensitive/internal fields before submitting
    const sanitizedBody = { ...body };
    delete sanitizedBody.ownerPhone;
    delete sanitizedBody.ownerEmail;
    delete sanitizedBody.crmId;
    delete sanitizedBody.internalNotes;
    delete sanitizedBody.assignedTo;
    delete sanitizedBody.assignedToName;
    delete sanitizedBody.staffRole;
    delete sanitizedBody.verification;

    const result = await enquiryService.submitEnquiry(sanitizedBody);
    const response = NextResponse.json(result, { status: 201 });
    return withCorrelationHeaders(response, requestId);
  } catch (error: any) {
    if (error instanceof EnquiryValidationError) {
      const response = NextResponse.json(
        { success: false, message: error.message },
        { status: 400 }
      );
      return withCorrelationHeaders(response, requestId);
    }
    console.error('Enquiry API error:', error);
    const response = NextResponse.json(
      { success: false, message: error?.message || 'An unexpected error occurred while processing your enquiry. Please try again.' },
      { status: 500 }
    );
    return withCorrelationHeaders(response, requestId);
  }
}
