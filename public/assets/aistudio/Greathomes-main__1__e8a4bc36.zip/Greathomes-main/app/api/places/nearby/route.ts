import { NextRequest, NextResponse } from 'next/server';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { nearbyPlaceService } from '@/src/domain/places/services/nearbyPlaceService';
import { isValidCoordinate } from '@/src/domain/projects/viewModels/projectLocationViewModel';
import { PlaceCategory } from '@/src/domain/places/entities';

export async function GET(req: NextRequest) {
  await ensureSeedData();

  const searchParams = req.nextUrl.searchParams;
  const latStr = searchParams.get('lat');
  const lngStr = searchParams.get('lng');
  const radiusStr = searchParams.get('radius');
  const categoryStr = searchParams.get('category');
  const limitStr = searchParams.get('limit');

  if (!latStr || !lngStr) {
    return NextResponse.json(
      { error: 'Missing required query parameters: "lat" and "lng"' },
      { status: 400 }
    );
  }

  const latitude = parseFloat(latStr);
  const longitude = parseFloat(lngStr);

  if (!isValidCoordinate(latitude, longitude)) {
    return NextResponse.json(
      { error: 'Invalid coordinates. Latitude must be between -90 and 90, longitude between -180 and 180.' },
      { status: 400 }
    );
  }

  // Security audit safeguard: Restrict arbitrary spatial probing to supported operational market bounds
  // West Bengal / Kolkata Regional Market: Lat [21.5, 27.5], Lng [85.5, 89.9]
  const isWithinOperationalMarket =
    latitude >= 21.5 && latitude <= 27.5 && longitude >= 85.5 && longitude <= 89.9;

  if (!isWithinOperationalMarket) {
    return NextResponse.json(
      { error: 'Spatial queries are restricted to supported operational regional markets (West Bengal / Kolkata).' },
      { status: 400 }
    );
  }

  // Security clamping: Cap radius to max 25 km and limit to max 50 to prevent spatial scraping
  const rawRadius = radiusStr ? parseFloat(radiusStr) : 15;
  const radiusKm = Math.min(25, Math.max(0.5, isNaN(rawRadius) ? 15 : rawRadius));

  const rawLimit = limitStr ? parseInt(limitStr, 10) : 20;
  const limit = Math.min(50, Math.max(1, isNaN(rawLimit) ? 20 : rawLimit));

  const category = categoryStr ? (categoryStr.toUpperCase() as PlaceCategory) : undefined;

  const places = await nearbyPlaceService.getNearbyPlaces(
    { latitude, longitude },
    { radiusKm, limit, category }
  );

  return NextResponse.json({
    success: true,
    count: places.length,
    origin: {
      latitude,
      longitude,
    },
    radiusKm,
    data: places,
  });
}
