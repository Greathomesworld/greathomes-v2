import { NextRequest, NextResponse } from 'next/server';
import { verifyStaffCapability } from '@/src/domain/auth/capabilities';
import { mediaProcessingService } from '@/src/domain/media/services/mediaProcessingService';
import { mediaRepository, MediaAsset } from '@/src/domain/media/repositories/mediaRepository';
import { auditService } from '@/src/domain/audit/auditService';
import { extractRequestContext, withCorrelationHeaders } from '@/src/lib/requestContext';

export async function POST(req: NextRequest) {
  const reqContext = extractRequestContext(req);

  // 1. Authorization check
  const auth = await verifyStaffCapability(req, 'MANAGE_MEDIA');
  if (!auth.authorized) {
    return withCorrelationHeaders(
      NextResponse.json(
        { success: false, error: auth.error || 'Unauthorized' },
        { status: auth.status || 401 }
      ),
      reqContext.requestId
    );
  }

  try {
    const contentType = req.headers.get('content-type') || '';
    let filename = '';
    let mimeType = '';
    let category = 'OTHER';
    let entityType: any = 'PROJECT';
    let entityId = 'general';
    let altText: string | null = null;
    let caption: string | null = null;
    let sortOrder = 0;
    let isFeatured = false;
    let watermarkMode: any = 'AUTO';
    let configurationId: string | null = null;
    let fileBuffer: Buffer | null = null;
    let updatedConfiguration: any = null;

    if (contentType.includes('multipart/form-data')) {
      const formData = await req.formData();
      const file = formData.get('file') as File | null;
      if (!file) {
        return withCorrelationHeaders(
          NextResponse.json(
            { success: false, error: 'No file provided in multipart form data.' },
            { status: 400 }
          ),
          reqContext.requestId
        );
      }

      filename = file.name;
      mimeType = file.type || 'application/octet-stream';
      category = (formData.get('category') as string) || 'OTHER';
      entityType = ((formData.get('entityType') as string) || 'PROJECT').toUpperCase();
      entityId = (formData.get('entityId') as string) || 'general';
      configurationId = (formData.get('configurationId') as string) || null;
      altText = (formData.get('altText') as string) || null;
      caption = (formData.get('caption') as string) || null;
      sortOrder = parseInt((formData.get('sortOrder') as string) || '0', 10);
      isFeatured = formData.get('isFeatured') === 'true';
      watermarkMode = formData.get('watermarkMode') || 'AUTO';

      const arrayBuffer = await file.arrayBuffer();
      fileBuffer = Buffer.from(arrayBuffer);
    } else {
      // JSON payload with base64 data
      const body = await req.json();
      if (!body.fileBase64 && !body.data) {
        return withCorrelationHeaders(
          NextResponse.json(
            { success: false, error: 'No file content or base64 provided.' },
            { status: 400 }
          ),
          reqContext.requestId
        );
      }

      filename = body.filename || 'upload.jpg';
      mimeType = body.mimeType || 'image/jpeg';
      category = body.category || 'OTHER';
      entityType = (body.entityType || 'PROJECT').toUpperCase();
      entityId = body.entityId || 'general';
      configurationId = body.configurationId || null;
      altText = body.altText || null;
      caption = body.caption || null;
      sortOrder = body.sortOrder || 0;
      isFeatured = Boolean(body.isFeatured);
      watermarkMode = body.watermarkMode || 'AUTO';

      const base64Str = (body.fileBase64 || body.data).replace(/^data:image\/[a-z]+;base64,/, '');
      fileBuffer = Buffer.from(base64Str, 'base64');
    }

    if (!fileBuffer || fileBuffer.length === 0) {
      return withCorrelationHeaders(
        NextResponse.json(
          { success: false, error: 'Empty file buffer received.' },
          { status: 400 }
        ),
        reqContext.requestId
      );
    }

    // Server-side validation of project and configuration identity if configurationId is supplied
    let targetProject: any = null;
    let targetConfig: any = null;
    if (entityType === 'PROJECT' && entityId && entityId !== 'general') {
      const { projectRepository, projectConfigurationRepository } = await import('@/src/infrastructure/repositories/projectProvider');
      targetProject = await projectRepository.findById(entityId);
      if (!targetProject) {
        targetProject = await projectRepository.findBySlug(entityId);
      }
      if (!targetProject && configurationId) {
        return withCorrelationHeaders(
          NextResponse.json({ success: false, error: `Project '${entityId}' not found.` }, { status: 404 }),
          reqContext.requestId
        );
      }
      if (configurationId) {
        targetConfig = await projectConfigurationRepository.findById(configurationId);
        if (!targetConfig) {
          return withCorrelationHeaders(
            NextResponse.json({ success: false, error: `Configuration '${configurationId}' not found.` }, { status: 404 }),
            reqContext.requestId
          );
        }
        if (targetProject && targetConfig.projectId !== targetProject.id) {
          return withCorrelationHeaders(
            NextResponse.json(
              { success: false, error: `Configuration '${configurationId}' does not belong to project '${targetProject.id}'.` },
              { status: 400 }
            ),
            reqContext.requestId
          );
        }
      }
    }

    // Process through the image optimization & watermarking pipeline
    const processed = await mediaProcessingService.processUpload(
      fileBuffer,
      filename,
      mimeType,
      category,
      entityType,
      entityId,
      { mode: watermarkMode }
    );

    const now = new Date().toISOString();
    const mediaAsset: MediaAsset = {
      id: processed.id,
      entityType,
      entityId,
      filename: processed.filename,
      mimeType: processed.mimeType,
      category: processed.category,
      mediaType: mimeType === 'application/pdf' ? 'DOCUMENT' : 'IMAGE',
      width: processed.width,
      height: processed.height,
      fileSizeBytes: processed.originalSizeBytes,
      storageProvider: processed.storageProvider,
      storageKey: processed.storageKey,
      url: processed.variants.publicUrl,
      originalUrl: processed.variants.original,
      thumbnailUrl: processed.variants.thumbnail,
      webpUrl: processed.variants.webp,
      avifUrl: processed.variants.avif,
      watermarkedUrl: processed.variants.watermarkedWebp,
      watermarkApplied: processed.watermarkApplied,
      altText,
      caption,
      sortOrder,
      isFeatured,
      processingStatus: processed.processingStatus,
      variants: processed.variants,
      createdAt: now,
      updatedAt: now,
    };

    const saved = await mediaRepository.create(mediaAsset);

    // If entityType is DEVELOPER, automatically link to developer_media using canonical provider!
    if (entityType === 'DEVELOPER') {
      const { developerMediaRepository, developerRepository } = await import('@/src/infrastructure/repositories/developerProvider');
      const dev = await developerRepository.findById(entityId);
      if (dev) {
        const validCategories = ['LOGO', 'BRAND', 'OFFICE', 'EDITORIAL'];
        const devCategory = validCategories.includes(category.toUpperCase())
          ? category.toUpperCase()
          : 'BRAND';
        await developerMediaRepository.create({
          developerId: entityId,
          mediaType: 'IMAGE',
          category: devCategory as any,
          url: saved.url,
          sortOrder: saved.sortOrder ?? 0,
          isFeatured: saved.isFeatured ?? false,
        });
      }
    }

    // If entityType is PROJECT, automatically link to project_media using canonical services!
    let createdProjectMedia: any = null;
    if (entityType === 'PROJECT' && entityId && entityId !== 'general') {
      const { projectIntelligenceService } = await import('@/src/domain/projects/services/projectIntelligenceService');
      const { projectRepository, projectMediaRepository, projectConfigurationRepository } = await import('@/src/infrastructure/repositories/projectProvider');

      let project = await projectRepository.findById(entityId);
      if (!project) {
        project = await projectRepository.findBySlug(entityId);
      }

      if (project) {
        const validCategories = [
          'EXTERIOR',
          'INTERIOR',
          'AMENITIES',
          'CLUBHOUSE',
          'LOCATION',
          'FLOOR_PLANS',
          'MASTER_PLAN',
          'CONSTRUCTION',
          'OTHER',
        ];
        const normalizedCategory = (category || 'OTHER').toUpperCase();
        const projectCategory = validCategories.includes(normalizedCategory)
          ? normalizedCategory
          : 'OTHER';

        // If newly uploaded item is marked as featured, update existing media for this project
        if (isFeatured) {
          try {
            const existingMedia = await projectMediaRepository.findByProjectId(project.id);
            for (const m of existingMedia) {
              if (m.isFeatured) {
                await projectMediaRepository.update(m.id, { isFeatured: false });
              }
            }
          } catch (featErr) {
            console.error('Error resetting existing featured project media:', featErr);
          }
        }

        createdProjectMedia = await projectIntelligenceService.createMedia(
          project.id,
          {
            projectId: project.id,
            mediaId: saved.id,
            configurationId: configurationId || null,
            mediaType: saved.mediaType || 'IMAGE',
            category: projectCategory as any,
            url: saved.url,
            altText: saved.altText ?? null,
            caption: saved.caption ?? null,
            sortOrder: saved.sortOrder ?? 0,
            isFeatured: isFeatured,
          },
          true
        );

        // If this is a floor plan for a configuration, link floorPlanMediaId on the configuration
        if (configurationId && projectCategory === 'FLOOR_PLANS') {
          try {
            const config = await projectConfigurationRepository.findById(configurationId);
            if (config) {
              const oldMediaId = config.floorPlanMediaId;
              updatedConfiguration = await projectConfigurationRepository.update(configurationId, {
                floorPlanMediaId: saved.id,
              });

              // Safe cleanup of replaced media if it is not referenced elsewhere
              if (oldMediaId && oldMediaId !== saved.id) {
                try {
                  const allConfigs = await projectConfigurationRepository.findByProjectId(project.id);
                  const referencedByOtherConfig = allConfigs.some(
                    (c) => c.id !== config.id && c.floorPlanMediaId === oldMediaId
                  );
                  const refCheck = await mediaRepository.checkReferenced(oldMediaId);
                  if (!referencedByOtherConfig && !refCheck.referenced) {
                    await mediaRepository.delete(oldMediaId);
                    await projectMediaRepository.delete(oldMediaId);
                  }
                } catch (cleanErr) {
                  console.warn('Safe cleanup of replaced media skipped:', cleanErr);
                }
              }
            }
          } catch (cfgErr) {
            console.error('Error linking floor plan to configuration:', cfgErr);
          }
        }
      }
    }

    // If marked as featured, update entity featured pointer
    if (isFeatured) {
      await mediaRepository.setFeatured(saved.id, entityType, entityId);
    }

    // Record audit log
    await auditService.record(
      req,
      auth.staff ? { id: auth.staff.id, role: auth.staff.role } : null,
      {
        action: 'CREATE',
        resourceType: 'MEDIA',
        resourceId: saved.id,
        resourceLabel: saved.filename,
        before: null,
        after: {
          id: saved.id,
          filename: saved.filename,
          url: saved.url,
          category: saved.category,
        },
        metadata: {
          filename: saved.filename,
          entityType: saved.entityType,
          entityId: saved.entityId,
          category: saved.category,
          watermarkApplied: saved.watermarkApplied,
        },
        success: true,
      }
    );

    const response = NextResponse.json(
      {
        success: true,
        data: {
          ...saved,
          projectMedia: createdProjectMedia,
          configuration: updatedConfiguration,
        },
        media: saved,
        projectMedia: createdProjectMedia,
        configuration: updatedConfiguration,
      },
      { status: 201 }
    );

    return withCorrelationHeaders(response, reqContext.requestId);
  } catch (error: any) {
    console.error('Media upload error:', error);
    const status = error.message?.includes('validation') ? 400 : 500;
    return withCorrelationHeaders(
      NextResponse.json(
        { success: false, error: error.message || 'Media upload failed' },
        { status }
      ),
      reqContext.requestId
    );
  }
}
