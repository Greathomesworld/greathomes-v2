import { NextRequest, NextResponse } from 'next/server';
import { verifyStaffCapability } from '@/src/domain/auth/capabilities';
import { mediaRepository } from '@/src/domain/media/repositories/mediaRepository';
import { auditService } from '@/src/domain/audit/auditService';
import { extractRequestContext, withCorrelationHeaders } from '@/src/lib/requestContext';

export async function PATCH(req: NextRequest) {
  const reqContext = extractRequestContext(req);
  const auth = await verifyStaffCapability(req, 'MANAGE_MEDIA');
  if (!auth.authorized) {
    return withCorrelationHeaders(
      NextResponse.json(
        { success: false, error: auth.error || 'Unauthorized' },
        { status: auth.status || 401 }
      ),
      reqContext.requestId
    );
  }

  try {
    const body = await req.json();
    const items = body.items as { id: string; sortOrder: number }[];

    if (!Array.isArray(items) || items.length === 0) {
      return withCorrelationHeaders(
        NextResponse.json(
          { success: false, error: 'Expected items array with id and sortOrder.' },
          { status: 400 }
        ),
        reqContext.requestId
      );
    }

    await mediaRepository.reorder(items);

    const { projectMediaRepository } = await import('@/src/infrastructure/repositories/projectProvider');
    for (const item of items) {
      try {
        await projectMediaRepository.update(item.id, { sortOrder: item.sortOrder });
      } catch (err) {
        // ignore individual if not project_media
      }
    }

    // Audit log
    await auditService.record(
      req,
      auth.staff ? { id: auth.staff.id, role: auth.staff.role } : null,
      {
        action: 'UPDATE',
        resourceType: 'MEDIA',
        resourceId: items[0]?.id || 'batch',
        resourceLabel: `Reorder ${items.length} items`,
        before: null,
        after: { items },
        metadata: { count: items.length, subAction: 'REORDER' },
        success: true,
      }
    );

    return withCorrelationHeaders(
      NextResponse.json({ success: true, message: 'Media reordered successfully.' }),
      reqContext.requestId
    );
  } catch (err: any) {
    return withCorrelationHeaders(
      NextResponse.json({ success: false, error: err.message }, { status: 400 }),
      reqContext.requestId
    );
  }
}
