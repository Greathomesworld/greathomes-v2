import { NextRequest, NextResponse } from 'next/server';
import { verifyStaffCapability } from '@/src/domain/auth/capabilities';
import { mediaProcessingService } from '@/src/domain/media/services/mediaProcessingService';
import { mediaRepository } from '@/src/domain/media/repositories/mediaRepository';
import { auditService } from '@/src/domain/audit/auditService';
import { extractRequestContext, withCorrelationHeaders } from '@/src/lib/requestContext';

export async function POST(
  req: NextRequest,
  props: { params: Promise<{ id: string }> }
) {
  const reqContext = extractRequestContext(req);
  const auth = await verifyStaffCapability(req, 'MANAGE_MEDIA');
  if (!auth.authorized) {
    return withCorrelationHeaders(
      NextResponse.json(
        { success: false, error: auth.error || 'Unauthorized' },
        { status: auth.status || 401 }
      ),
      reqContext.requestId
    );
  }

  const { id } = await props.params;
  const existing = await mediaRepository.findById(id);
  if (!existing) {
    return withCorrelationHeaders(
      NextResponse.json({ success: false, error: 'Media asset not found.' }, { status: 404 }),
      reqContext.requestId
    );
  }

  try {
    const contentType = req.headers.get('content-type') || '';
    let filename = '';
    let mimeType = '';
    let fileBuffer: Buffer | null = null;

    if (contentType.includes('multipart/form-data')) {
      const formData = await req.formData();
      const file = formData.get('file') as File | null;
      if (!file) {
        return withCorrelationHeaders(
          NextResponse.json({ success: false, error: 'No replacement file provided.' }, { status: 400 }),
          reqContext.requestId
        );
      }
      filename = file.name;
      mimeType = file.type;
      fileBuffer = Buffer.from(await file.arrayBuffer());
    } else {
      const body = await req.json();
      filename = body.filename || 'replacement.jpg';
      mimeType = body.mimeType || 'image/jpeg';
      const base64Str = (body.fileBase64 || body.data || '').replace(/^data:image\/[a-z]+;base64,/, '');
      fileBuffer = Buffer.from(base64Str, 'base64');
    }

    if (!fileBuffer || fileBuffer.length === 0) {
      return withCorrelationHeaders(
        NextResponse.json({ success: false, error: 'Empty file buffer received.' }, { status: 400 }),
        reqContext.requestId
      );
    }

    // Process new file
    const processed = await mediaProcessingService.processUpload(
      fileBuffer,
      filename,
      mimeType,
      existing.category,
      existing.entityType,
      existing.entityId
    );

    // Update existing record with new URLs and variants while preserving the same ID!
    const updated = await mediaRepository.update(id, {
      filename: processed.filename,
      mimeType: processed.mimeType,
      width: processed.width,
      height: processed.height,
      fileSizeBytes: processed.originalSizeBytes,
      url: processed.variants.publicUrl,
      originalUrl: processed.variants.original,
      thumbnailUrl: processed.variants.thumbnail,
      webpUrl: processed.variants.webp,
      avifUrl: processed.variants.avif,
      watermarkedUrl: processed.variants.watermarkedWebp,
      watermarkApplied: processed.watermarkApplied,
      variants: processed.variants,
      processingStatus: processed.processingStatus,
    });

    // Audit log
    await auditService.record(
      req,
      auth.staff ? { id: auth.staff.id, role: auth.staff.role } : null,
      {
        action: 'UPDATE',
        resourceType: 'MEDIA',
        resourceId: id,
        resourceLabel: processed.filename,
        before: { filename: existing.filename, url: existing.url },
        after: { filename: processed.filename, url: processed.variants.publicUrl },
        metadata: { entityType: existing.entityType, entityId: existing.entityId, subAction: 'REPLACE' },
        success: true,
      }
    );

    return withCorrelationHeaders(
      NextResponse.json({ success: true, data: updated }),
      reqContext.requestId
    );
  } catch (err: any) {
    return withCorrelationHeaders(
      NextResponse.json({ success: false, error: err.message }, { status: 400 }),
      reqContext.requestId
    );
  }
}
