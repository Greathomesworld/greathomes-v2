import { NextRequest, NextResponse } from 'next/server';
import { ensureSeedData } from '@/src/infrastructure/seed';
import { projectIntelligenceService } from '@/src/domain/projects/services/projectIntelligenceService';
import { nearbyPlaceService } from '@/src/domain/places/services/nearbyPlaceService';
import { buildProjectLocationViewModel } from '@/src/domain/projects/viewModels/projectLocationViewModel';
import { PlaceCategory } from '@/src/domain/places/entities';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ slug: string }> }
) {
  await ensureSeedData();

  const { slug } = await context.params;
  const project = await projectIntelligenceService.getProjectBySlug(slug);

  if (!project) {
    return NextResponse.json(
      { error: 'Project not found' },
      { status: 404 }
    );
  }

  const locationVm = buildProjectLocationViewModel(project.location);

  if (!locationVm.hasValidCoordinates || locationVm.latitude === null || locationVm.longitude === null) {
    return NextResponse.json({
      success: true,
      hasCoordinates: false,
      message: 'Project location coordinates are pending verification.',
      count: 0,
      data: [],
    });
  }

  const searchParams = req.nextUrl.searchParams;
  const categoryStr = searchParams.get('category');
  const radiusStr = searchParams.get('radius');
  const limitStr = searchParams.get('limit');

  const radiusKm = radiusStr ? parseFloat(radiusStr) : 15;
  const limit = limitStr ? parseInt(limitStr, 10) : 20;
  const category = categoryStr ? (categoryStr.toUpperCase() as PlaceCategory) : undefined;

  const places = await nearbyPlaceService.getNearbyPlaces(
    { latitude: locationVm.latitude, longitude: locationVm.longitude },
    { radiusKm, limit, category }
  );

  return NextResponse.json({
    success: true,
    hasCoordinates: true,
    projectName: project.name,
    projectLocation: {
      name: locationVm.name,
      latitude: locationVm.latitude,
      longitude: locationVm.longitude,
    },
    count: places.length,
    data: places,
  });
}
